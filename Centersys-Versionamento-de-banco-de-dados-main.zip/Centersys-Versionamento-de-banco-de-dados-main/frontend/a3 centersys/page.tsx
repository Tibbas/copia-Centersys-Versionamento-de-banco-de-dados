'use client';

import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type Dispatch,
  type SetStateAction,
  type ChangeEvent,
} from 'react';
import type { LucideIcon } from 'lucide-react';
import {
  Activity,
  ArrowRight,
  ArrowUpRight,
  Building2,
  CalendarClock,
  Check,
  CheckCheck,
  ChevronDown,
  Clock3,
  Database,
  Edit3,
  Eye,
  EyeOff,
  FileCode,
  History,
  Info,
  KeyRound,
  LayoutDashboard,
  ListChecks,
  LoaderCircle,
  LockKeyhole,
  LogOut,
  Mail,
  Play,
  PlugZap,
  Plus,
  RefreshCw,
  Rocket,
  RotateCcw,
  Search,
  Server,
  ShieldAlert,
  ShieldCheck,
  Shuffle,
  SlidersHorizontal,
  Square,
  Terminal,
  Trash2,
  TriangleAlert,
  Upload,
  X,
} from 'lucide-react';
import {
  api,
  ApiError,
  clearAuthSession,
  getStoredToken,
  getStoredUser,
  saveAuthSession,
  type AgendamentoDto,
  type BancoDeDadosClienteDto,
  type CredencialServidorDto,
  type HistoricoExecucaoResumoDto,
  type LogExecucaoDto,
  type UsuarioInfo,
  type VersaoDisponivelDto,
} from './api';

/* -------------------------------------------------------------------------- */
/* Tipos                                                                       */
/* -------------------------------------------------------------------------- */

type DatabaseStatus = 'Atualizado' | 'Pendente' | 'DESATUALIZADA' | 'Falha' | 'Atualizando...';
type DatacenterFilter = string;
type StatusFilter = 'Todos' | DatabaseStatus;
type Tab = 'dashboard' | 'orchestrator' | 'operations';
type LogLevel = 'SYSTEM' | 'INFO' | 'EXEC' | 'SUCCESS' | 'WARN';
type QueueFocus = 'Todos' | 'DESATUALIZADA' | 'Pendente' | 'Falha';

export interface DatabaseRecord {
  id: number;
  company: string;
  name: string;
  server: string;
  datacenter: string;
  version: string;
  status: DatabaseStatus;
  approved: boolean;
  activeOnInstance: boolean;
  pendingScriptsCount: number;
  lastError?: string | null;
  lastUpdated?: string | null;
}

interface LogEntry {
  id: number;
  time: string;
  level: LogLevel;
  db?: string;
  message: string;
}

interface BatchOrigin {
  status: DatabaseStatus;
  version: string;
}

interface KpiCard {
  title: string;
  value: number;
  icon: LucideIcon;
  color: 'blue' | 'green' | 'amber' | 'red';
  detail: string;
  bar?: number;
}

export interface CustomScript {
  name: string;
  size: string;
  content: string;
}

/* -------------------------------------------------------------------------- */
/* Constantes auxiliares                                                       */
/* -------------------------------------------------------------------------- */

const DEFAULT_FALLBACK_VERSION = 'V4.48.0.0';
const DEFAULT_DATACENTERS = ['Datacenter 111', 'Datacenter 222'];
const DEFAULT_SERVERS = ['SRV-SQL-01', 'SRV-SQL-02', 'SRV-SQL-03', 'SRV-SQL-04', 'SRV-SQL-05'];
const LEGACY_VERSIONS = ['4.42.0.1', '4.45.2.0', '4.46.0.1', '4.46.0.3', '4.47.0.0'];
const STATUS_OPTIONS: DatabaseStatus[] = ['Atualizado', 'Pendente', 'DESATUALIZADA', 'Falha', 'Atualizando...'];
const UPDATABLE: DatabaseStatus[] = ['DESATUALIZADA', 'Pendente', 'Falha'];
const SAMPLE_COMPANIES = [
  'Rede Pague Bem',
  'Atacadão Serra Azul',
  'Laticínios Vale Verde',
  'Construtora Pilar',
  'Transportes Rota Sul',
  'Padaria Trigo de Ouro',
  'Hospital Santa Clara',
  'Agropecuária Campo Forte',
];

const STATUS_META: Record<DatabaseStatus, { className: string; icon: LucideIcon }> = {
  Atualizado: { className: 'status-ok', icon: Check },
  Pendente: { className: 'status-pending', icon: Clock3 },
  DESATUALIZADA: { className: 'status-outdated', icon: TriangleAlert },
  Falha: { className: 'status-failed', icon: X },
  'Atualizando...': { className: 'status-running', icon: LoaderCircle },
};

/* -------------------------------------------------------------------------- */
/* Utilitários                                                                 */
/* -------------------------------------------------------------------------- */

const stripAccents = (value: string) => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
const normalize = (value: string) => stripAccents(value).toLocaleLowerCase('pt-BR');

function cleanVersionNum(v: string) {
  return v.replace(/^[vV]/, '').trim();
}

function compareVersions(a: string, b: string) {
  const pa = cleanVersionNum(a).split('.').map(Number);
  const pb = cleanVersionNum(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const na = isNaN(pa[i]) ? 0 : pa[i];
    const nb = isNaN(pb[i]) ? 0 : pb[i];
    const diff = na - nb;
    if (diff !== 0) return Math.sign(diff);
  }
  return 0;
}

function isVersionBehind(version: string, target: string, isCustom: boolean) {
  if (isCustom) return true;
  return compareVersions(version, target) < 0;
}

function isVersionUpToDate(version: string, target: string, isCustom: boolean) {
  if (isCustom) return false;
  return compareVersions(version, target) >= 0;
}

function formatVersionDisplay(version: string) {
  if (version.endsWith('.sql')) return version;
  if (version.startsWith('V') || version.startsWith('v')) return version;
  return `v${version}`;
}

function mapDtoToRecord(dto: BancoDeDadosClienteDto): DatabaseRecord {
  const validStatuses: DatabaseStatus[] = ['Atualizado', 'Pendente', 'DESATUALIZADA', 'Falha', 'Atualizando...'];
  const normalizedStatus: DatabaseStatus = validStatuses.includes(dto.status as DatabaseStatus)
    ? (dto.status as DatabaseStatus)
    : 'DESATUALIZADA';

  return {
    id: dto.id,
    company: dto.nomeEmpresa,
    name: dto.nomeBanco,
    server: dto.servidor,
    datacenter: dto.datacenter,
    version: dto.versaoAtual,
    status: normalizedStatus,
    approved: dto.aprovado,
    activeOnInstance: dto.ativoNaInstancia,
    pendingScriptsCount: dto.quantidadeScriptsPendentes,
    lastError: dto.ultimoErroResumo ?? dto.logErros?.[0] ?? null,
    lastUpdated: dto.ultimaAtualizacao ?? null,
  };
}

function computePendingScriptsCount(
  currentVersion: string,
  targetVersion: string,
  availableVersions: VersaoDisponivelDto[]
): number {
  if (targetVersion.endsWith('.sql')) return 1;
  const packages = availableVersions.filter(
    v => compareVersions(v.versao, currentVersion) > 0 && compareVersions(v.versao, targetVersion) <= 0
  );
  return packages.reduce((acc, pkg) => acc + pkg.quantidadeScripts, 0);
}

const GENERIC_WORDS = new Set(['grupo', 'rede', 'de', 'da', 'do', 'das', 'dos', 'e', 'ltda', 'sa', 'me', 'eireli', 'cia']);
function suggestDatabaseName(company: string) {
  const words = stripAccents(company).replace(/[^a-zA-Z0-9 ]/g, ' ').split(/\s+/).filter(Boolean);
  const significant = words.filter(word => !GENERIC_WORDS.has(word.toLowerCase()));
  const base = (significant.length ? significant : words)
    .slice(0, 2)
    .map(word => word[0].toUpperCase() + word.slice(1).toLowerCase())
    .join('');
  return base ? `DB_${base}_Prod` : '';
}

const initials = (company: string) =>
  company
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map(word => word[0])
    .join('')
    .toUpperCase();

const pick = <T,>(list: readonly T[]): T => list[Math.floor(Math.random() * list.length)];
const statusRank = (status: DatabaseStatus) =>
  ({ DESATUALIZADA: 0, Pendente: 1, Falha: 2 } as Partial<Record<DatabaseStatus, number>>)[status] ?? 3;

/* -------------------------------------------------------------------------- */
/* Componentes de apresentação                                                 */
/* -------------------------------------------------------------------------- */

function Brand({ light = false, large = false }: { light?: boolean; large?: boolean }) {
  return (
    <div className={`brand ${light ? 'text-white' : 'text-[#102b50]'} ${large ? 'brand-large' : ''}`}>
      <img src="/assets/centersys.png" alt="" />
      <div>
        <span>centersys</span>
        <small>Soluções em sistemas</small>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: DatabaseStatus }) {
  const { className, icon: Icon } = STATUS_META[status] ?? STATUS_META.DESATUALIZADA;
  return (
    <span className={`status ${className}`}>
      <Icon size={12} strokeWidth={2.4} className={status === 'Atualizando...' ? 'animate-spin' : undefined} />
      {status}
    </span>
  );
}

function VersionBadge({
  version,
  targetVersion,
  isCustom,
}: {
  version: string;
  targetVersion: string;
  isCustom: boolean;
}) {
  const behind = isVersionBehind(version, targetVersion, isCustom);
  const isSql = version.endsWith('.sql');
  return (
    <span
      className={`version-pill ${behind ? 'version-behind' : 'version-current'}`}
      title={behind ? `Defasada em relação ao alvo ${targetVersion}` : `Alinhada com o alvo (${targetVersion})`}
    >
      <span className="version-dot" />
      {isSql && <FileCode size={12} className="shrink-0 text-emerald-600" />}
      <code className="font-mono text-[12.5px] font-bold">{formatVersionDisplay(version)}</code>
    </span>
  );
}

function ProgressBar({ value }: { value: number }) {
  return (
    <div className="progress-track" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={value}>
      <div className={`progress-fill ${value >= 100 ? 'done' : ''}`} style={{ width: `${value}%` }} />
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* Aba 1 — Dashboard / Visão geral                                             */
/* -------------------------------------------------------------------------- */

interface DashboardProps {
  records: DatabaseRecord[];
  filteredRecords: DatabaseRecord[];
  availableVersions: VersaoDisponivelDto[];
  datacentersList: string[];
  datacenter: DatacenterFilter;
  setDatacenter: (value: DatacenterFilter) => void;
  status: StatusFilter;
  setStatus: (value: StatusFilter) => void;
  search: string;
  setSearch: (value: string) => void;
  clearFilters: () => void;
  highlightId: number | null;
  isSyncing: boolean;
  testingClientId: number | null;
  onSyncSqlServer: () => void;
  onTestConnection: (record: DatabaseRecord) => void;
  onEditCompany: (record: DatabaseRecord) => void;
  onOpenOrchestrator: (ids: number[]) => void;
  onNewCompany: () => void;
  onOpenVersionDetails: () => void;
  onOpenNewVersionModal: () => void;
  targetVersion: string;
  setTargetVersion: (v: string) => void;
  customScript: CustomScript | null;
  setCustomScript: (script: CustomScript | null) => void;
  activeTarget: string;
  isCustomScript: boolean;
  setToast: (msg: string) => void;
}

function DashboardView({
  records,
  filteredRecords,
  availableVersions,
  datacentersList,
  datacenter,
  setDatacenter,
  status,
  setStatus,
  search,
  setSearch,
  clearFilters,
  highlightId,
  isSyncing,
  testingClientId,
  onSyncSqlServer,
  onTestConnection,
  onEditCompany,
  onOpenOrchestrator,
  onNewCompany,
  onOpenVersionDetails,
  onOpenNewVersionModal,
  targetVersion,
  setTargetVersion,
  customScript,
  setCustomScript,
  activeTarget,
  isCustomScript,
  setToast,
}: DashboardProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const kpis = useMemo(() => {
    const total = filteredRecords.length;
    const current = filteredRecords.filter(
      r => r.status === 'Atualizado' && isVersionUpToDate(r.version, activeTarget, isCustomScript)
    ).length;
    const outdated = filteredRecords.filter(
      r =>
        r.status === 'DESATUALIZADA' ||
        (r.status === 'Atualizado' && isVersionBehind(r.version, activeTarget, isCustomScript))
    ).length;
    const pending = filteredRecords.filter(r => r.status === 'Pendente' || r.status === 'Atualizando...').length;
    const failed = filteredRecords.filter(r => r.status === 'Falha').length;
    return { total, current, outdated, pending, failed, pct: total ? Math.round((current / total) * 100) : 0 };
  }, [filteredRecords, activeTarget, isCustomScript]);

  const cards: KpiCard[] = [
    { title: 'Total de empresas', value: kpis.total, icon: Building2, color: 'blue', detail: 'Bancos ativos no catálogo' },
    {
      title: 'Na versão alvo',
      value: kpis.current,
      icon: CheckCheck,
      color: 'green',
      detail: `${kpis.pct}% alinhados a ${activeTarget}`,
      bar: kpis.pct,
    },
    {
      title: 'Desatualizadas / Pendentes',
      value: kpis.outdated + kpis.pending,
      icon: Clock3,
      color: 'amber',
      detail: `${kpis.outdated} desatualizada(s) · ${kpis.pending} pendente(s)`,
    },
    { title: 'Falhas', value: kpis.failed, icon: TriangleAlert, color: 'red', detail: 'Requerem atenção / reprocessamento' },
  ];

  const outdatedAll = records.filter(
    r => r.approved && (r.status === 'DESATUALIZADA' || isVersionBehind(r.version, activeTarget, isCustomScript))
  );
  const hasFilters = datacenter !== 'Todos' || status !== 'Todos' || search !== '';

  const handleFileUpload = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const content = await file.text();
      const sizeStr = `${(file.size / 1024).toFixed(1)} KB`;
      setCustomScript({ name: file.name, size: sizeStr, content });
      setToast(`Script customizado "${file.name}" (${sizeStr}) carregado e pronto para validação T-SQL.`);
    }
    event.target.value = '';
  };

  return (
    <>
      <div className="mb-8 flex flex-wrap items-center justify-between gap-6">
        <div>
          <div className="eyebrow mb-2">GERENCIAMENTO DE AMBIENTES SQL SERVER</div>
          <h1 className="text-[29px] font-semibold tracking-[-.8px]">Seus bancos, em uma só visão.</h1>
          <p className="mt-2 text-sm text-slate-500">
            Versões lidas diretamente de <code className="font-mono text-xs text-[#103c6b]">dbo.Log_Acesso.cNumVersao</code> em cada banco ativo da instância.
          </p>
        </div>

        {/* Card Destaque de Versão Alvo */}
        <div className="target-panel flex flex-col justify-between gap-3 p-4 sm:p-5 w-full md:w-auto md:min-w-[440px] lg:min-w-[490px]">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#103c6b] text-white shadow-sm">
                {isCustomScript ? <FileCode size={19} /> : <ArrowUpRight size={19} />}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <p className="text-[10px] font-bold tracking-[1.4px] text-[#647b97]">VERSÃO ALVO PADRÃO</p>
                  <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse" title="Conectado à API" />
                </div>
                <p className="text-[11px] text-slate-400">
                  {isCustomScript ? 'Script SQL customizado carregado em memória' : 'Pacote oficial cadastrado no Banco Central'}
                </p>
              </div>
            </div>

            {isCustomScript ? (
              <span className="target-badge-custom">
                <FileCode size={12} /> Script .SQL
              </span>
            ) : (
              <span className="target-badge-official">
                <ShieldCheck size={12} /> Oficial CenterSys
              </span>
            )}
          </div>

          <div className="flex items-baseline justify-between gap-3 border-y border-slate-100 py-2">
            <div className="flex items-center gap-2.5">
              <span className="font-mono text-2xl lg:text-3xl font-extrabold tracking-tight text-[#0b2c54] drop-shadow-sm break-all">
                {activeTarget}
              </span>
              {isCustomScript && (
                <span className="rounded bg-emerald-100/70 px-2 py-0.5 font-mono text-[11px] font-semibold text-emerald-800">
                  {customScript?.size}
                </span>
              )}
            </div>
            <div className="flex items-center gap-1.5">
              {!isCustomScript && (
                <button
                  type="button"
                  onClick={onOpenVersionDetails}
                  className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-medium text-[#103c6b] hover:bg-[#eef5fd] transition-colors"
                  title="Ver scripts e hashes SHA-256 deste pacote"
                >
                  <Info size={13} /> Detalhes
                </button>
              )}
              {isCustomScript && (
                <button
                  type="button"
                  onClick={() => {
                    setCustomScript(null);
                    setToast(`Restaurada a versão padrão ${targetVersion}.`);
                  }}
                  className="inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-[11px] font-medium text-slate-500 hover:bg-slate-100 hover:text-slate-800 transition-colors"
                >
                  <RotateCcw size={12} /> Restaurar padrão
                </button>
              )}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 pt-0.5">
            <div className="relative min-w-[155px] flex-1">
              <select
                id="target-version-select"
                value={isCustomScript ? '' : targetVersion}
                onChange={e => {
                  setTargetVersion(e.target.value);
                  setCustomScript(null);
                  setToast(`Versão alvo padrão alterada para ${e.target.value}.`);
                }}
                className="h-9 w-full appearance-none rounded-lg border border-[#cfdcec] bg-white px-3 pr-8 text-xs font-semibold text-[#142a46] shadow-sm hover:border-[#103c6b] focus:border-[#103c6b] focus:outline-none cursor-pointer"
                aria-label="Selecionar versão alvo"
              >
                {isCustomScript && (
                  <option value="" disabled>
                    Custom: {customScript?.name}
                  </option>
                )}
                {availableVersions.map(v => (
                  <option key={v.versao} value={v.versao}>
                    {v.versao} ({v.quantidadeScripts} scripts){v.padrao ? ' · Padrão' : ''}
                  </option>
                ))}
              </select>
              <ChevronDown size={14} className="pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            </div>

            <button
              type="button"
              onClick={onOpenNewVersionModal}
              className="inline-flex h-9 items-center justify-center gap-1.5 rounded-lg border border-[#cfdcec] bg-white px-3 text-xs font-semibold text-[#103c6b] hover:bg-[#f1f6fc]"
              title="Cadastrar novo pacote de versão oficial"
            >
              <Plus size={14} /> Nova Versão
            </button>

            <input ref={fileInputRef} type="file" accept=".sql" className="hidden" onChange={handleFileUpload} />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className={`inline-flex h-9 items-center justify-center gap-2 rounded-lg border px-3.5 text-xs font-semibold shadow-sm transition-all cursor-pointer ${
                isCustomScript
                  ? 'border-emerald-300 bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                  : 'border-[#103c6b] bg-[#103c6b] text-white hover:bg-[#17558f]'
              }`}
              title="Anexar arquivo .sql para aplicar como script customizado"
            >
              <Upload size={14} />
              <span>{isCustomScript ? 'Substituir .sql' : 'Anexar .sql'}</span>
            </button>
          </div>
        </div>
      </div>

      {outdatedAll.length > 0 && (
        <div className="alert-banner mb-6">
          <div className="flex items-start gap-3">
            <span className="mt-0.5 rounded-lg bg-orange-100 p-2 text-orange-600">
              <TriangleAlert size={17} />
            </span>
            <div>
              <p className="text-sm font-semibold text-[#7c2d12]">
                {outdatedAll.length} empresa(s) elegíveis para atualização em relação ao alvo ({activeTarget})
              </p>
              <p className="mt-0.5 text-xs text-[#9a3412]/80">
                {outdatedAll
                  .slice(0, 3)
                  .map(r => `${r.company} (${r.version})`)
                  .join(' · ')}
                {outdatedAll.length > 3 && ` e mais ${outdatedAll.length - 3}`}
              </p>
            </div>
          </div>
          <button className="action-button" onClick={() => onOpenOrchestrator(outdatedAll.map(r => r.id))}>
            <Rocket size={13} /> Atualizar no orquestrador
          </button>
        </div>
      )}

      <div className="mb-8 grid grid-cols-2 gap-4 lg:grid-cols-4">
        {cards.map(card => (
          <section key={card.title} className="stat-card rounded-xl border border-slate-200 bg-white p-5">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[13px] text-slate-500">{card.title}</span>
              <span className={`stat-icon ${card.color}`}>
                <card.icon size={18} />
              </span>
            </div>
            <p className="mt-1 text-[32px] font-semibold tracking-tight">{card.value.toString().padStart(2, '0')}</p>
            {card.bar !== undefined && (
              <div className="mt-2">
                <ProgressBar value={card.bar} />
              </div>
            )}
            <p className="mt-1.5 text-[11px] text-slate-400">{card.detail}</p>
          </section>
        ))}
      </div>

      <section className="overflow-hidden rounded-xl border border-slate-200 bg-white">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 px-6 py-5">
          <div className="flex items-center gap-3">
            <h2 className="text-base font-semibold">Frota de bancos de dados</h2>
            <span className="rounded-md bg-slate-100 px-2 py-1 text-[10px] font-medium text-slate-500">
              {records.length} EMPRESAS
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              className="ghost-button"
              onClick={onSyncSqlServer}
              disabled={isSyncing}
              title="Varre sys.databases (ignorando '_') e relê dbo.Log_Acesso em todos os clientes"
            >
              <RefreshCw size={14} className={isSyncing ? 'animate-spin' : undefined} />
              {isSyncing ? 'Sincronizando...' : 'Sincronizar SQL Server'}
            </button>
            <button type="button" className="ghost-button" onClick={onNewCompany}>
              <Plus size={15} /> Cadastrar Cliente / Banco
            </button>
          </div>
        </div>

        <div className="flex flex-wrap items-end gap-4 px-6 py-5">
          <div className="min-w-[200px] flex-1">
            <label htmlFor="search" className="filter-label">
              Buscar banco ou empresa
            </label>
            <div className="input-wrap compact">
              <Search size={16} />
              <input
                id="search"
                placeholder="Empresa, banco ou servidor..."
                value={search}
                onChange={event => setSearch(event.target.value)}
              />
              {search && (
                <button aria-label="Limpar busca" onClick={() => setSearch('')}>
                  <X size={14} />
                </button>
              )}
            </div>
          </div>
          <div className="w-full sm:w-[205px]">
            <label htmlFor="datacenter" className="filter-label">
              Datacenter
            </label>
            <div className="select-wrap">
              <Server size={15} />
              <select id="datacenter" value={datacenter} onChange={event => setDatacenter(event.target.value)}>
                <option value="Todos">Todos os datacenters</option>
                {datacentersList.map(dc => (
                  <option key={dc} value={dc}>
                    {dc}
                  </option>
                ))}
              </select>
              <ChevronDown size={14} />
            </div>
          </div>
          <div className="w-full sm:w-[190px]">
            <label htmlFor="status" className="filter-label">
              Status
            </label>
            <div className="select-wrap">
              <SlidersHorizontal size={15} />
              <select id="status" value={status} onChange={event => setStatus(event.target.value as StatusFilter)}>
                <option value="Todos">Todos os status</option>
                {STATUS_OPTIONS.map(option => (
                  <option key={option}>{option}</option>
                ))}
              </select>
              <ChevronDown size={14} />
            </div>
          </div>
          {hasFilters && (
            <button className="h-10 text-xs font-medium text-blue-700 hover:underline" onClick={clearFilters}>
              Limpar filtros
            </button>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[1140px] text-left">
            <thead>
              <tr>
                {['Empresa', 'Banco de dados', 'Servidor', 'Datacenter', 'Versão instalada', 'Status', 'Operações'].map(
                  label => (
                    <th key={label}>{label}</th>
                  )
                )}
              </tr>
            </thead>
            <tbody>
              {filteredRecords.map(record => (
                <tr
                  key={record.id}
                  className={`${record.id === highlightId ? 'row-new' : ''} ${
                    record.status === 'Atualizando...' ? 'row-running' : ''
                  }`}
                >
                  <td>
                    <div className="flex items-center gap-3">
                      <span className="client-avatar">{initials(record.company)}</span>
                      <div>
                        <span className="font-medium">{record.company}</span>
                        {!record.approved && (
                          <span className="ml-2 rounded bg-amber-100 px-1.5 py-0.5 text-[9px] font-bold text-amber-800">
                            AGUARDANDO APROVAÇÃO
                          </span>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="font-mono text-[11px] text-slate-600">{record.name}</td>
                  <td>
                    <span className="flex items-center gap-2 text-slate-500">
                      <Server size={13} className="text-slate-400" />
                      {record.server}
                    </span>
                  </td>
                  <td>
                    <span className="dc-dot" />
                    {record.datacenter}
                  </td>
                  <td>
                    <VersionBadge version={record.version} targetVersion={activeTarget} isCustom={isCustomScript} />
                  </td>
                  <td>
                    <div className="flex flex-col items-start gap-1">
                      <StatusBadge status={record.status} />
                      {record.status === 'Falha' && record.lastError && (
                        <span className="max-w-[220px] truncate text-[10px] text-red-600" title={record.lastError}>
                          {record.lastError}
                        </span>
                      )}
                    </div>
                  </td>
                  <td>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => onTestConnection(record)}
                        disabled={testingClientId === record.id}
                        className="flex h-7 w-7 items-center justify-center rounded-md border border-slate-200 bg-white text-slate-500 hover:border-[#103c6b] hover:text-[#103c6b]"
                        title={`Testar conexão SQL e ler versão em ${record.name}`}
                      >
                        {testingClientId === record.id ? (
                          <LoaderCircle size={13} className="animate-spin text-[#103c6b]" />
                        ) : (
                          <PlugZap size={13} />
                        )}
                      </button>
                      <button
                        type="button"
                        onClick={() => onEditCompany(record)}
                        className="flex h-7 w-7 items-center justify-center rounded-md border border-slate-200 bg-white text-slate-500 hover:border-[#103c6b] hover:text-[#103c6b]"
                        title={`Editar cadastro de ${record.company}`}
                      >
                        <Edit3 size={13} />
                      </button>
                      <RowAction
                        record={record}
                        activeTarget={activeTarget}
                        isCustomScript={isCustomScript}
                        onOpenOrchestrator={onOpenOrchestrator}
                      />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredRecords.length === 0 && (
            <div className="py-16 text-center">
              <Search className="mx-auto mb-3 text-slate-300" size={30} />
              <h3 className="font-medium">Nenhuma empresa encontrada</h3>
              <p className="mt-2 text-sm text-slate-500">Ajuste os filtros ou cadastre um novo cliente no catálogo.</p>
              {hasFilters && (
                <button onClick={clearFilters} className="mt-4 text-sm font-medium text-blue-700">
                  Limpar filtros
                </button>
              )}
            </div>
          )}
        </div>

        <footer className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 bg-[#fcfdfe] px-6 py-4 text-[11px] text-slate-500">
          <p aria-live="polite">
            Mostrando <strong className="font-medium text-slate-700">{filteredRecords.length}</strong> de{' '}
            <strong className="font-medium text-slate-700">{records.length}</strong> bancos cadastrados no{' '}
            <code className="font-mono text-[10.5px]">CentersysControle</code>
          </p>
          <span className="flex items-center gap-1.5 text-emerald-700 font-medium">
            <ShieldCheck size={14} /> Conectado ao Microsoft SQL Server (Bancos iniciados com "_" descartados automaticamente)
          </span>
        </footer>
      </section>
    </>
  );
}

function RowAction({
  record,
  activeTarget,
  isCustomScript,
  onOpenOrchestrator,
}: {
  record: DatabaseRecord;
  activeTarget: string;
  isCustomScript: boolean;
  onOpenOrchestrator: (ids: number[]) => void;
}) {
  if (!record.approved) {
    return <span className="text-[10px] font-medium text-amber-700">Pendente aprovação</span>;
  }
  if (record.status === 'Atualizando...') {
    return (
      <span className="inline-flex items-center gap-1.5 text-[11px] font-medium text-[#1662b3]">
        <LoaderCircle size={13} className="animate-spin" /> Em execução
      </span>
    );
  }
  if (record.status === 'Falha') {
    return (
      <button className="action-button subtle" onClick={() => onOpenOrchestrator([record.id])}>
        <Rocket size={13} /> Reprocessar
      </button>
    );
  }
  if (record.status === 'DESATUALIZADA') {
    return (
      <button className="action-button" onClick={() => onOpenOrchestrator([record.id])}>
        <Rocket size={13} /> Atualizar agora
      </button>
    );
  }
  if (record.status === 'Pendente' || isVersionBehind(record.version, activeTarget, isCustomScript)) {
    return (
      <button className="action-button subtle" onClick={() => onOpenOrchestrator([record.id])}>
        <ListChecks size={13} /> Orquestrar
      </button>
    );
  }
  return <span className="text-slate-300">—</span>;
}

/* -------------------------------------------------------------------------- */
/* Aba 2 — Orquestrador de atualizações                                        */
/* -------------------------------------------------------------------------- */

interface OrchestratorProps {
  records: DatabaseRecord[];
  availableVersions: VersaoDisponivelDto[];
  selectedIds: number[];
  setSelectedIds: Dispatch<SetStateAction<number[]>>;
  batchOrigin: Record<number, BatchOrigin>;
  progress: Record<number, number>;
  stages: Record<number, string>;
  isRunning: boolean;
  activeLoteId: number | null;
  logs: LogEntry[];
  onRequestStart: () => void;
  onCancelBatch: () => void;
  onClearLogs: () => void;
  onNewCompany: () => void;
  activeTarget: string;
  customScript: CustomScript | null;
  rowTargetVersions: Record<number, string>;
  rowCustomScripts: Record<number, CustomScript>;
  onRowTargetChange: (id: number, target: string) => void;
  onRowCustomScriptChange: (id: number, script: CustomScript | null) => void;
  setToast: (msg: string) => void;
}

function OrchestratorView({
  records,
  availableVersions,
  selectedIds,
  setSelectedIds,
  batchOrigin,
  progress,
  stages,
  isRunning,
  activeLoteId,
  logs,
  onRequestStart,
  onCancelBatch,
  onClearLogs,
  onNewCompany,
  activeTarget,
  customScript,
  rowTargetVersions,
  rowCustomScripts,
  onRowTargetChange,
  onRowCustomScriptChange,
  setToast,
}: OrchestratorProps) {
  const [focus, setFocus] = useState<QueueFocus>('Todos');

  const originStatus = useCallback(
    (record: DatabaseRecord) => batchOrigin[record.id]?.status ?? record.status,
    [batchOrigin]
  );

  const isEligible = useCallback(
    (r: DatabaseRecord) => {
      if (!r.approved) return false;
      const rowScript = rowCustomScripts[r.id];
      const rowTarget = rowScript ? rowScript.name : customScript ? customScript.name : rowTargetVersions[r.id] ?? activeTarget;
      const isRowCustom = Boolean(rowScript || customScript);
      return UPDATABLE.includes(r.status) || isVersionBehind(r.version, rowTarget, isRowCustom);
    },
    [rowCustomScripts, customScript, rowTargetVersions, activeTarget]
  );

  const queue = useMemo(
    () =>
      records
        .filter(r => isEligible(r) || r.id in batchOrigin)
        .filter(r => focus === 'Todos' || originStatus(r) === focus)
        .sort(
          (a, b) =>
            statusRank(originStatus(a)) - statusRank(originStatus(b)) ||
            compareVersions(batchOrigin[a.id]?.version ?? a.version, batchOrigin[b.id]?.version ?? b.version)
        ),
    [records, batchOrigin, focus, originStatus, isEligible]
  );

  const selectable = queue.filter(r => isEligible(r) && r.status !== 'Atualizando...');
  const allSelected = selectable.length > 0 && selectable.every(r => selectedIds.includes(r.id));
  const someSelected = selectable.some(r => selectedIds.includes(r.id));
  const validSelected = records.filter(r => selectedIds.includes(r.id) && isEligible(r) && r.status !== 'Atualizando...');
  const datacentersInvolved = new Set(validSelected.map(r => r.datacenter)).size;

  const eligibleCount = records.filter(isEligible).length;

  const batchIds = Object.keys(batchOrigin).map(Number);
  const overall = batchIds.length
    ? Math.round(batchIds.reduce((sum, id) => sum + (progress[id] ?? 0), 0) / batchIds.length)
    : 0;
  const doneCount = batchIds.filter(id => (progress[id] ?? 0) >= 100).length;

  const selectedTargets = useMemo(() => {
    return Array.from(
      new Set(
        validSelected.map(r => {
          const rowScript = rowCustomScripts[r.id];
          if (rowScript) return rowScript.name;
          if (customScript) return customScript.name;
          return rowTargetVersions[r.id] ?? activeTarget;
        })
      )
    );
  }, [validSelected, rowCustomScripts, customScript, rowTargetVersions, activeTarget]);

  const focusOptions: { key: QueueFocus; label: string; count: number }[] = [
    { key: 'Todos', label: 'Todos elegíveis', count: eligibleCount },
    { key: 'DESATUALIZADA', label: 'Desatualizadas', count: records.filter(r => r.status === 'DESATUALIZADA').length },
    { key: 'Pendente', label: 'Pendentes', count: records.filter(r => r.status === 'Pendente').length },
    { key: 'Falha', label: 'Com falha', count: records.filter(r => r.status === 'Falha').length },
  ];

  const toggle = (id: number) =>
    setSelectedIds(prev => (prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]));
  const toggleAll = () => {
    const ids = selectable.map(r => r.id);
    setSelectedIds(prev => (allSelected ? prev.filter(id => !ids.includes(id)) : Array.from(new Set([...prev, ...ids]))));
  };

  return (
    <>
      <div className="mb-8 flex flex-wrap items-center justify-between gap-5">
        <div>
          <div className="eyebrow mb-2">ORQUESTRADOR TRANSACIONAL T-SQL</div>
          <h1 className="text-[29px] font-semibold tracking-[-.8px]">Atualize em lote, com segurança real.</h1>
          <p className="mt-2 text-sm text-slate-500">
            Pré-varredura sintática com <code className="font-mono text-xs text-[#103c6b]">ScriptDom</code>, quebra segura de lotes <code className="font-mono text-xs text-[#103c6b]">GO</code>, idempotência SHA-256 e <code className="font-mono text-xs text-[#103c6b]">ROLLBACK</code> automático em falhas.
          </p>
        </div>
        <button className="ghost-button" onClick={onNewCompany}>
          <Plus size={15} /> Cadastrar Cliente / Banco
        </button>
      </div>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_340px]">
        {/* Fila de seleção */}
        <section className="overflow-hidden rounded-xl border border-slate-200 bg-white">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 px-6 py-5">
            <div className="flex items-center gap-3">
              <h2 className="text-base font-semibold">Fila de bancos elegíveis</h2>
              <span className="rounded-md bg-slate-100 px-2 py-1 text-[10px] font-medium text-slate-500">
                {eligibleCount} PARA ATUALIZAR
              </span>
            </div>
            <div className="flex flex-wrap gap-2">
              {focusOptions.map(option => (
                <button
                  key={option.key}
                  className={`chip ${focus === option.key ? 'chip-active' : ''}`}
                  onClick={() => setFocus(option.key)}
                >
                  {option.label} <b>{option.count}</b>
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between gap-3 px-6 py-3.5">
            <label className="check-label">
              <input
                type="checkbox"
                className="check"
                checked={allSelected}
                disabled={selectable.length === 0 || isRunning}
                ref={element => {
                  if (element) element.indeterminate = someSelected && !allSelected;
                }}
                onChange={toggleAll}
              />
              Selecionar todos <span className="font-normal text-slate-400">({selectable.length})</span>
            </label>
            {validSelected.length > 0 && !isRunning && (
              <button className="text-[11px] font-medium text-blue-700 hover:underline" onClick={() => setSelectedIds([])}>
                Limpar seleção
              </button>
            )}
          </div>

          <div className="overflow-x-auto">
            <table className="w-full min-w-[1060px] text-left">
              <thead>
                <tr>
                  <th className="w-[52px]">
                    <span className="sr-only">Selecionar</span>
                  </th>
                  {['Empresa / Banco', 'Servidor', 'Versão instalada', 'Versão alvo', 'Status', 'Progresso'].map(
                    label => (
                      <th key={label}>{label}</th>
                    )
                  )}
                </tr>
              </thead>
              <tbody>
                {queue.map(record => {
                  const origin = batchOrigin[record.id];
                  const running = record.status === 'Atualizando...';
                  const done = Boolean(origin) && record.status === 'Atualizado';
                  const failedInBatch = Boolean(origin) && record.status === 'Falha';
                  const canSelect = isEligible(record) && !running && !isRunning;
                  const checked = selectedIds.includes(record.id);
                  const value = progress[record.id] ?? 0;
                  const stage = stages[record.id] ?? (done ? 'Concluído' : failedInBatch ? 'Rollback aplicado' : 'Aguardando');

                  const rowScript = rowCustomScripts[record.id];
                  const effectiveCustomScript = rowScript ?? customScript;
                  const rowTarget = effectiveCustomScript
                    ? effectiveCustomScript.name
                    : rowTargetVersions[record.id] ?? activeTarget;
                  const isRowCustom = Boolean(effectiveCustomScript);
                  const scriptsCount = computePendingScriptsCount(record.version, rowTarget, availableVersions);

                  return (
                    <tr
                      key={record.id}
                      className={checked ? 'row-selected' : running ? 'row-running' : done ? 'row-done' : ''}
                    >
                      <td>
                        <input
                          type="checkbox"
                          className="check"
                          checked={checked}
                          disabled={!canSelect}
                          onChange={() => toggle(record.id)}
                          aria-label={`Selecionar ${record.company}`}
                        />
                      </td>
                      <td>
                        <div className="flex items-center gap-3">
                          <span className="client-avatar">{initials(record.company)}</span>
                          <div>
                            <p className="font-medium">{record.company}</p>
                            <p className="mt-0.5 font-mono text-[10.5px] text-slate-500">{record.name}</p>
                          </div>
                        </div>
                      </td>
                      <td>
                        <p className="flex items-center gap-2 text-slate-500">
                          <Server size={13} className="text-slate-400" />
                          {record.server}
                        </p>
                        <p className="mt-1 text-[10px] text-slate-400">{record.datacenter}</p>
                      </td>

                      <td>
                        <div className="flex items-center gap-2">
                          <VersionBadge version={record.version} targetVersion={rowTarget} isCustom={isRowCustom} />
                        </div>
                        {done && origin && (
                          <p className="mt-1 text-[10px] text-emerald-700">
                            atualizada de {formatVersionDisplay(origin.version)}
                          </p>
                        )}
                      </td>

                      <td className="w-[240px]">
                        {running || done ? (
                          <div className="flex items-center gap-1.5">
                            {isRowCustom ? (
                              <span
                                className="inline-flex items-center gap-1.5 rounded-md border border-emerald-300 bg-emerald-50 px-2.5 py-1 font-mono text-[11px] font-bold text-emerald-800"
                                title={rowTarget}
                              >
                                <FileCode size={13} className="shrink-0 text-emerald-600" />
                                <span className="max-w-[140px] truncate">{rowTarget}</span>
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 rounded-md border border-blue-200 bg-blue-50 px-2.5 py-1 font-mono text-[11px] font-bold text-[#103c6b]">
                                {rowTarget}
                              </span>
                            )}
                          </div>
                        ) : (
                          <div className="flex items-center gap-2">
                            {rowScript ? (
                              <div className="flex items-center gap-1">
                                <span
                                  className="inline-flex items-center gap-1.5 rounded-md border border-emerald-300 bg-emerald-50 px-2 py-1 font-mono text-[11px] font-bold text-emerald-800"
                                  title={`${rowScript.name} (${rowScript.size})`}
                                >
                                  <FileCode size={13} className="shrink-0 text-emerald-600" />
                                  <span className="max-w-[110px] truncate">{rowScript.name}</span>
                                </span>
                                <button
                                  type="button"
                                  onClick={() => {
                                    onRowCustomScriptChange(record.id, null);
                                    setToast(`Script individual removido de ${record.company}.`);
                                  }}
                                  className="flex h-7 w-7 items-center justify-center rounded text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                                  title="Remover script customizado desta linha"
                                >
                                  <X size={13} />
                                </button>
                              </div>
                            ) : customScript ? (
                              <span className="inline-flex items-center gap-1.5 rounded-md border border-emerald-300 bg-emerald-50 px-2 py-1 font-mono text-[11px] font-bold text-emerald-800">
                                <FileCode size={13} className="shrink-0 text-emerald-600" />
                                <span className="max-w-[125px] truncate">{customScript.name}</span>
                              </span>
                            ) : (
                              <div className="relative">
                                <select
                                  value={rowTargetVersions[record.id] ?? activeTarget}
                                  onChange={e => onRowTargetChange(record.id, e.target.value)}
                                  className="h-8 appearance-none rounded-md border border-slate-200 bg-white pl-2.5 pr-6 text-[11px] font-mono font-bold text-[#142a46] hover:border-[#103c6b] cursor-pointer"
                                  aria-label={`Versão alvo para ${record.company}`}
                                >
                                  {availableVersions.map(v => (
                                    <option key={v.versao} value={v.versao}>
                                      {v.versao}
                                    </option>
                                  ))}
                                </select>
                                <ChevronDown
                                  size={11}
                                  className="pointer-events-none absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400"
                                />
                              </div>
                            )}

                            <input
                              type="file"
                              accept=".sql"
                              id={`row-sql-${record.id}`}
                              className="hidden"
                              onChange={async e => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  const content = await file.text();
                                  const size = `${(file.size / 1024).toFixed(1)} KB`;
                                  onRowCustomScriptChange(record.id, { name: file.name, size, content });
                                  setToast(`Script "${file.name}" (${size}) vinculado a ${record.company}.`);
                                }
                                e.target.value = '';
                              }}
                            />
                            <button
                              type="button"
                              onClick={() => document.getElementById(`row-sql-${record.id}`)?.click()}
                              className={`flex h-8 w-8 items-center justify-center rounded-md border transition-all cursor-pointer ${
                                rowScript
                                  ? 'border-emerald-300 bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                                  : 'border-slate-200 bg-slate-50 text-slate-600 hover:border-[#103c6b] hover:bg-[#eef5fd] hover:text-[#103c6b]'
                              }`}
                              title={`Anexar script .sql exclusivo para ${record.company}`}
                            >
                              <Upload size={13} />
                            </button>
                          </div>
                        )}
                      </td>

                      <td>
                        <StatusBadge status={record.status} />
                      </td>
                      <td className="w-[220px]">
                        {running || done || failedInBatch ? (
                          <div className="w-[180px]">
                            <div className="mb-1.5 flex items-center justify-between text-[10px]">
                              <span
                                className={
                                  done
                                    ? 'font-semibold text-emerald-700'
                                    : failedInBatch
                                    ? 'font-semibold text-red-600'
                                    : 'text-[#1662b3]'
                                }
                              >
                                {stage}
                              </span>
                              <span className="font-mono font-bold text-slate-600">{value}%</span>
                            </div>
                            <ProgressBar value={value} />
                          </div>
                        ) : (
                          <span className="text-[11px] text-slate-400">
                            {isRowCustom ? '1 script .sql customizado' : `${scriptsCount} script(s) pendente(s)`}
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {queue.length === 0 && (
              <div className="py-16 text-center">
                <CheckCheck className="mx-auto mb-3 text-emerald-400" size={32} />
                <h3 className="font-medium">Nenhum banco pendente nesta visão</h3>
                <p className="mt-2 text-sm text-slate-500">
                  Toda a frota filtrada já está alinhada às respectivas versões alvo no SQL Server.
                </p>
                <button onClick={onNewCompany} className="mt-4 text-sm font-medium text-blue-700">
                  + Cadastrar novo banco de cliente
                </button>
              </div>
            )}
          </div>
        </section>

        {/* Painel de controle do lote */}
        <aside className="h-fit overflow-hidden rounded-xl border border-slate-200 bg-white lg:sticky lg:top-6">
          <div className="batch-panel-head px-6 py-6 text-white">
            <p className="text-[10px] font-bold tracking-[1.8px] text-blue-100/70">PAINEL DE CONTROLE DO LOTE</p>
            <p className="mt-4 text-[11px] text-blue-100/70">Versões alvo configuradas</p>
            {selectedTargets.length <= 1 ? (
              <p className="font-mono text-[26px] font-extrabold leading-tight tracking-tight break-all">
                {formatVersionDisplay(selectedTargets[0] ?? activeTarget)}
              </p>
            ) : (
              <div>
                <p className="font-mono text-[22px] font-extrabold leading-tight tracking-tight">Alvos individuais</p>
                <p className="mt-1 text-[11px] text-blue-100/80">
                  {selectedTargets.length} versões distintas selecionadas
                </p>
              </div>
            )}
            <span className="mt-3 inline-flex items-center gap-1.5 rounded-full border border-white/20 px-2.5 py-1 text-[10px] text-blue-100">
              <ShieldCheck size={12} /> SET XACT_ABORT ON + Transação por arquivo
            </span>
          </div>
          <div className="space-y-5 p-6">
            <div className="grid grid-cols-3 gap-2 text-center">
              {[
                { label: 'Selecionados', value: validSelected.length, strong: true },
                { label: 'Elegíveis', value: eligibleCount, strong: false },
                { label: 'Datacenters', value: datacentersInvolved, strong: false },
              ].map(item => (
                <div
                  key={item.label}
                  className={`rounded-lg border px-2 py-3 ${
                    item.strong ? 'border-[#bcd6f3] bg-[#eef5fd]' : 'border-slate-200 bg-slate-50'
                  }`}
                >
                  <p className={`text-[22px] font-semibold leading-none ${item.strong ? 'text-[#103c6b]' : 'text-slate-600'}`}>
                    {item.value.toString().padStart(2, '0')}
                  </p>
                  <p className="mt-1.5 text-[10px] text-slate-500">{item.label}</p>
                </div>
              ))}
            </div>

            <ul className="space-y-2.5">
              {[
                'Pré-varredura AST (ScriptDom) antes de rodar',
                'Lock atômico exclusivo por banco de dados',
                'Rollback imediato em erro SQL sem afetar demais clientes',
              ].map(item => (
                <li key={item} className="check-item">
                  <Check size={14} className="shrink-0 text-emerald-600" strokeWidth={2.6} />
                  {item}
                </li>
              ))}
            </ul>

            {batchIds.length > 0 && (
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3.5">
                <div className="mb-2 flex items-center justify-between text-[11px]">
                  <span className="font-medium text-slate-600">
                    {isRunning ? `Executando Lote #${activeLoteId ?? ''}` : `Último Lote #${activeLoteId ?? ''}`}
                  </span>
                  <span className="font-mono font-bold text-slate-700">
                    {doneCount}/{batchIds.length} · {overall}%
                  </span>
                </div>
                <ProgressBar value={overall} />
              </div>
            )}

            <button
              className="primary-button w-full"
              disabled={isRunning || validSelected.length === 0}
              onClick={onRequestStart}
            >
              {isRunning ? (
                <>
                  <LoaderCircle size={18} className="animate-spin" /> Executando no SQL Server...
                </>
              ) : (
                <>
                  <Play size={16} fill="currentColor" /> Iniciar Atualização
                  {validSelected.length > 0 && ` (${validSelected.length})`}
                </>
              )}
            </button>

            {isRunning && activeLoteId && (
              <button
                type="button"
                onClick={onCancelBatch}
                className="flex h-10 w-full items-center justify-center gap-2 rounded-lg border border-red-200 bg-red-50 text-xs font-semibold text-red-700 hover:bg-red-100"
              >
                <Square size={13} fill="currentColor" /> Cancelar Operação com Rollback Seguro
              </button>
            )}

            <p className="text-center text-[11px] leading-5 text-slate-400">
              {isRunning
                ? 'Acompanhe os logs reais gravados no SQL Server abaixo.'
                : validSelected.length === 0
                ? 'Selecione ao menos um banco na fila para habilitar o disparo.'
                : `${validSelected.length} banco(s) receberão os pacotes pendentes até suas versões alvo.`}
            </p>
          </div>
        </aside>
      </div>

      <LogConsole logs={logs} isRunning={isRunning} onClear={onClearLogs} />
    </>
  );
}

function LogConsole({ logs, isRunning, onClear }: { logs: LogEntry[]; isRunning: boolean; onClear: () => void }) {
  const bodyRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const element = bodyRef.current;
    if (element) element.scrollTop = element.scrollHeight;
  }, [logs]);

  return (
    <section className="terminal mt-6" aria-label="Console de logs da atualização">
      <header className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 px-5 py-3">
        <div className="flex items-center gap-3">
          <span className="flex gap-1.5">
            <i className="term-dot bg-[#ff5f57]" />
            <i className="term-dot bg-[#febc2e]" />
            <i className="term-dot bg-[#28c840]" />
          </span>
          <Terminal size={14} className="text-blue-200/70" />
          <span className="font-mono text-[12px] text-blue-100/80">
            centersys-orchestrator — auditoria SQL Server ao vivo (dbo.LogsEventos)
          </span>
        </div>
        <div className="flex items-center gap-4">
          <span className={`term-state ${isRunning ? 'live' : ''}`}>{isRunning ? 'EXECUTANDO' : 'OCIOSO'}</span>
          <button className="term-clear" onClick={onClear} disabled={logs.length === 0 || isRunning}>
            <Trash2 size={13} /> Limpar tela
          </button>
        </div>
      </header>
      <div
        ref={bodyRef}
        className="terminal-body h-[300px] overflow-y-auto px-5 py-4 font-mono text-[12px] leading-[1.9]"
        role="log"
        aria-live="polite"
      >
        {logs.length === 0 ? (
          <p className="text-blue-100/40">
            $ conectado a CentersysControle — aguardando disparo do lote... <span className="cursor-blink">▋</span>
          </p>
        ) : (
          logs.map(log => (
            <div key={log.id} className="flex flex-wrap gap-x-3">
              <span className="shrink-0 text-slate-500">{log.time}</span>
              <span className={`log-tag log-${log.level}`}>[{log.level}]</span>
              {log.db && <span className="shrink-0 text-sky-300/80">{log.db}</span>}
              <span
                className={
                  log.level === 'SUCCESS'
                    ? 'text-emerald-300'
                    : log.level === 'SYSTEM'
                    ? 'text-slate-400'
                    : log.level === 'WARN'
                    ? 'text-orange-300'
                    : 'text-slate-200'
                }
              >
                {log.message}
              </span>
            </div>
          ))
        )}
        {isRunning && logs.length > 0 && <span className="cursor-blink text-blue-200">▋</span>}
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------------- */
/* Aba 3 — Histórico, Agendamentos e Credenciais SQL                           */
/* -------------------------------------------------------------------------- */

interface OperationsTabProps {
  availableVersions: VersaoDisponivelDto[];
  datacentersList: string[];
  userRole: string;
  onLoadBatchLogs: (loteId: number) => void;
  setToast: (msg: string) => void;
}

function OperationsView({
  availableVersions,
  datacentersList,
  userRole,
  onLoadBatchLogs,
  setToast,
}: OperationsTabProps) {
  const [history, setHistory] = useState<HistoricoExecucaoResumoDto[]>([]);
  const [schedules, setSchedules] = useState<AgendamentoDto[]>([]);
  const [credentials, setCredentials] = useState<CredencialServidorDto[]>([]);
  const [loading, setLoading] = useState(true);

  const [schedDesc, setSchedDesc] = useState('');
  const [schedTarget, setSchedTarget] = useState(availableVersions[0]?.versao ?? DEFAULT_FALLBACK_VERSION);
  const [schedDc, setSchedDc] = useState('Todos');
  const [schedDate, setSchedDate] = useState('');

  const [credServer, setCredServer] = useState('SRV-SQL-01');
  const [credDc, setCredDc] = useState('Datacenter 111');
  const [credHost, setCredHost] = useState('(localdb)\\MSSQLLocalDB');
  const [credWinAuth, setCredWinAuth] = useState(true);
  const [credUser, setCredUser] = useState('');
  const [credPass, setCredPass] = useState('');
  const [testingCredId, setTestingCredId] = useState<number | null>(null);

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [histData, schedData] = await Promise.all([api.obterHistorico(25), api.listarAgendamentos()]);
      setHistory(histData);
      setSchedules(schedData);

      if (userRole === 'Admin') {
        const credData = await api.listarCredenciais();
        setCredentials(credData);
      }
    } catch (err) {
      setToast(err instanceof Error ? err.message : 'Erro ao carregar dados operacionais.');
    } finally {
      setLoading(false);
    }
  }, [userRole, setToast]);

  useEffect(() => {
    void loadAll();
  }, [loadAll]);

  const handleCreateSchedule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!schedDesc.trim() || !schedDate) {
      setToast('Preencha a descrição e a data/hora programada do agendamento.');
      return;
    }
    try {
      await api.criarAgendamento({
        descricao: schedDesc.trim(),
        versaoAlvo: schedTarget,
        datacenterEscopo: schedDc,
        dataHoraProgramada: new Date(schedDate).toISOString(),
      });
      setSchedDesc('');
      setSchedDate('');
      setToast('Agendamento persistido no SQL Server (dbo.Agendamentos).');
      await loadAll();
    } catch (err) {
      setToast(err instanceof Error ? err.message : 'Erro ao criar agendamento.');
    }
  };

  const handleCancelSchedule = async (id: number) => {
    try {
      await api.cancelarAgendamento(id);
      setToast(`Agendamento #${id} cancelado.`);
      await loadAll();
    } catch (err) {
      setToast(err instanceof Error ? err.message : 'Erro ao cancelar agendamento.');
    }
  };

  const handleSaveCredential = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.salvarCredencial({
        servidor: credServer,
        datacenter: credDc,
        hostInstancia: credHost,
        usarAutenticacaoWindows: credWinAuth,
        usuarioSql: credWinAuth ? undefined : credUser,
        senhaSql: credWinAuth ? undefined : credPass,
        trustServerCertificate: true,
      });
      setCredPass('');
      setToast(`Credencial do servidor ${credServer} salva com criptografia DataProtection.`);
      await loadAll();
    } catch (err) {
      setToast(err instanceof Error ? err.message : 'Erro ao salvar credencial.');
    }
  };

  const handleTestCredential = async (id: number) => {
    setTestingCredId(id);
    try {
      const res = await api.testarCredencialServidor(id);
      setToast(res.mensagem);
      await loadAll();
    } catch (err) {
      setToast(err instanceof Error ? err.message : 'Erro ao testar instância SQL.');
    } finally {
      setTestingCredId(null);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="eyebrow mb-2">AUDITORIA, AGENDAMENTO E CONECTIVIDADE</div>
          <h1 className="text-[29px] font-semibold tracking-[-.8px]">Histórico e Operações</h1>
          <p className="mt-2 text-sm text-slate-500">
            Consulte lotes anteriores, programe janelas automáticas de atualização e gerencie credenciais criptografadas por instância.
          </p>
        </div>
        <button className="ghost-button" onClick={() => void loadAll()} disabled={loading}>
          <RefreshCw size={14} className={loading ? 'animate-spin' : undefined} /> Atualizar painel
        </button>
      </div>

      {/* Histórico de Lotes */}
      <section className="overflow-hidden rounded-xl border border-slate-200 bg-white">
        <div className="flex items-center justify-between border-b border-slate-100 px-6 py-5">
          <div className="flex items-center gap-2.5">
            <History size={18} className="text-[#103c6b]" />
            <h2 className="text-base font-semibold">Histórico de Lotes Executados</h2>
            <span className="rounded-md bg-slate-100 px-2 py-1 text-[10px] font-medium text-slate-500">
              {history.length} REGISTROS
            </span>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[960px] text-left">
            <thead>
              <tr>
                {['Lote', 'Data / Hora', 'Disparado por', 'Origem', 'Resumo (Sucesso / Falha)', 'Bancos no Lote', 'Logs'].map(
                  h => (
                    <th key={h}>{h}</th>
                  )
                )}
              </tr>
            </thead>
            <tbody>
              {history.map(item => (
                <tr key={item.loteId}>
                  <td className="font-mono font-bold text-[#103c6b]">#{item.loteId}</td>
                  <td>{new Date(item.dataInicio).toLocaleString('pt-BR')}</td>
                  <td>{item.disparadoPor}</td>
                  <td>
                    <span className="rounded bg-slate-100 px-2 py-0.5 text-[10px] font-semibold text-slate-600">
                      {item.origem}
                    </span>
                  </td>
                  <td>
                    <span className="font-semibold text-emerald-700">{item.totalSucesso} OK</span>
                    {' · '}
                    <span className={item.totalFalha > 0 ? 'font-semibold text-red-600' : 'text-slate-400'}>
                      {item.totalFalha} falha(s)
                    </span>
                    {item.totalCancelado > 0 && ` · ${item.totalCancelado} cancelado(s)`}
                  </td>
                  <td>
                    <div className="flex flex-wrap gap-1.5 py-2">
                      {item.bancos.map(b => (
                        <span
                          key={`${item.loteId}-${b.id}`}
                          className={`rounded border px-2 py-0.5 font-mono text-[10px] ${
                            b.sucesso
                              ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
                              : 'border-red-200 bg-red-50 text-red-700'
                          }`}
                          title={b.mensagem ?? ''}
                        >
                          {b.nomeBanco}: {b.versaoAnterior} → {b.versaoAtual}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td>
                    <button
                      type="button"
                      className="action-button subtle"
                      onClick={() => onLoadBatchLogs(item.loteId)}
                    >
                      <Terminal size={12} /> Abrir no console
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {history.length === 0 && (
            <div className="py-12 text-center text-sm text-slate-500">Nenhum lote executado até o momento.</div>
          )}
        </div>
      </section>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Agendamentos Automáticos (GB-11) */}
        <section className="overflow-hidden rounded-xl border border-slate-200 bg-white p-6">
          <div className="mb-5 flex items-center gap-2.5">
            <CalendarClock size={18} className="text-[#103c6b]" />
            <div>
              <h2 className="text-base font-semibold">Agendamento Automático (Worker Interno)</h2>
              <p className="text-xs text-slate-500">Dispara atualizações automaticamente na janela configurada sem usar o Agendador do Windows.</p>
            </div>
          </div>

          <form onSubmit={handleCreateSchedule} className="mb-6 grid gap-3 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label htmlFor="sched-desc">Identificação da Janela</label>
              <div className="input-wrap compact">
                <input
                  id="sched-desc"
                  placeholder="Ex.: Janela Noturna Datacenter 111"
                  value={schedDesc}
                  onChange={e => setSchedDesc(e.target.value)}
                />
              </div>
            </div>
            <div>
              <label htmlFor="sched-ver">Versão Alvo</label>
              <div className="select-wrap">
                <select id="sched-ver" value={schedTarget} onChange={e => setSchedTarget(e.target.value)}>
                  {availableVersions.map(v => (
                    <option key={v.versao} value={v.versao}>
                      {v.versao}
                    </option>
                  ))}
                </select>
                <ChevronDown size={14} />
              </div>
            </div>
            <div>
              <label htmlFor="sched-dc">Escopo Datacenter</label>
              <div className="select-wrap">
                <select id="sched-dc" value={schedDc} onChange={e => setSchedDc(e.target.value)}>
                  <option value="Todos">Todos os datacenters</option>
                  {datacentersList.map(dc => (
                    <option key={dc} value={dc}>
                      {dc}
                    </option>
                  ))}
                </select>
                <ChevronDown size={14} />
              </div>
            </div>
            <div>
              <label htmlFor="sched-date">Data e Hora</label>
              <div className="input-wrap compact">
                <input
                  id="sched-date"
                  type="datetime-local"
                  value={schedDate}
                  onChange={e => setSchedDate(e.target.value)}
                />
              </div>
            </div>
            <div className="flex items-end">
              <button type="submit" className="primary-button sm w-full">
                <Plus size={14} /> Agendar Lote
              </button>
            </div>
          </form>

          <div className="space-y-2.5 max-h-[260px] overflow-y-auto">
            {schedules.map(ag => (
              <div
                key={ag.id}
                className="flex items-center justify-between gap-3 rounded-lg border border-slate-200 bg-slate-50/70 px-4 py-3 text-xs"
              >
                <div>
                  <p className="font-semibold text-slate-800">
                    {ag.descricao} · <span className="font-mono text-[#103c6b]">{ag.versaoAlvo}</span>
                  </p>
                  <p className="mt-0.5 text-[11px] text-slate-500">
                    Programado: {new Date(ag.dataHoraProgramada).toLocaleString('pt-BR')} · Escopo: {ag.datacenterEscopo ?? 'Todos'}
                  </p>
                  {ag.mensagemResultado && <p className="mt-1 text-[11px] text-emerald-700">{ag.mensagemResultado}</p>}
                </div>
                <div className="flex items-center gap-2">
                  <span className="rounded bg-white px-2 py-1 text-[10px] font-bold border border-slate-200">
                    {ag.status}
                  </span>
                  {ag.status === 'Pendente' && (
                    <button
                      type="button"
                      onClick={() => void handleCancelSchedule(ag.id)}
                      className="text-red-600 hover:underline text-[11px]"
                    >
                      Cancelar
                    </button>
                  )}
                </div>
              </div>
            ))}
            {schedules.length === 0 && (
              <p className="py-4 text-center text-xs text-slate-400">Nenhum agendamento cadastrado.</p>
            )}
          </div>
        </section>

        {/* Credenciais de Servidores SQL (GB-12) */}
        <section className="overflow-hidden rounded-xl border border-slate-200 bg-white p-6">
          <div className="mb-5 flex items-center gap-2.5">
            <KeyRound size={18} className="text-[#103c6b]" />
            <div>
              <h2 className="text-base font-semibold">Credenciais de Instâncias SQL Server</h2>
              <p className="text-xs text-slate-500">Senhas protegidas com criptografia simétrica DataProtection (nunca expostas em texto claro).</p>
            </div>
          </div>

          <form onSubmit={handleSaveCredential} className="mb-6 grid gap-3 sm:grid-cols-2">
            <div>
              <label htmlFor="cred-srv">Identificador Servidor</label>
              <div className="select-wrap">
                <select id="cred-srv" value={credServer} onChange={e => setCredServer(e.target.value)}>
                  {DEFAULT_SERVERS.map(s => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
                <ChevronDown size={14} />
              </div>
            </div>
            <div>
              <label htmlFor="cred-dc">Datacenter</label>
              <div className="select-wrap">
                <select id="cred-dc" value={credDc} onChange={e => setCredDc(e.target.value)}>
                  {DEFAULT_DATACENTERS.map(d => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
                <ChevronDown size={14} />
              </div>
            </div>
            <div className="sm:col-span-2">
              <label htmlFor="cred-host">Host / Instância SQL Server</label>
              <div className="input-wrap compact">
                <input
                  id="cred-host"
                  value={credHost}
                  onChange={e => setCredHost(e.target.value)}
                  placeholder="(localdb)\MSSQLLocalDB ou IP\INSTANCIA"
                />
              </div>
            </div>
            <div className="sm:col-span-2">
              <label className="check-label">
                <input
                  type="checkbox"
                  className="check"
                  checked={credWinAuth}
                  onChange={e => setCredWinAuth(e.target.checked)}
                />
                Usar Autenticação Integrada do Windows (Trusted_Connection)
              </label>
            </div>
            {!credWinAuth && (
              <>
                <div>
                  <label htmlFor="cred-user">Usuário SQL</label>
                  <div className="input-wrap compact">
                    <input id="cred-user" value={credUser} onChange={e => setCredUser(e.target.value)} placeholder="usr_orquestrador" />
                  </div>
                </div>
                <div>
                  <label htmlFor="cred-pass">Senha SQL (Criptografada ao salvar)</label>
                  <div className="input-wrap compact">
                    <input id="cred-pass" type="password" value={credPass} onChange={e => setCredPass(e.target.value)} placeholder="••••••••" />
                  </div>
                </div>
              </>
            )}
            <div className="sm:col-span-2">
              <button type="submit" className="primary-button sm w-full">
                <ShieldCheck size={14} /> Salvar Credencial Segura
              </button>
            </div>
          </form>

          <div className="space-y-2 max-h-[220px] overflow-y-auto">
            {credentials.map(c => (
              <div
                key={c.id}
                className="flex items-center justify-between gap-3 rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-xs"
              >
                <div className="min-w-0">
                  <p className="font-semibold text-slate-800">
                    {c.servidor} <span className="font-normal text-slate-400">({c.datacenter})</span> →{' '}
                    <code className="font-mono text-[11px] text-[#103c6b]">{c.hostInstancia}</code>
                  </p>
                  <p className="truncate text-[10.5px] text-slate-500">
                    {c.usarAutenticacaoWindows
                      ? 'Windows Auth'
                      : `SQL Auth (${c.usuarioSql}) · Senha cifrada: ${c.possuiSenhaConfigurada ? 'Sim' : 'Não'}`}
                    {c.mensagemStatusConexao ? ` · ${c.mensagemStatusConexao}` : ''}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => void handleTestCredential(c.id)}
                  disabled={testingCredId === c.id}
                  className="action-button subtle shrink-0"
                >
                  {testingCredId === c.id ? <LoaderCircle size={12} className="animate-spin" /> : <Activity size={12} />} Testar
                </button>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* Modais (Cadastro/Edição de Cliente, Confirmação de Lote e Pacotes)          */
/* -------------------------------------------------------------------------- */

interface CompanyModalProps {
  mode: 'create' | 'edit';
  initialRecord?: DatabaseRecord | null;
  existingCompanies: string[];
  existingDatabases: string[];
  onClose: () => void;
  onSaveCreate: (payload: {
    company: string;
    name: string;
    server: string;
    datacenter: string;
    version: string;
    createPhysicalDb: boolean;
  }) => Promise<void>;
  onSaveEdit: (id: number, payload: { company: string; server: string; datacenter: string; approved: boolean }) => Promise<void>;
}

function CompanyModal({
  mode,
  initialRecord,
  existingCompanies,
  existingDatabases,
  onClose,
  onSaveCreate,
  onSaveEdit,
}: CompanyModalProps) {
  const [company, setCompany] = useState(initialRecord?.company ?? '');
  const [database, setDatabase] = useState(initialRecord?.name ?? '');
  const [databaseEdited, setDatabaseEdited] = useState(mode === 'edit');
  const [server, setServer] = useState(initialRecord?.server ?? DEFAULT_SERVERS[0]);
  const [datacenter, setDatacenter] = useState(initialRecord?.datacenter ?? DEFAULT_DATACENTERS[0]);
  const [version, setVersion] = useState(initialRecord?.version ?? LEGACY_VERSIONS[0]);
  const [approved, setApproved] = useState(initialRecord?.approved ?? true);
  const [createPhysicalDb, setCreatePhysicalDb] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const firstFieldRef = useRef<HTMLInputElement>(null);

  const databaseName = mode === 'edit' ? database : databaseEdited ? database : suggestDatabaseName(company);

  useEffect(() => {
    firstFieldRef.current?.focus();
  }, []);

  const randomize = () => {
    const pool = SAMPLE_COMPANIES.filter(
      name => !existingCompanies.some(existing => normalize(existing) === normalize(name))
    );
    setCompany(pick(pool.length ? pool : SAMPLE_COMPANIES));
    setDatabaseEdited(false);
    setServer(pick(DEFAULT_SERVERS));
    setDatacenter(pick(DEFAULT_DATACENTERS));
    setVersion(pick(LEGACY_VERSIONS));
    setError('');
  };

  const submit = async () => {
    const name = company.trim();
    const db = databaseName.trim();
    if (!name) {
      setError('Informe o nome da empresa.');
      return;
    }

    setSubmitting(true);
    setError('');
    try {
      if (mode === 'edit' && initialRecord) {
        await onSaveEdit(initialRecord.id, { company: name, server, datacenter, approved });
      } else {
        if (!/^[A-Za-z0-9_]+$/.test(db)) {
          setError('Nome do banco inválido: use apenas letras, números e "_".');
          setSubmitting(false);
          return;
        }
        if (db.startsWith('_')) {
          setError('Bancos ativos não podem iniciar com "_" (convenção de bancos inativos da CenterSys).');
          setSubmitting(false);
          return;
        }
        if (existingDatabases.some(existing => existing.toLowerCase() === db.toLowerCase())) {
          setError(`O banco ${db} já está cadastrado.`);
          setSubmitting(false);
          return;
        }
        await onSaveCreate({ company: name, name: db, server, datacenter, version, createPhysicalDb });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Falha ao salvar no SQL Server.');
      setSubmitting(false);
    }
  };

  return (
    <div
      className="modal-backdrop"
      onMouseDown={event => {
        if (event.target === event.currentTarget && !submitting) onClose();
      }}
    >
      <div role="dialog" aria-modal="true" className="modal-card w-full max-w-[540px] overflow-hidden rounded-2xl bg-white shadow-2xl">
        <header className="flex items-start justify-between gap-4 border-b border-slate-100 px-6 py-5">
          <div className="flex items-center gap-3">
            <span className="stat-icon blue">
              <Building2 size={18} />
            </span>
            <div>
              <h2 className="text-base font-semibold">
                {mode === 'edit' ? 'Editar Cadastro do Cliente' : 'Cadastrar Cliente / Banco SQL Server'}
              </h2>
              <p className="mt-0.5 text-xs text-slate-500">
                {mode === 'edit'
                  ? 'Atualiza os metadados e aprovação do banco no catálogo central.'
                  : 'Registra no CentersysControle e cria o banco físico com dbo.Log_Acesso na instância.'}
              </p>
            </div>
          </div>
          <button
            aria-label="Fechar"
            onClick={onClose}
            disabled={submitting}
            className="icon-button rounded-md text-slate-400 hover:bg-slate-100 hover:text-slate-600"
          >
            <X size={18} />
          </button>
        </header>

        <form
          className="space-y-4 px-6 py-5"
          onSubmit={event => {
            event.preventDefault();
            void submit();
          }}
        >
          <div>
            <label htmlFor="nc-company">Empresa</label>
            <div className="input-wrap compact">
              <Building2 size={16} />
              <input
                ref={firstFieldRef}
                id="nc-company"
                placeholder="Ex.: Grupo Horizonte"
                value={company}
                onChange={event => {
                  setCompany(event.target.value);
                  setError('');
                }}
              />
            </div>
          </div>
          <div>
            <label htmlFor="nc-db">Banco de dados no SQL Server</label>
            <div className="input-wrap compact">
              <Database size={16} />
              <input
                id="nc-db"
                className="mono-input"
                placeholder="DB_Empresa_Prod"
                disabled={mode === 'edit'}
                value={databaseName}
                onChange={event => {
                  setDatabase(event.target.value);
                  setDatabaseEdited(true);
                  setError('');
                }}
              />
            </div>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="nc-server">Servidor</label>
              <div className="select-wrap">
                <Server size={15} />
                <select id="nc-server" value={server} onChange={event => setServer(event.target.value)}>
                  {DEFAULT_SERVERS.map(item => (
                    <option key={item}>{item}</option>
                  ))}
                </select>
                <ChevronDown size={14} />
              </div>
            </div>
            <div>
              <label htmlFor="nc-dc">Datacenter</label>
              <div className="select-wrap">
                <Server size={15} />
                <select id="nc-dc" value={datacenter} onChange={event => setDatacenter(event.target.value)}>
                  {DEFAULT_DATACENTERS.map(item => (
                    <option key={item}>{item}</option>
                  ))}
                </select>
                <ChevronDown size={14} />
              </div>
            </div>
          </div>

          {mode === 'create' ? (
            <>
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label htmlFor="nc-version">Versão inicial em dbo.Log_Acesso</label>
                  <div className="select-wrap">
                    <ArrowUpRight size={15} />
                    <select id="nc-version" value={version} onChange={event => setVersion(event.target.value)}>
                      {LEGACY_VERSIONS.map(item => (
                        <option key={item} value={item}>
                          v{item}
                        </option>
                      ))}
                    </select>
                    <ChevronDown size={14} />
                  </div>
                </div>
                <div>
                  <span className="mb-[9px] block text-[12px] font-semibold">Status inicial</span>
                  <div className="flex h-10 items-center">
                    <StatusBadge status="DESATUALIZADA" />
                  </div>
                </div>
              </div>
              <label className="check-label">
                <input
                  type="checkbox"
                  className="check"
                  checked={createPhysicalDb}
                  onChange={e => setCreatePhysicalDb(e.target.checked)}
                />
                Criar banco físico e tabela <code className="font-mono text-xs">dbo.Log_Acesso</code> caso ainda não existam na instância
              </label>
            </>
          ) : (
            <label className="check-label">
              <input type="checkbox" className="check" checked={approved} onChange={e => setApproved(e.target.checked)} />
              Banco aprovado para receber pacotes de atualização no orquestrador
            </label>
          )}

          {error && (
            <p className="flex items-center gap-2 rounded-md bg-red-50 px-3 py-2 text-xs text-red-700" role="alert">
              <TriangleAlert size={14} />
              {error}
            </p>
          )}
          <footer className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-5">
            {mode === 'create' ? (
              <button type="button" className="ghost-button" onClick={randomize} disabled={submitting}>
                <Shuffle size={14} /> Preencher exemplo
              </button>
            ) : (
              <span />
            )}
            <div className="flex gap-2">
              <button type="button" className="ghost-button" onClick={onClose} disabled={submitting}>
                Cancelar
              </button>
              <button type="submit" className="primary-button sm" disabled={submitting}>
                {submitting ? <LoaderCircle size={15} className="animate-spin" /> : <Check size={15} />}
                {mode === 'edit' ? 'Salvar alterações' : 'Cadastrar no SQL Server'}
              </button>
            </div>
          </footer>
        </form>
      </div>
    </div>
  );
}

function ConfirmBatchModal({
  items,
  allowNonTransactional,
  setAllowNonTransactional,
  onConfirm,
  onClose,
}: {
  items: { company: string; dbName: string; currentVersion: string; target: string }[];
  allowNonTransactional: boolean;
  setAllowNonTransactional: (v: boolean) => void;
  onConfirm: () => void;
  onClose: () => void;
}) {
  return (
    <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && onClose()}>
      <div role="dialog" aria-modal="true" className="modal-card w-full max-w-[560px] overflow-hidden rounded-2xl bg-white shadow-2xl">
        <header className="flex items-start justify-between gap-4 border-b border-slate-100 px-6 py-5">
          <div className="flex items-center gap-3">
            <span className="stat-icon amber">
              <ShieldAlert size={18} />
            </span>
            <div>
              <h2 className="text-base font-semibold">Confirmar Execução de Atualização SQL</h2>
              <p className="mt-0.5 text-xs text-slate-500">
                Revise os bancos e versões alvo antes de abrir transações no SQL Server.
              </p>
            </div>
          </div>
          <button onClick={onClose} className="icon-button rounded-md text-slate-400 hover:bg-slate-100">
            <X size={18} />
          </button>
        </header>
        <div className="space-y-4 px-6 py-5">
          <div className="max-h-[220px] space-y-2 overflow-y-auto rounded-lg border border-slate-200 bg-slate-50 p-3">
            {items.map(it => (
              <div key={it.dbName} className="flex items-center justify-between text-xs">
                <div>
                  <strong className="text-slate-800">{it.company}</strong>{' '}
                  <span className="font-mono text-[11px] text-slate-500">({it.dbName})</span>
                </div>
                <span className="font-mono font-bold text-[#103c6b]">
                  {formatVersionDisplay(it.currentVersion)} → {formatVersionDisplay(it.target)}
                </span>
              </div>
            ))}
          </div>

          <label className="check-label">
            <input
              type="checkbox"
              className="check"
              checked={allowNonTransactional}
              onChange={e => setAllowNonTransactional(e.target.checked)}
            />
            Permitir execução caso o script contenha comandos não transacionais (ex.: ALTER DATABASE / FULLTEXT)
          </label>

          <footer className="flex justify-end gap-2 border-t border-slate-100 pt-4">
            <button type="button" className="ghost-button" onClick={onClose}>
              Revisar seleção
            </button>
            <button type="button" className="primary-button sm" onClick={onConfirm}>
              <Rocket size={14} /> Confirmar e Executar ({items.length})
            </button>
          </footer>
        </div>
      </div>
    </div>
  );
}

function VersionDetailsModal({
  versionPkg,
  onClose,
}: {
  versionPkg: VersaoDisponivelDto;
  onClose: () => void;
}) {
  return (
    <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && onClose()}>
      <div role="dialog" aria-modal="true" className="modal-card w-full max-w-[620px] overflow-hidden rounded-2xl bg-white shadow-2xl">
        <header className="flex items-start justify-between gap-4 border-b border-slate-100 px-6 py-5">
          <div>
            <h2 className="text-base font-semibold">
              Detalhes do Pacote <span className="font-mono text-[#103c6b]">{versionPkg.versao}</span>
            </h2>
            <p className="mt-0.5 text-xs text-slate-500">
              Origem: {versionPkg.origem} · {versionPkg.quantidadeScripts} arquivo(s) .sql ordenados (scriptVersao.sql sempre por último)
            </p>
          </div>
          <button onClick={onClose} className="icon-button rounded-md text-slate-400 hover:bg-slate-100">
            <X size={18} />
          </button>
        </header>
        <div className="space-y-3 px-6 py-5 max-h-[400px] overflow-y-auto">
          {versionPkg.arquivos.map(arq => (
            <div key={arq.id} className="rounded-lg border border-slate-200 bg-slate-50 p-3.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-mono font-bold text-slate-800">
                  #{arq.ordemExecucao} · {arq.nomeArquivo}
                </span>
                <span className="rounded bg-blue-100 px-2 py-0.5 font-mono text-[10px] font-bold text-[#103c6b]">
                  {arq.quantidadeLotesGo} lote(s) GO
                </span>
              </div>
              <p className="mt-1.5 font-mono text-[10.5px] text-slate-500 break-all">SHA-256: {arq.hashSha256}</p>
              {arq.avisosValidacao && (
                <p className="mt-1 text-[11px] text-amber-700">{arq.avisosValidacao}</p>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function NewVersionPackageModal({
  onClose,
  onCreated,
}: {
  onClose: () => void;
  onCreated: (v: VersaoDisponivelDto) => void;
}) {
  const [numeroVersao, setNumeroVersao] = useState('V4.49.0.0');
  const [descricao, setDescricao] = useState('');
  const [definirComoPadrao, setDefinirComoPadrao] = useState(false);
  const [files, setFiles] = useState<{ nomeArquivo: string; conteudoSql: string }[]>([]);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const handleFilesSelected = async (e: ChangeEvent<HTMLInputElement>) => {
    const selected = Array.from(e.target.files ?? []);
    const loaded: { nomeArquivo: string; conteudoSql: string }[] = [];
    for (const f of selected) {
      loaded.push({ nomeArquivo: f.name, conteudoSql: await f.text() });
    }
    setFiles(prev => [...prev, ...loaded]);
    e.target.value = '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (files.length === 0) {
      setError('Anexe ao menos um arquivo .sql para compor o pacote.');
      return;
    }
    setSaving(true);
    setError('');
    try {
      const created = await api.cadastrarPacoteVersao({
        numeroVersao,
        descricao,
        definirComoPadrao,
        arquivos: files,
      });
      onCreated(created);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao validar/cadastrar pacote.');
      setSaving(false);
    }
  };

  return (
    <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && !saving && onClose()}>
      <div role="dialog" aria-modal="true" className="modal-card w-full max-w-[540px] overflow-hidden rounded-2xl bg-white shadow-2xl">
        <header className="flex items-start justify-between gap-4 border-b border-slate-100 px-6 py-5">
          <div>
            <h2 className="text-base font-semibold">Cadastrar Novo Pacote de Versão</h2>
            <p className="mt-0.5 text-xs text-slate-500">
              Os scripts passam por validação sintática com ScriptDom antes de entrarem no catálogo.
            </p>
          </div>
          <button onClick={onClose} className="icon-button rounded-md text-slate-400 hover:bg-slate-100">
            <X size={18} />
          </button>
        </header>
        <form onSubmit={handleSubmit} className="space-y-4 px-6 py-5">
          <div>
            <label htmlFor="pkg-ver">Número da Versão (4+ segmentos)</label>
            <div className="input-wrap compact">
              <input
                id="pkg-ver"
                className="mono-input"
                value={numeroVersao}
                onChange={e => setNumeroVersao(e.target.value)}
                placeholder="V4.49.0.0"
              />
            </div>
          </div>
          <div>
            <label htmlFor="pkg-desc">Descrição da Release</label>
            <div className="input-wrap compact">
              <input
                id="pkg-desc"
                value={descricao}
                onChange={e => setDescricao(e.target.value)}
                placeholder="Ex.: Ajustes fiscais e novos índices"
              />
            </div>
          </div>
          <div>
            <label>Arquivos SQL do Pacote</label>
            <input type="file" accept=".sql" multiple onChange={handleFilesSelected} className="text-xs" />
            {files.length > 0 && (
              <ul className="mt-2 space-y-1 rounded border border-slate-200 bg-slate-50 p-2.5 text-xs font-mono">
                {files.map((f, idx) => (
                  <li key={`${f.nomeArquivo}-${idx}`} className="flex items-center justify-between">
                    <span>{f.nomeArquivo}</span>
                    <button
                      type="button"
                      className="text-red-600"
                      onClick={() => setFiles(prev => prev.filter((_, i) => i !== idx))}
                    >
                      remover
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
          <label className="check-label">
            <input
              type="checkbox"
              className="check"
              checked={definirComoPadrao}
              onChange={e => setDefinirComoPadrao(e.target.checked)}
            />
            Definir como nova versão alvo padrão do sistema
          </label>
          {error && <p className="rounded bg-red-50 px-3 py-2 text-xs text-red-700">{error}</p>}
          <footer className="flex justify-end gap-2 border-t border-slate-100 pt-4">
            <button type="button" className="ghost-button" onClick={onClose}>
              Cancelar
            </button>
            <button type="submit" className="primary-button sm" disabled={saving}>
              {saving ? <LoaderCircle size={14} className="animate-spin" /> : <Upload size={14} />} Validar e Cadastrar
            </button>
          </footer>
        </form>
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/* Componente principal — Estado Real Conectado à API .NET + SQL Server        */
/* -------------------------------------------------------------------------- */

export default function App() {
  const [user, setUser] = useState<UsuarioInfo | null>(() => getStoredUser());
  const [emailInput, setEmailInput] = useState('admin@centersys.com.br');
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [records, setRecords] = useState<DatabaseRecord[]>([]);
  const [availableVersions, setAvailableVersions] = useState<VersaoDisponivelDto[]>([]);
  const [targetVersion, setTargetVersion] = useState<string>(DEFAULT_FALLBACK_VERSION);
  const [customScript, setCustomScript] = useState<CustomScript | null>(null);
  const [rowTargetVersions, setRowTargetVersions] = useState<Record<number, string>>({});
  const [rowCustomScripts, setRowCustomScripts] = useState<Record<number, CustomScript>>({});

  const [isSyncing, setIsSyncing] = useState(false);
  const [apiErrorBanner, setApiErrorBanner] = useState<string | null>(null);
  const [testingClientId, setTestingClientId] = useState<number | null>(null);

  const [datacenter, setDatacenter] = useState<DatacenterFilter>('Todos');
  const [status, setStatus] = useState<StatusFilter>('Todos');
  const [search, setSearch] = useState('');
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [batchOrigin, setBatchOrigin] = useState<Record<number, BatchOrigin>>({});
  const [progress, setProgress] = useState<Record<number, number>>({});
  const [stages, setStages] = useState<Record<number, string>>({});
  const [isRunning, setIsRunning] = useState(false);
  const [activeLoteId, setActiveLoteId] = useState<number | null>(null);
  const [logs, setLogs] = useState<LogEntry[]>([]);

  const [companyModalState, setCompanyModalState] = useState<{
    open: boolean;
    mode: 'create' | 'edit';
    record?: DatabaseRecord | null;
  }>({ open: false, mode: 'create', record: null });
  const [showConfirmBatch, setShowConfirmBatch] = useState(false);
  const [allowNonTransactional, setAllowNonTransactional] = useState(false);
  const [showVersionDetails, setShowVersionDetails] = useState(false);
  const [showNewVersionModal, setShowNewVersionModal] = useState(false);

  const [toast, setToast] = useState<string | null>(null);
  const [highlightId, setHighlightId] = useState<number | null>(null);
  const pollTimerRef = useRef<number | null>(null);

  const loggedIn = Boolean(user && getStoredToken());
  const activeTarget = customScript ? customScript.name : targetVersion;
  const isCustomScript = Boolean(customScript);

  const stopPolling = useCallback(() => {
    if (pollTimerRef.current !== null) {
      window.clearInterval(pollTimerRef.current);
      pollTimerRef.current = null;
    }
  }, []);

  useEffect(() => () => stopPolling(), [stopPolling]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 4200);
    return () => window.clearTimeout(timer);
  }, [toast]);

  useEffect(() => {
    if (highlightId === null) return;
    const timer = window.setTimeout(() => setHighlightId(null), 2800);
    return () => window.clearTimeout(timer);
  }, [highlightId]);

  const loadInitialData = useCallback(async (sincronizar = true) => {
    setIsSyncing(true);
    setApiErrorBanner(null);
    try {
      const [versoesData, clientesData, logsRecentes] = await Promise.all([
        api.listarVersoes(),
        api.listarClientes(sincronizar),
        api.obterLogs(),
      ]);

      setAvailableVersions(versoesData);
      const padraoApi = versoesData.find(v => v.padrao)?.versao ?? versoesData[0]?.versao ?? DEFAULT_FALLBACK_VERSION;
      setTargetVersion(prev => (versoesData.some(v => v.versao === prev) ? prev : padraoApi));

      const mapped = clientesData.map(mapDtoToRecord);
      setRecords(mapped);

      setRowTargetVersions(prev => {
        const next = { ...prev };
        mapped.forEach(r => {
          if (!next[r.id]) next[r.id] = padraoApi;
        });
        return next;
      });

      if (logsRecentes.length > 0) {
        setLogs(
          logsRecentes.map(l => ({
            id: l.id,
            time: l.time,
            level: l.level,
            db: l.db ?? undefined,
            message: l.message,
          }))
        );
      }
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        setUser(null);
        setLoginError('Sessão expirada. Faça login novamente.');
      } else {
        setApiErrorBanner(
          err instanceof Error ? err.message : 'Não foi possível comunicar com a API do Orquestrador.'
        );
      }
    } finally {
      setIsSyncing(false);
    }
  }, []);

  useEffect(() => {
    if (loggedIn) {
      void loadInitialData(true);
    }
  }, [loggedIn, loadInitialData]);

  const datacentersList = useMemo(() => {
    const set = new Set<string>(DEFAULT_DATACENTERS);
    records.forEach(r => set.add(r.datacenter));
    return Array.from(set);
  }, [records]);

  const filteredRecords = useMemo(
    () =>
      records.filter(
        record =>
          (datacenter === 'Todos' || record.datacenter === datacenter) &&
          (status === 'Todos' || record.status === status) &&
          normalize(`${record.company} ${record.name} ${record.server}`).includes(normalize(search))
      ),
    [records, datacenter, status, search]
  );

  const eligibleCount = useMemo(
    () =>
      records.filter(r => {
        if (!r.approved) return false;
        const rowScript = rowCustomScripts[r.id];
        const rowTarget = rowScript ? rowScript.name : customScript ? customScript.name : rowTargetVersions[r.id] ?? activeTarget;
        const isRowCustom = Boolean(rowScript || customScript);
        return UPDATABLE.includes(r.status) || isVersionBehind(r.version, rowTarget, isRowCustom);
      }).length,
    [records, rowCustomScripts, customScript, rowTargetVersions, activeTarget]
  );

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setIsLoggingIn(true);
    try {
      const res = await api.login(emailInput, passwordInput);
      saveAuthSession(res.token, res.usuario);
      setUser(res.usuario);
      setPasswordInput('');
    } catch (err) {
      setLoginError(err instanceof Error ? err.message : 'Falha ao autenticar na API.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = () => {
    stopPolling();
    clearAuthSession();
    setUser(null);
    setIsRunning(false);
    setActiveTab('dashboard');
    setSelectedIds([]);
  };

  const clearFilters = () => {
    setDatacenter('Todos');
    setStatus('Todos');
    setSearch('');
  };

  const openOrchestrator = (ids: number[]) => {
    setSelectedIds(ids);
    setActiveTab('orchestrator');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleTestConnection = async (record: DatabaseRecord) => {
    setTestingClientId(record.id);
    try {
      const res = await api.testarConexaoCliente(record.id);
      setToast(res.mensagem);
      await loadInitialData(false);
    } catch (err) {
      setToast(err instanceof Error ? err.message : 'Erro ao testar conexão SQL.');
    } finally {
      setTestingClientId(null);
    }
  };

  const handleCreateCompany = async (payload: {
    company: string;
    name: string;
    server: string;
    datacenter: string;
    version: string;
    createPhysicalDb: boolean;
  }) => {
    const created = await api.cadastrarCliente({
      nomeEmpresa: payload.company,
      nomeBanco: payload.name,
      servidor: payload.server,
      datacenter: payload.datacenter,
      versaoInicial: payload.version,
      criarBancoFisicoSeNaoExistir: payload.createPhysicalDb,
    });
    const record = mapDtoToRecord(created);
    setRecords(prev => [...prev, record]);
    setRowTargetVersions(prev => ({ ...prev, [record.id]: targetVersion }));
    if (activeTab === 'orchestrator') setSelectedIds(prev => [...prev, record.id]);
    setHighlightId(record.id);
    setCompanyModalState({ open: false, mode: 'create', record: null });
    setToast(`${record.company} (${record.name}) criado e validado no SQL Server!`);
  };

  const handleEditCompany = async (
    id: number,
    payload: { company: string; server: string; datacenter: string; approved: boolean }
  ) => {
    await api.editarCliente(id, {
      nomeEmpresa: payload.company,
      servidor: payload.server,
      datacenter: payload.datacenter,
      aprovado: payload.approved,
    });
    setCompanyModalState({ open: false, mode: 'create', record: null });
    setToast('Cadastro do cliente atualizado no Banco Central.');
    await loadInitialData(false);
  };

  const executeBatch = async () => {
    setShowConfirmBatch(false);
    if (isRunning) return;

    const batch = records.filter(r => selectedIds.includes(r.id) && r.approved);
    if (batch.length === 0) return;

    const origins: Record<number, BatchOrigin> = {};
    const initialProg: Record<number, number> = {};
    const initialStages: Record<number, string> = {};
    batch.forEach(r => {
      origins[r.id] = { status: r.status, version: r.version };
      initialProg[r.id] = 5;
      initialStages[r.id] = 'Enfileirado';
    });

    setBatchOrigin(origins);
    setProgress(initialProg);
    setStages(initialStages);
    setSelectedIds([]);
    setIsRunning(true);

    try {
      const payload = {
        permiteOperacaoNaoTransacional: allowNonTransactional,
        versoes: batch.map(r => {
          const scriptToUse = rowCustomScripts[r.id] ?? customScript;
          const target = scriptToUse ? scriptToUse.name : rowTargetVersions[r.id] ?? targetVersion;
          return {
            idClienteBanco: r.id,
            nomeEmpresa: r.company,
            nomeBanco: r.name,
            versaoAtual: r.version,
            versaoAlvo: target,
            nomeScriptCustomizado: scriptToUse?.name,
            scriptCustomizadoConteudo: scriptToUse?.content,
          };
        }),
      };

      const loteInicial = await api.iniciarLote(payload);
      setActiveLoteId(loteInicial.loteId);

      const syncLoteState = async () => {
        try {
          const st = await api.obterStatusLote(loteInicial.loteId);
          setLogs(
            st.logs.map(l => ({
              id: l.id,
              time: l.time,
              level: l.level,
              db: l.db ?? undefined,
              message: l.message,
            }))
          );

          const nextProg: Record<number, number> = {};
          const nextStages: Record<number, string> = {};
          st.bancos.forEach(b => {
            nextProg[b.id] = b.progressoPercentual;
            nextStages[b.id] = b.etapaAtual;
          });
          setProgress(prev => ({ ...prev, ...nextProg }));
          setStages(prev => ({ ...prev, ...nextStages }));

          setRecords(prev =>
            prev.map(rec => {
              const b = st.bancos.find(item => item.id === rec.id);
              if (!b) return rec;
              const mappedStatus: DatabaseStatus =
                b.status === 'Cancelado' ? 'Pendente' : (b.status as DatabaseStatus);
              return {
                ...rec,
                version: b.versaoAtual,
                status: mappedStatus,
                lastError: b.sucesso ? null : b.mensagem ?? rec.lastError,
              };
            })
          );

          if (!st.emExecucao) {
            stopPolling();
            setIsRunning(false);
            await loadInitialData(false);
            setToast(
              `Lote #${st.loteId} finalizado: ${st.totalSucesso} sucesso(s), ${st.totalFalha} falha(s).`
            );
          }
        } catch (pollErr) {
          stopPolling();
          setIsRunning(false);
          setToast(pollErr instanceof Error ? pollErr.message : 'Erro ao consultar progresso do lote.');
        }
      };

      await syncLoteState();
      pollTimerRef.current = window.setInterval(() => {
        void syncLoteState();
      }, 450);
    } catch (err) {
      setIsRunning(false);
      setToast(err instanceof Error ? err.message : 'Falha ao iniciar o lote de atualização.');
      await loadInitialData(false);
    }
  };

  const handleCancelBatch = async () => {
    if (!activeLoteId) return;
    try {
      const res = await api.cancelarLote(activeLoteId);
      setToast(res.mensagem);
    } catch (err) {
      setToast(err instanceof Error ? err.message : 'Não foi possível cancelar o lote.');
    }
  };

  const handleLoadBatchLogsFromHistory = async (loteId: number) => {
    try {
      const batchLogs = await api.obterLogs(loteId);
      setLogs(
        batchLogs.map(l => ({
          id: l.id,
          time: l.time,
          level: l.level,
          db: l.db ?? undefined,
          message: l.message,
        }))
      );
      setActiveLoteId(loteId);
      setActiveTab('orchestrator');
      setToast(`Logs do Lote #${loteId} carregados no console.`);
    } catch (err) {
      setToast(err instanceof Error ? err.message : 'Erro ao carregar logs do lote.');
    }
  };

  /* ------------------------------------------------------------------------ */
  /* Renderização Login                                                        */
  /* ------------------------------------------------------------------------ */

  if (!loggedIn) {
    return (
      <main className="login-grid min-h-screen grid md:grid-cols-2 bg-white">
        <section className="login-left flex flex-col px-7 sm:px-12 lg:px-16">
          <header className="pt-10">
            <Brand />
          </header>
          <div className="login-form mx-auto w-full max-w-[380px]">
            <div className="eyebrow mb-5">PORTAL DE GERENCIAMENTO SEGURO (JWT)</div>
            <h1 className="text-[34px] font-semibold tracking-[-1.2px] text-[#142a46]">Bem-vindo de volta.</h1>
            <p className="mt-3 text-sm leading-6 text-slate-500">
              Autentique-se para gerenciar a frota de bancos SQL Server.
            </p>
            <form className="mt-8 space-y-5" onSubmit={handleLogin}>
              <div>
                <label htmlFor="email">E-mail corporativo</label>
                <div className="input-wrap">
                  <Mail size={18} />
                  <input
                    id="email"
                    type="email"
                    autoComplete="username"
                    placeholder="admin@centersys.com.br"
                    value={emailInput}
                    onChange={e => setEmailInput(e.target.value)}
                    required
                  />
                </div>
              </div>
              <div>
                <label htmlFor="password">Senha</label>
                <div className="input-wrap">
                  <LockKeyhole size={18} />
                  <input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    autoComplete="current-password"
                    placeholder="Digite sua senha"
                    value={passwordInput}
                    onChange={e => setPasswordInput(e.target.value)}
                    required
                  />
                  <button
                    type="button"
                    aria-label={showPassword ? 'Ocultar senha' : 'Mostrar senha'}
                    onClick={() => setShowPassword(!showPassword)}
                    className="icon-button"
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>
              {loginError && (
                <p className="flex items-center gap-2 rounded-md bg-red-50 px-3 py-2.5 text-xs font-medium text-red-700">
                  <TriangleAlert size={15} className="shrink-0" />
                  {loginError}
                </p>
              )}
              <button className="primary-button w-full" type="submit" disabled={isLoggingIn}>
                {isLoggingIn ? (
                  <>
                    <LoaderCircle size={18} className="animate-spin" /> Autenticando...
                  </>
                ) : (
                  <>
                    Entrar <ArrowRight size={18} />
                  </>
                )}
              </button>
            </form>
            <div className="demo-note mt-6 flex items-start justify-between gap-3 rounded-lg p-4">
              <div className="flex items-start gap-2.5">
                <ShieldCheck size={17} className="mt-0.5 shrink-0 text-[#103c6b]" />
                <div>
                  <strong>Ambiente Local de Homologação</strong>
                  <br />
                  Usuário inicial: <code className="font-mono">admin@centersys.com.br</code>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setEmailInput('admin@centersys.com.br');
                  setPasswordInput('CenterSys@2026');
                  setLoginError('');
                }}
                className="shrink-0 rounded border border-[#bcd6f3] bg-white px-2.5 py-1 text-[11px] font-semibold text-[#103c6b] hover:bg-[#eef5fd]"
              >
                Preencher dev
              </button>
            </div>
          </div>
          <footer className="pb-8 text-xs text-slate-400">© 2026 CenterSys. Todos os direitos reservados.</footer>
        </section>
        <section className="login-right relative flex flex-col items-center justify-center bg-[#0b2c54] px-8 py-16 text-center text-white lg:px-14">
          <div className="mb-14">
            <Brand light large />
          </div>
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/20 px-4 py-2 text-[11px] tracking-[1.5px] text-blue-100">
            <span className="h-1.5 w-1.5 rounded-full bg-sky-400" /> CONTROLE. CONSISTÊNCIA. EVOLUÇÃO.
          </div>
          <h2 className="max-w-lg text-[38px] font-medium leading-[1.16] tracking-[-1.5px] lg:text-[50px]">
            Versionamento de
            <br />
            Banco de Dados
          </h2>
          <p className="mt-6 max-w-[360px] text-sm leading-7 text-blue-100/65">
            Todas as empresas. Todos os ambientes.
            <br />
            Orquestração transacional integrada ao SQL Server.
          </p>
          <div className="mt-14 flex items-center justify-center gap-6 border-t border-white/15 pt-7 text-xs text-blue-100/75">
            <span className="flex items-center gap-2">
              <Database size={15} /> Multiempresa
            </span>
            <span className="h-3 w-px bg-white/20" />
            <span className="flex items-center gap-2">
              <Server size={15} /> Multidatacenter
            </span>
          </div>
          <p className="absolute bottom-8 text-[10px] tracking-[2px] text-blue-100/40">
            TECNOLOGIA QUE CONECTA SUA OPERAÇÃO
          </p>
        </section>
      </main>
    );
  }

  const currentVersionPkg = availableVersions.find(v => v.versao === targetVersion) ?? null;

  return (
    <div className="min-h-screen bg-[#f5f7fa] text-[#142a46]">
      <header className="dashboard-header flex items-center justify-between gap-4 bg-[#0b2c54] px-6 lg:px-12">
        <Brand light />
        <div className="flex items-center gap-5">
          <span className="hidden items-center gap-2 rounded-full border border-emerald-400/30 bg-emerald-500/10 px-3 py-1.5 text-[11px] text-emerald-200 sm:flex">
            <Database size={13} /> {user?.nome} ({user?.perfil})
          </span>
          <span className="h-7 w-px bg-white/15" />
          <button className="flex items-center gap-2 text-sm text-white/85 hover:text-white" onClick={handleLogout}>
            <LogOut size={16} /> Sair
          </button>
        </div>
      </header>

      <nav className="overflow-x-auto border-b border-slate-200 bg-white px-6 lg:px-12" aria-label="Navegação principal">
        <div role="tablist" className="flex gap-8">
          <button
            role="tab"
            aria-selected={activeTab === 'dashboard'}
            className={`tab ${activeTab === 'dashboard' ? 'tab-active' : ''}`}
            onClick={() => setActiveTab('dashboard')}
          >
            <LayoutDashboard size={17} /> Visão geral
          </button>
          <button
            role="tab"
            aria-selected={activeTab === 'orchestrator'}
            className={`tab ${activeTab === 'orchestrator' ? 'tab-active' : ''}`}
            onClick={() => setActiveTab('orchestrator')}
          >
            <Rocket size={17} /> Orquestrador de atualizações
            {isRunning ? (
              <LoaderCircle size={14} className="animate-spin text-[#176ac0]" />
            ) : (
              <span className={`tab-count ${eligibleCount === 0 ? 'zero' : ''}`}>{eligibleCount}</span>
            )}
          </button>
          <button
            role="tab"
            aria-selected={activeTab === 'operations'}
            className={`tab ${activeTab === 'operations' ? 'tab-active' : ''}`}
            onClick={() => setActiveTab('operations')}
          >
            <History size={17} /> Histórico, Agendamentos & Credenciais
          </button>
        </div>
      </nav>

      <main className="mx-auto max-w-[1600px] px-6 py-9 lg:px-12">
        {apiErrorBanner && (
          <div className="mb-6 flex items-center justify-between gap-4 rounded-xl border border-red-200 bg-red-50 px-5 py-4 text-xs text-red-800">
            <div className="flex items-center gap-2.5">
              <TriangleAlert size={16} className="shrink-0 text-red-600" />
              <span>
                <strong>Erro de comunicação com a API:</strong> {apiErrorBanner}
              </span>
            </div>
            <button
              type="button"
              onClick={() => void loadInitialData(true)}
              className="rounded border border-red-300 bg-white px-3 py-1.5 font-semibold text-red-700 hover:bg-red-100"
            >
              Tentar novamente
            </button>
          </div>
        )}

        {activeTab === 'dashboard' && (
          <DashboardView
            records={records}
            filteredRecords={filteredRecords}
            availableVersions={availableVersions}
            datacentersList={datacentersList}
            datacenter={datacenter}
            setDatacenter={setDatacenter}
            status={status}
            setStatus={setStatus}
            search={search}
            setSearch={setSearch}
            clearFilters={clearFilters}
            highlightId={highlightId}
            isSyncing={isSyncing}
            testingClientId={testingClientId}
            onSyncSqlServer={() => void loadInitialData(true)}
            onTestConnection={r => void handleTestConnection(r)}
            onEditCompany={r => setCompanyModalState({ open: true, mode: 'edit', record: r })}
            onOpenOrchestrator={openOrchestrator}
            onNewCompany={() => setCompanyModalState({ open: true, mode: 'create', record: null })}
            onOpenVersionDetails={() => setShowVersionDetails(true)}
            onOpenNewVersionModal={() => setShowNewVersionModal(true)}
            targetVersion={targetVersion}
            setTargetVersion={setTargetVersion}
            customScript={customScript}
            setCustomScript={setCustomScript}
            activeTarget={activeTarget}
            isCustomScript={isCustomScript}
            setToast={setToast}
          />
        )}

        {activeTab === 'orchestrator' && (
          <OrchestratorView
            records={records}
            availableVersions={availableVersions}
            selectedIds={selectedIds}
            setSelectedIds={setSelectedIds}
            batchOrigin={batchOrigin}
            progress={progress}
            stages={stages}
            isRunning={isRunning}
            activeLoteId={activeLoteId}
            logs={logs}
            onRequestStart={() => setShowConfirmBatch(true)}
            onCancelBatch={() => void handleCancelBatch()}
            onClearLogs={() => setLogs([])}
            onNewCompany={() => setCompanyModalState({ open: true, mode: 'create', record: null })}
            activeTarget={activeTarget}
            customScript={customScript}
            rowTargetVersions={rowTargetVersions}
            rowCustomScripts={rowCustomScripts}
            onRowTargetChange={(id, target) => setRowTargetVersions(prev => ({ ...prev, [id]: target }))}
            onRowCustomScriptChange={(id, script) =>
              setRowCustomScripts(prev => {
                const next = { ...prev };
                if (script) next[id] = script;
                else delete next[id];
                return next;
              })
            }
            setToast={setToast}
          />
        )}

        {activeTab === 'operations' && (
          <OperationsView
            availableVersions={availableVersions}
            datacentersList={datacentersList}
            userRole={user?.perfil ?? 'Operador'}
            onLoadBatchLogs={loteId => void handleLoadBatchLogsFromHistory(loteId)}
            setToast={setToast}
          />
        )}

        <footer className="mt-7 flex flex-wrap justify-between gap-3 text-[11px] text-slate-400">
          <span>© 2026 CenterSys · Soluções em sistemas</span>
          <span>
            Orquestrador de Atualizações Multi-Tenant <span className="px-2">/</span> Produção Integrada SQL Server
          </span>
        </footer>
      </main>

      {companyModalState.open && (
        <CompanyModal
          mode={companyModalState.mode}
          initialRecord={companyModalState.record}
          existingCompanies={records.map(r => r.company)}
          existingDatabases={records.map(r => r.name)}
          onClose={() => setCompanyModalState({ open: false, mode: 'create', record: null })}
          onSaveCreate={handleCreateCompany}
          onSaveEdit={handleEditCompany}
        />
      )}

      {showConfirmBatch && (
        <ConfirmBatchModal
          items={records
            .filter(r => selectedIds.includes(r.id) && r.approved)
            .map(r => {
              const s = rowCustomScripts[r.id] ?? customScript;
              return {
                company: r.company,
                dbName: r.name,
                currentVersion: r.version,
                target: s ? s.name : rowTargetVersions[r.id] ?? targetVersion,
              };
            })}
          allowNonTransactional={allowNonTransactional}
          setAllowNonTransactional={setAllowNonTransactional}
          onConfirm={() => void executeBatch()}
          onClose={() => setShowConfirmBatch(false)}
        />
      )}

      {showVersionDetails && currentVersionPkg && (
        <VersionDetailsModal versionPkg={currentVersionPkg} onClose={() => setShowVersionDetails(false)} />
      )}

      {showNewVersionModal && (
        <NewVersionPackageModal
          onClose={() => setShowNewVersionModal(false)}
          onCreated={created => {
            setShowNewVersionModal(false);
            setToast(`Pacote ${created.versao} validado e registrado no catálogo central!`);
            void loadInitialData(false);
          }}
        />
      )}

      {toast && (
        <div className="toast" role="status">
          <CheckCheck size={16} className="shrink-0 text-emerald-300" />
          {toast}
        </div>
      )}
    </div>
  );
}
