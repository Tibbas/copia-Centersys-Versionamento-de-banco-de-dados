# CenterSys — Frontend do Orquestrador de Atualizações

Aplicação web em **React 19, TypeScript, Vite e Tailwind CSS v4** integrada em tempo real à API **ASP.NET Core (.NET 10)** e ao **Microsoft SQL Server**.

## Executar em Desenvolvimento
1. Certifique-se de que a API (`Centersys.AtualizadorVersoes.Api`) está em execução em `http://localhost:5119`.
2. Instale as dependências e inicie o servidor Vite:
```bash
npm install
npm run dev
```
3. Acesse `http://localhost:3000`.

## Build de Produção e Checagem de Tipos
```bash
npm run build
```

## Funcionalidades Integradas à API Real
- **Autenticação JWT (`POST /api/auth/login`):** Sessão autenticada com controle de expiração.
- **Visão Geral da Frota (`GET /api/versoes`):** Sincronização com `sys.databases` (descartando bancos iniciados com `_`), leitura real de `dbo.Log_Acesso.cNumVersao`, teste de conexão com latência por banco, cadastro e edição de clientes, visualização de hashes SHA-256 e cadastro de novos pacotes de versão.
- **Orquestrador de Atualizações (`POST /api/versoes/lotes` + Polling em Tempo Real):** Seleção individual ou em lote, versão alvo individual por banco ou upload de script `.sql` customizado (com leitura e validação T-SQL real), barra de progresso real, cancelamento seguro com rollback e console de auditoria conectado a `dbo.LogsEventos`.
- **Histórico, Agendamentos e Credenciais (`/api/versoes/historico`, `/api/agendamentos`, `/api/credenciais`):** Consulta de lotes anteriores, agendamento automático interno e gestão segura de instâncias SQL Server.
