export interface UsuarioInfo {
  id: number;
  nome: string;
  email: string;
  perfil: string;
}

export interface LoginResponse {
  token: string;
  expiraEm: string;
  usuario: UsuarioInfo;
}

export interface BancoDeDadosClienteDto {
  id: number;
  nomeEmpresa: string;
  nomeBanco: string;
  servidor: string;
  datacenter: string;
  versaoAtual: string;
  status: 'Atualizado' | 'Pendente' | 'DESATUALIZADA' | 'Falha' | 'Atualizando...';
  aprovado: boolean;
  ativoNaInstancia: boolean;
  emExecucao: boolean;
  quantidadeScriptsPendentes: number;
  pacotesPendentes: string[];
  ultimaVerificacao?: string | null;
  ultimaAtualizacao?: string | null;
  ultimoErroResumo?: string | null;
  logErros: string[];
}

export interface ArquivoScriptResumoDto {
  id: number;
  nomeArquivo: string;
  ordemExecucao: number;
  hashSha256: string;
  quantidadeLotesGo: number;
  contemTransacaoInterna: boolean;
  contemOperacaoNaoTransacional: boolean;
  avisosValidacao?: string | null;
}

export interface VersaoDisponivelDto {
  id: number;
  versao: string;
  descricao?: string | null;
  origem: string;
  idPastaDrive?: string | null;
  padrao: boolean;
  quantidadeScripts: number;
  criadoEm: string;
  arquivos: ArquivoScriptResumoDto[];
}

export interface AtualizarVersaoItemDto {
  idClienteBanco?: number;
  nomeEmpresa: string;
  nomeBanco?: string;
  versaoAtual: string;
  versaoAlvo: string;
  nomeScriptCustomizado?: string;
  scriptCustomizadoConteudo?: string;
}

export interface AtualizarVersoesRequestDto {
  versoes: AtualizarVersaoItemDto[];
  permiteOperacaoNaoTransacional?: boolean;
}

export interface LogExecucaoDto {
  id: number;
  time: string;
  level: 'SYSTEM' | 'INFO' | 'EXEC' | 'SUCCESS' | 'WARN';
  db?: string | null;
  message: string;
  dataHoraUtc: string;
}

export interface BancoAtualizadoDto {
  id: number;
  execucaoLoteId: number;
  nomeEmpresa: string;
  nomeBanco: string;
  servidor: string;
  datacenter: string;
  versaoAnterior: string;
  versaoAlvo: string;
  versaoAtual: string;
  status: 'Atualizado' | 'Pendente' | 'DESATUALIZADA' | 'Falha' | 'Atualizando...' | 'Cancelado';
  progressoPercentual: number;
  etapaAtual: string;
  mensagem?: string | null;
  sucesso: boolean;
  logs: LogExecucaoDto[];
}

export interface StatusLoteExecucaoDto {
  loteId: number;
  disparadoPor: string;
  origem: string;
  statusLote: string;
  totalBancos: number;
  totalSucesso: number;
  totalFalha: number;
  totalCancelado: number;
  progressoGeralPercentual: number;
  emExecucao: boolean;
  cancelamentoSolicitado: boolean;
  dataInicio: string;
  dataFim?: string | null;
  bancos: BancoAtualizadoDto[];
  logs: LogExecucaoDto[];
}

export interface HistoricoExecucaoResumoDto {
  loteId: number;
  disparadoPor: string;
  origem: string;
  statusLote: string;
  totalBancos: number;
  totalSucesso: number;
  totalFalha: number;
  totalCancelado: number;
  dataInicio: string;
  dataFim?: string | null;
  bancos: BancoAtualizadoDto[];
}

export interface CriarClienteBancoRequestDto {
  nomeEmpresa: string;
  nomeBanco: string;
  servidor: string;
  datacenter: string;
  versaoInicial: string;
  criarBancoFisicoSeNaoExistir: boolean;
}

export interface EditarClienteBancoRequestDto {
  nomeEmpresa: string;
  servidor: string;
  datacenter: string;
  aprovado: boolean;
}

export interface TesteConexaoResponseDto {
  clienteBancoId: number;
  nomeBanco: string;
  servidor: string;
  conectado: boolean;
  versaoLida?: string | null;
  latenciaMs: number;
  mensagem: string;
}

export interface CadastrarPacoteVersaoRequestDto {
  numeroVersao: string;
  descricao?: string;
  definirComoPadrao: boolean;
  arquivos: { nomeArquivo: string; conteudoSql: string }[];
}

export interface AgendamentoDto {
  id: number;
  descricao: string;
  versaoAlvo: string;
  datacenterEscopo?: string | null;
  dataHoraProgramada: string;
  status: string;
  execucaoLoteId?: number | null;
  mensagemResultado?: string | null;
  criadoEm: string;
  executadoEm?: string | null;
}

export interface CredencialServidorDto {
  id: number;
  servidor: string;
  datacenter: string;
  hostInstancia: string;
  porta?: number | null;
  usarAutenticacaoWindows: boolean;
  usuarioSql?: string | null;
  possuiSenhaConfigurada: boolean;
  trustServerCertificate: boolean;
  ultimaConexaoOk?: boolean | null;
  ultimaVerificacaoConexao?: string | null;
  mensagemStatusConexao?: string | null;
}

const TOKEN_KEY = 'centersys_jwt_token';
const USER_KEY = 'centersys_auth_user';

const envApiUrl = (import.meta as unknown as { env?: Record<string, string | undefined> }).env?.VITE_API_URL;
const API_BASE = envApiUrl ? envApiUrl.replace(/\/$/, '') : 'http://localhost:5119';

export function getStoredToken(): string | null {
  return sessionStorage.getItem(TOKEN_KEY);
}

export function getStoredUser(): UsuarioInfo | null {
  const raw = sessionStorage.getItem(USER_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as UsuarioInfo;
  } catch {
    return null;
  }
}

export function saveAuthSession(token: string, usuario: UsuarioInfo): void {
  sessionStorage.setItem(TOKEN_KEY, token);
  sessionStorage.setItem(USER_KEY, JSON.stringify(usuario));
}

export function clearAuthSession(): void {
  sessionStorage.removeItem(TOKEN_KEY);
  sessionStorage.removeItem(USER_KEY);
}

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

async function requestJson<T>(path: string, init: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers = new Headers(init.headers);
  if (!headers.has('Content-Type') && init.body) {
    headers.set('Content-Type', 'application/json');
  }
  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  let response: Response;
  try {
    // Tenta rota relativa (proxy Vite em dev) ou fallback direto para API_BASE
    const url = window.location.port === '3000' ? path : `${API_BASE}${path}`;
    response = await fetch(url, { ...init, headers });
  } catch {
    response = await fetch(`${API_BASE}${path}`, { ...init, headers });
  }

  if (response.status === 204) {
    return undefined as T;
  }

  let payload: unknown = null;
  const text = await response.text();
  if (text) {
    try {
      payload = JSON.parse(text);
    } catch {
      payload = { erro: text };
    }
  }

  if (!response.ok) {
    if (response.status === 401) {
      clearAuthSession();
    }
    const msg =
      (payload && typeof payload === 'object' && 'erro' in payload && typeof (payload as { erro?: unknown }).erro === 'string'
        ? (payload as { erro: string }).erro
        : null) ?? `Erro HTTP ${response.status} ao comunicar com a API.`;
    throw new ApiError(msg, response.status);
  }

  return payload as T;
}

export const api = {
  login: (email: string, senha: string) =>
    requestJson<LoginResponse>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, senha }),
    }),

  me: () => requestJson<UsuarioInfo>('/api/auth/me'),

  listarClientes: (sincronizar = true) =>
    requestJson<BancoDeDadosClienteDto[]>(`/api/versoes?sincronizar=${sincronizar}`),

  cadastrarCliente: (body: CriarClienteBancoRequestDto) =>
    requestJson<BancoDeDadosClienteDto>('/api/versoes/clientes', {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  editarCliente: (id: number, body: EditarClienteBancoRequestDto) =>
    requestJson<BancoDeDadosClienteDto>(`/api/versoes/clientes/${id}`, {
      method: 'PUT',
      body: JSON.stringify(body),
    }),

  testarConexaoCliente: (id: number) =>
    requestJson<TesteConexaoResponseDto>(`/api/versoes/clientes/${id}/testar-conexao`, {
      method: 'POST',
    }),

  listarVersoes: () => requestJson<VersaoDisponivelDto[]>('/api/versoes/versoes'),

  cadastrarPacoteVersao: (body: CadastrarPacoteVersaoRequestDto) =>
    requestJson<VersaoDisponivelDto>('/api/versoes/versoes', {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  iniciarLote: (body: AtualizarVersoesRequestDto) =>
    requestJson<StatusLoteExecucaoDto>('/api/versoes/lotes', {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  obterStatusLote: (loteId: number) =>
    requestJson<StatusLoteExecucaoDto>(`/api/versoes/lotes/${loteId}`),

  cancelarLote: (loteId: number) =>
    requestJson<{ mensagem: string }>(`/api/versoes/lotes/${loteId}/cancelar`, {
      method: 'POST',
    }),

  obterHistorico: (limite = 25) =>
    requestJson<HistoricoExecucaoResumoDto[]>(`/api/versoes/historico?limite=${limite}`),

  obterLogs: (loteId?: number, clienteBancoId?: number) => {
    const params = new URLSearchParams();
    if (loteId) params.set('loteId', String(loteId));
    if (clienteBancoId) params.set('clienteBancoId', String(clienteBancoId));
    const qs = params.toString();
    return requestJson<LogExecucaoDto[]>(`/api/versoes/logs${qs ? `?${qs}` : ''}`);
  },

  listarAgendamentos: () => requestJson<AgendamentoDto[]>('/api/agendamentos'),

  criarAgendamento: (body: {
    descricao: string;
    versaoAlvo: string;
    datacenterEscopo?: string;
    dataHoraProgramada: string;
  }) =>
    requestJson<AgendamentoDto>('/api/agendamentos', {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  cancelarAgendamento: (id: number) =>
    requestJson<void>(`/api/agendamentos/${id}`, { method: 'DELETE' }),

  listarCredenciais: () => requestJson<CredencialServidorDto[]>('/api/credenciais'),

  salvarCredencial: (body: {
    servidor: string;
    datacenter: string;
    hostInstancia: string;
    porta?: number | null;
    usarAutenticacaoWindows: boolean;
    usuarioSql?: string;
    senhaSql?: string;
    trustServerCertificate: boolean;
  }) =>
    requestJson<CredencialServidorDto>('/api/credenciais', {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  testarCredencialServidor: (id: number) =>
    requestJson<{ conectado: boolean; latenciaMs: number; mensagem: string }>(
      `/api/credenciais/${id}/testar`,
      { method: 'POST' }
    ),
};
