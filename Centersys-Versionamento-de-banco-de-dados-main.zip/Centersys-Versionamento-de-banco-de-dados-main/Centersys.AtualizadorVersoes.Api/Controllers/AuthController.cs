using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Centersys.AtualizadorVersoes.Api.Configuration;
using Centersys.AtualizadorVersoes.Api.Configuration.Data;
using Centersys.AtualizadorVersoes.Api.DTOs;
using Centersys.AtualizadorVersoes.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace Centersys.AtualizadorVersoes.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController(
    ApplicationDbContext dbContext,
    IOptions<JwtSettings> jwtOptions,
    IConfiguration configuration) : ControllerBase
{
    private readonly JwtSettings _jwtSettings = jwtOptions.Value;

    [AllowAnonymous]
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest request, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.Email) || string.IsNullOrWhiteSpace(request.Senha))
        {
            return BadRequest(new { erro = "Informe e-mail e senha para autenticar." });
        }

        var emailNormalizado = request.Email.Trim().ToLowerInvariant();
        var usuario = await dbContext.Usuarios
            .AsNoTracking()
            .FirstOrDefaultAsync(u => u.Email.ToLower() == emailNormalizado && u.Ativo, cancellationToken);

        if (usuario is null || !PasswordHasher.VerifyPassword(request.Senha, usuario.SenhaHash))
        {
            return Unauthorized(new { erro = "E-mail ou senha inválidos." });
        }

        var secretKey = ObterChaveJwtEfetiva(configuration, _jwtSettings);
        var expiraEm = DateTime.UtcNow.AddHours(Math.Max(1, _jwtSettings.ExpiracaoHoras));

        var claims = new List<Claim>
        {
            new(JwtRegisteredClaimNames.Sub, usuario.Id.ToString()),
            new(JwtRegisteredClaimNames.Email, usuario.Email),
            new(ClaimTypes.Name, usuario.Nome),
            new(ClaimTypes.Role, usuario.Perfil),
            new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString("N"))
        };

        var signingKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secretKey));
        var credentials = new SigningCredentials(signingKey, SecurityAlgorithms.HmacSha256);

        var jwt = new JwtSecurityToken(
            issuer: _jwtSettings.Issuer,
            audience: _jwtSettings.Audience,
            claims: claims,
            expires: expiraEm,
            signingCredentials: credentials);

        var tokenString = new JwtSecurityTokenHandler().WriteToken(jwt);

        return Ok(new LoginResponse
        {
            Token = tokenString,
            ExpiraEm = expiraEm,
            Usuario = new UsuarioInfoDto
            {
                Id = usuario.Id,
                Nome = usuario.Nome,
                Email = usuario.Email,
                Perfil = usuario.Perfil
            }
        });
    }

    [Authorize]
    [HttpGet("me")]
    public async Task<IActionResult> Me(CancellationToken cancellationToken)
    {
        var sub = User.FindFirstValue(JwtRegisteredClaimNames.Sub) ?? User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!int.TryParse(sub, out var userId))
            return Unauthorized();

        var usuario = await dbContext.Usuarios
            .AsNoTracking()
            .FirstOrDefaultAsync(u => u.Id == userId && u.Ativo, cancellationToken);

        if (usuario is null)
            return Unauthorized();

        return Ok(new UsuarioInfoDto
        {
            Id = usuario.Id,
            Nome = usuario.Nome,
            Email = usuario.Email,
            Perfil = usuario.Perfil
        });
    }

    public static string ObterChaveJwtEfetiva(IConfiguration configuration, JwtSettings settings)
    {
        var envKey = configuration["CENTERSYS_JWT_SECRET"];
        var key = !string.IsNullOrWhiteSpace(envKey) ? envKey : settings.SecretKey;

        if (string.IsNullOrWhiteSpace(key) || Encoding.UTF8.GetByteCount(key) < 32)
        {
            throw new InvalidOperationException(
                "Chave JWT inválida ou ausente. Configure 'CENTERSYS_JWT_SECRET' (mínimo de 32 caracteres).");
        }

        return key;
    }
}
