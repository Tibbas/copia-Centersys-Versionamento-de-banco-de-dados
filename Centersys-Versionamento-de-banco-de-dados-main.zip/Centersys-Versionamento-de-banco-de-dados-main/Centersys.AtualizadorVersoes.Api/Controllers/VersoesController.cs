using System.Security.Claims;
using Centersys.AtualizadorVersoes.Api.DTOs;
using Centersys.AtualizadorVersoes.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Centersys.AtualizadorVersoes.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/[controller]")]
public class VersoesController(IVersaoService versaoService) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetBancoDeDadosClientes(
        [FromQuery] bool sincronizar = true,
        CancellationToken cancellationToken = default)
    {
        var result = await versaoService.GetBancoDeDadosClientesAsync(sincronizar, cancellationToken);
        return Ok(result);
    }

    [HttpPost("clientes")]
    public async Task<IActionResult> CadastrarCliente(
        [FromBody] CriarClienteBancoRequest request,
        CancellationToken cancellationToken = default)
    {
        var criado = await versaoService.CadastrarClienteAsync(request, cancellationToken);
        return Created($"/api/versoes/clientes/{criado.Id}", criado);
    }

    [HttpPut("clientes/{id:int}")]
    public async Task<IActionResult> EditarCliente(
        int id,
        [FromBody] EditarClienteBancoRequest request,
        CancellationToken cancellationToken = default)
    {
        var atualizado = await versaoService.EditarClienteAsync(id, request, cancellationToken);
        return Ok(atualizado);
    }

    [HttpPost("clientes/{id:int}/testar-conexao")]
    public async Task<IActionResult> TestarConexaoCliente(
        int id,
        CancellationToken cancellationToken = default)
    {
        var status = await versaoService.TestarConexaoClienteAsync(id, cancellationToken);
        return Ok(status);
    }

    [HttpGet("versoes")]
    public async Task<IActionResult> GetVersoesDisponiveis(CancellationToken cancellationToken = default)
    {
        var result = await versaoService.GetVersoesDisponiveisAsync(cancellationToken);
        return Ok(result);
    }

    [HttpPost("versoes")]
    public async Task<IActionResult> CadastrarPacoteVersao(
        [FromBody] CadastrarPacoteVersaoRequest request,
        CancellationToken cancellationToken = default)
    {
        var pacote = await versaoService.CadastrarPacoteVersaoAsync(request, cancellationToken);
        return Created($"/api/versoes/versoes", pacote);
    }

    [HttpPost("atualizar")]
    public async Task<IActionResult> AtualizarBancos(
        [FromBody] AtualizarVersoesRequest request,
        CancellationToken cancellationToken = default)
    {
        var operador = User.FindFirstValue(ClaimTypes.Name) ?? "Operador";
        var result = await versaoService.AtualizarBancoDeDadosAsync(request, operador, "Manual", cancellationToken);
        return Ok(result);
    }

    [HttpPost("lotes")]
    public async Task<IActionResult> IniciarLoteAssincrono(
        [FromBody] AtualizarVersoesRequest request,
        CancellationToken cancellationToken = default)
    {
        var operador = User.FindFirstValue(ClaimTypes.Name) ?? "Operador";
        var lote = await versaoService.IniciarLoteAssincronoAsync(request, operador, "Manual", cancellationToken);
        return Accepted($"/api/versoes/lotes/{lote.LoteId}", lote);
    }

    [HttpGet("lotes/{loteId:int}")]
    public async Task<IActionResult> ObterStatusLote(
        int loteId,
        CancellationToken cancellationToken = default)
    {
        var status = await versaoService.ObterStatusLoteAsync(loteId, cancellationToken);
        return status is null ? NotFound(new { erro = $"Lote #{loteId} não encontrado." }) : Ok(status);
    }

    [HttpPost("lotes/{loteId:int}/cancelar")]
    public async Task<IActionResult> CancelarLote(
        int loteId,
        CancellationToken cancellationToken = default)
    {
        var cancelado = await versaoService.CancelarLoteAsync(loteId, cancellationToken);
        if (!cancelado)
            return BadRequest(new { erro = $"O Lote #{loteId} já foi encerrado ou não está em execução." });

        return Ok(new { mensagem = $"Solicitação de cancelamento enviada ao Lote #{loteId}." });
    }

    [HttpGet("historico")]
    public async Task<IActionResult> ObterHistorico(
        [FromQuery] int limite = 25,
        CancellationToken cancellationToken = default)
    {
        var historico = await versaoService.ObterHistoricoExecucoesAsync(limite, cancellationToken);
        return Ok(historico);
    }

    [HttpGet("logs")]
    public async Task<IActionResult> ObterLogs(
        [FromQuery] int? loteId = null,
        [FromQuery] int? clienteBancoId = null,
        [FromQuery] int limite = 200,
        CancellationToken cancellationToken = default)
    {
        var logs = await versaoService.ObterLogsRecentesAsync(loteId, clienteBancoId, limite, cancellationToken);
        return Ok(logs);
    }
}
