using System.Diagnostics;
using System.Security.Claims;
using Centersys.AtualizadorVersoes.Api.Configuration.Data;
using Centersys.AtualizadorVersoes.Api.DTOs;
using Centersys.AtualizadorVersoes.Api.Models;
using Centersys.AtualizadorVersoes.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace Centersys.AtualizadorVersoes.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/[controller]")]
public class AgendamentosController(ApplicationDbContext dbContext) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Listar(CancellationToken cancellationToken)
    {
        var itens = await dbContext.Agendamentos
            .AsNoTracking()
            .OrderByDescending(a => a.DataHoraProgramada)
            .Take(50)
            .Select(a => new AgendamentoResponse
            {
                Id = a.Id,
                Descricao = a.Descricao,
                VersaoAlvo = a.VersaoAlvo,
                DatacenterEscopo = a.DatacenterEscopo,
                DataHoraProgramada = a.DataHoraProgramada,
                Status = a.Status,
                ExecucaoLoteId = a.ExecucaoLoteId,
                MensagemResultado = a.MensagemResultado,
                CriadoEm = a.CriadoEm,
                ExecutadoEm = a.ExecutadoEm
            })
            .ToListAsync(cancellationToken);

        return Ok(itens);
    }

    [HttpPost]
    public async Task<IActionResult> Criar(
        [FromBody] CriarAgendamentoRequest request,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.Descricao))
            return BadRequest(new { erro = "Informe uma descrição para o agendamento." });
        if (!VersionComparer.TryExtractVersion(request.VersaoAlvo, out var versaoCanonica))
            return BadRequest(new { erro = $"Versão alvo inválida: '{request.VersaoAlvo}'." });

        var usuario = User.FindFirstValue(ClaimTypes.Name) ?? "Operador";
        var programadaUtc = request.DataHoraProgramada.Kind == DateTimeKind.Utc
            ? request.DataHoraProgramada
            : request.DataHoraProgramada.ToUniversalTime();

        var novo = new AgendamentoAtualizacao
        {
            Descricao = request.Descricao.Trim(),
            VersaoAlvo = versaoCanonica,
            DatacenterEscopo = string.IsNullOrWhiteSpace(request.DatacenterEscopo) ? "Todos" : request.DatacenterEscopo,
            IdsClientesCsv = request.IdsClientes is { Count: > 0 }
                ? string.Join(',', request.IdsClientes)
                : null,
            DataHoraProgramada = programadaUtc,
            Status = "Pendente",
            CriadoPor = usuario
        };

        dbContext.Agendamentos.Add(novo);
        await dbContext.SaveChangesAsync(cancellationToken);

        return Created($"/api/agendamentos/{novo.Id}", new AgendamentoResponse
        {
            Id = novo.Id,
            Descricao = novo.Descricao,
            VersaoAlvo = novo.VersaoAlvo,
            DatacenterEscopo = novo.DatacenterEscopo,
            DataHoraProgramada = novo.DataHoraProgramada,
            Status = novo.Status,
            CriadoEm = novo.CriadoEm
        });
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Cancelar(int id, CancellationToken cancellationToken)
    {
        var item = await dbContext.Agendamentos.FirstOrDefaultAsync(a => a.Id == id, cancellationToken);
        if (item is null)
            return NotFound();

        if (item.Status == "Pendente")
        {
            item.Status = "Cancelado";
            await dbContext.SaveChangesAsync(cancellationToken);
        }

        return NoContent();
    }
}

[ApiController]
[Authorize(Roles = "Admin")]
[Route("api/[controller]")]
public class CredenciaisController(
    ApplicationDbContext dbContext,
    ICredentialProvider credentialProvider) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Listar(CancellationToken cancellationToken)
    {
        var lista = await dbContext.CredenciaisServidores
            .AsNoTracking()
            .OrderBy(c => c.Servidor)
            .Select(c => new CredencialServidorResponse
            {
                Id = c.Id,
                Servidor = c.Servidor,
                Datacenter = c.Datacenter,
                HostInstancia = c.HostInstancia,
                Porta = c.Porta,
                UsarAutenticacaoWindows = c.UsarAutenticacaoWindows,
                UsuarioSql = c.UsuarioSql,
                PossuiSenhaConfigurada = !string.IsNullOrEmpty(c.SenhaCriptografada),
                TrustServerCertificate = c.TrustServerCertificate,
                UltimaConexaoOk = c.UltimaConexaoOk,
                UltimaVerificacaoConexao = c.UltimaVerificacaoConexao,
                MensagemStatusConexao = c.MensagemStatusConexao
            })
            .ToListAsync(cancellationToken);

        return Ok(lista);
    }

    [HttpPost]
    public async Task<IActionResult> Salvar(
        [FromBody] SalvarCredencialServidorRequest request,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.Servidor) || string.IsNullOrWhiteSpace(request.HostInstancia))
            return BadRequest(new { erro = "Informe Servidor e Host/Instância SQL." });

        if (!request.UsarAutenticacaoWindows && string.IsNullOrWhiteSpace(request.UsuarioSql))
            return BadRequest(new { erro = "Informe o Usuário SQL quando a Autenticação Windows estiver desabilitada." });

        var srvNorm = request.Servidor.Trim();
        var existente = await dbContext.CredenciaisServidores
            .FirstOrDefaultAsync(c => c.Servidor == srvNorm, cancellationToken);

        if (existente is null)
        {
            existente = new CredencialServidor
            {
                Servidor = srvNorm,
                Datacenter = request.Datacenter.Trim(),
                HostInstancia = request.HostInstancia.Trim(),
                Porta = request.Porta,
                UsarAutenticacaoWindows = request.UsarAutenticacaoWindows,
                UsuarioSql = request.UsarAutenticacaoWindows ? null : request.UsuarioSql?.Trim(),
                SenhaCriptografada = !request.UsarAutenticacaoWindows && !string.IsNullOrEmpty(request.SenhaSql)
                    ? credentialProvider.CriptografarSenha(request.SenhaSql)
                    : null,
                TrustServerCertificate = request.TrustServerCertificate,
                Ativo = true
            };
            dbContext.CredenciaisServidores.Add(existente);
        }
        else
        {
            existente.Datacenter = request.Datacenter.Trim();
            existente.HostInstancia = request.HostInstancia.Trim();
            existente.Porta = request.Porta;
            existente.UsarAutenticacaoWindows = request.UsarAutenticacaoWindows;
            existente.UsuarioSql = request.UsarAutenticacaoWindows ? null : request.UsuarioSql?.Trim();
            existente.TrustServerCertificate = request.TrustServerCertificate;

            if (request.UsarAutenticacaoWindows)
            {
                existente.SenhaCriptografada = null;
            }
            else if (!string.IsNullOrEmpty(request.SenhaSql))
            {
                existente.SenhaCriptografada = credentialProvider.CriptografarSenha(request.SenhaSql);
            }
        }

        await dbContext.SaveChangesAsync(cancellationToken);

        return Ok(new CredencialServidorResponse
        {
            Id = existente.Id,
            Servidor = existente.Servidor,
            Datacenter = existente.Datacenter,
            HostInstancia = existente.HostInstancia,
            Porta = existente.Porta,
            UsarAutenticacaoWindows = existente.UsarAutenticacaoWindows,
            UsuarioSql = existente.UsuarioSql,
            PossuiSenhaConfigurada = !string.IsNullOrEmpty(existente.SenhaCriptografada),
            TrustServerCertificate = existente.TrustServerCertificate,
            UltimaConexaoOk = existente.UltimaConexaoOk,
            UltimaVerificacaoConexao = existente.UltimaVerificacaoConexao,
            MensagemStatusConexao = existente.MensagemStatusConexao
        });
    }

    [HttpPost("{id:int}/testar")]
    public async Task<IActionResult> TestarConexaoServidor(int id, CancellationToken cancellationToken)
    {
        var credencial = await dbContext.CredenciaisServidores.FirstOrDefaultAsync(c => c.Id == id, cancellationToken);
        if (credencial is null)
            return NotFound();

        var sw = Stopwatch.StartNew();
        try
        {
            var connStr = await credentialProvider.ObterConnectionStringInstanciaAsync(credencial.Servidor, cancellationToken);
            await using var conn = new SqlConnection(connStr);
            await conn.OpenAsync(cancellationToken);
            await using var cmd = new SqlCommand("SELECT @@VERSION;", conn) { CommandTimeout = 10 };
            var versaoMotor = Convert.ToString(await cmd.ExecuteScalarAsync(cancellationToken))?.Split('\n').FirstOrDefault()?.Trim();
            sw.Stop();

            credencial.UltimaConexaoOk = true;
            credencial.UltimaVerificacaoConexao = DateTime.UtcNow;
            credencial.MensagemStatusConexao = $"OK ({sw.ElapsedMilliseconds} ms) — {versaoMotor}";
            await dbContext.SaveChangesAsync(cancellationToken);

            return Ok(new
            {
                conectado = true,
                latenciaMs = sw.ElapsedMilliseconds,
                mensagem = credencial.MensagemStatusConexao
            });
        }
        catch (Exception ex)
        {
            sw.Stop();
            credencial.UltimaConexaoOk = false;
            credencial.UltimaVerificacaoConexao = DateTime.UtcNow;
            credencial.MensagemStatusConexao = $"Falha: {ex.Message}";
            await dbContext.SaveChangesAsync(cancellationToken);

            return Ok(new
            {
                conectado = false,
                latenciaMs = sw.ElapsedMilliseconds,
                mensagem = credencial.MensagemStatusConexao
            });
        }
    }
}
