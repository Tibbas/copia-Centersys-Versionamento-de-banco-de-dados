using Centersys.AtualizadorVersoes.Api.Configuration.Data;
using Centersys.AtualizadorVersoes.Api.DTOs;
using Microsoft.EntityFrameworkCore;

namespace Centersys.AtualizadorVersoes.Api.Services;

public sealed class AgendamentoWorker(
    IServiceScopeFactory scopeFactory,
    ILogger<AgendamentoWorker> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var timer = new PeriodicTimer(TimeSpan.FromSeconds(15));

        while (!stoppingToken.IsCancellationRequested && await timer.WaitForNextTickAsync(stoppingToken))
        {
            try
            {
                await ProcessarAgendamentosVencidosAsync(stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Erro no ciclo de verificação de agendamentos automáticos.");
            }
        }
    }

    private async Task ProcessarAgendamentosVencidosAsync(CancellationToken stoppingToken)
    {
        using var scope = scopeFactory.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
        var versaoService = scope.ServiceProvider.GetRequiredService<IVersaoService>();

        var agora = DateTime.UtcNow;
        var pendentes = await dbContext.Agendamentos
            .Where(a => a.Status == "Pendente" && a.DataHoraProgramada <= agora)
            .OrderBy(a => a.DataHoraProgramada)
            .ToListAsync(stoppingToken);

        foreach (var agenda in pendentes)
        {
            agenda.Status = "Executando";
            agenda.ExecutadoEm = DateTime.UtcNow;
            await dbContext.SaveChangesAsync(stoppingToken);

            try
            {
                var queryClientes = dbContext.ClientesBancos
                    .AsNoTracking()
                    .Where(c => c.Aprovado && c.AtivoNaInstancia && !c.EmExecucaoLock);

                if (!string.IsNullOrWhiteSpace(agenda.DatacenterEscopo) && agenda.DatacenterEscopo != "Todos")
                {
                    queryClientes = queryClientes.Where(c => c.Datacenter == agenda.DatacenterEscopo);
                }

                if (!string.IsNullOrWhiteSpace(agenda.IdsClientesCsv))
                {
                    var ids = agenda.IdsClientesCsv
                        .Split(',', StringSplitOptions.RemoveEmptyEntries)
                        .Select(s => int.TryParse(s, out var id) ? id : 0)
                        .Where(id => id > 0)
                        .ToList();

                    if (ids.Count > 0)
                        queryClientes = queryClientes.Where(c => ids.Contains(c.Id));
                }

                var candidatos = await queryClientes.ToListAsync(stoppingToken);
                var desatualizados = candidatos
                    .Where(c => VersionComparer.Compare(c.VersaoAtualConhecida, agenda.VersaoAlvo) < 0)
                    .ToList();

                if (desatualizados.Count == 0)
                {
                    agenda.Status = "Concluido";
                    agenda.MensagemResultado = "Nenhum banco desatualizado encontrado no escopo do agendamento.";
                    await dbContext.SaveChangesAsync(stoppingToken);
                    continue;
                }

                var request = new AtualizarVersoesRequest
                {
                    Versoes = desatualizados.Select(c => new AtualizarVersaoItem
                    {
                        IdClienteBanco = c.Id,
                        NomeEmpresa = c.NomeEmpresa,
                        NomeBanco = c.NomeBanco,
                        VersaoAtual = c.VersaoAtualConhecida,
                        VersaoAlvo = agenda.VersaoAlvo
                    }).ToList()
                };

                var resultados = (await versaoService.AtualizarBancoDeDadosAsync(
                    request,
                    disparadoPor: $"Agendador ({agenda.Descricao})",
                    origem: "Agendado",
                    cancellationToken: stoppingToken)).ToList();

                var loteId = resultados.FirstOrDefault()?.ExecucaoLoteId;
                var falhas = resultados.Count(r => !r.Sucesso);

                agenda.ExecucaoLoteId = loteId;
                agenda.Status = falhas > 0 ? "Falha" : "Concluido";
                agenda.MensagemResultado = $"Lote #{loteId}: {resultados.Count - falhas}/{resultados.Count} banco(s) atualizados com sucesso.";
                await dbContext.SaveChangesAsync(stoppingToken);
            }
            catch (Exception ex)
            {
                agenda.Status = "Falha";
                agenda.MensagemResultado = $"Erro ao disparar agendamento: {ex.Message}";
                await dbContext.SaveChangesAsync(CancellationToken.None);
            }
        }
    }
}
