using Centersys.AtualizadorVersoes.Api.Configuration;
using Centersys.AtualizadorVersoes.Api.Configuration.Data;
using Centersys.AtualizadorVersoes.Api.DTOs;
using Centersys.AtualizadorVersoes.Api.Models;
using Centersys.AtualizadorVersoes.Api.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace Centersys.AtualizadorVersoes.Api.Services;

public class VersaoService(
    ApplicationDbContext dbContext,
    IBancoClientesRepository repository,
    IGoogleDriveService googleDriveService,
    ISqlScriptAnalyzer scriptAnalyzer,
    ILoteCancellationManager cancellationManager,
    IServiceScopeFactory scopeFactory,
    IOptions<OrquestradorSettings> settingsOptions,
    ILogger<VersaoService> logger) : IVersaoService
{
    private readonly OrquestradorSettings _settings = settingsOptions.Value;

    public async Task<IEnumerable<BancoDeDadosClienteResponse>> GetBancoDeDadosClientesAsync(
        bool sincronizarInstancia = true,
        CancellationToken cancellationToken = default)
    {
        if (sincronizarInstancia)
        {
            await repository.SincronizarDescobertaBancosInstanciaAsync(cancellationToken: cancellationToken);
        }

        var pacotesAtivos = await dbContext.PacotesVersao
            .AsNoTracking()
            .Include(p => p.Arquivos)
            .Where(p => p.Ativo)
            .ToListAsync(cancellationToken);

        var versaoPadrao = ObterVersaoAlvoPadraoEfetiva(pacotesAtivos);

        var clientes = await dbContext.ClientesBancos
            .AsNoTracking()
            .OrderBy(c => c.Id)
            .ToListAsync(cancellationToken);

        var ultimosErrosPorCliente = await dbContext.ExecucoesScript
            .AsNoTracking()
            .Where(s => !s.Sucesso)
            .OrderByDescending(s => s.DataExecucao)
            .Take(100)
            .ToListAsync(cancellationToken);

        var agora = DateTime.UtcNow;
        var resposta = new List<BancoDeDadosClienteResponse>(clientes.Count);

        foreach (var c in clientes)
        {
            var pacotesPendentes = pacotesAtivos
                .Where(p => VersionComparer.Compare(p.NumeroVersao, c.VersaoAtualConhecida) > 0 &&
                            VersionComparer.Compare(p.NumeroVersao, versaoPadrao) <= 0)
                .OrderBy(p => p.NumeroVersao, Comparer<string>.Create(VersionComparer.Compare))
                .ToList();

            var qtdScriptsPendentes = pacotesPendentes.Sum(p => p.Arquivos.Count);
            var emExecucao = c.EmExecucaoLock && c.LockExpiracao.HasValue && c.LockExpiracao.Value > agora;

            var errosCliente = ultimosErrosPorCliente
                .Where(e => e.ClienteBancoId == c.Id)
                .Take(5)
                .Select(e => e.MensagemLog)
                .ToList();

            if (errosCliente.Count == 0 && !string.IsNullOrWhiteSpace(c.UltimoErroResumo))
            {
                errosCliente.Add(c.UltimoErroResumo);
            }

            resposta.Add(new BancoDeDadosClienteResponse
            {
                Id = c.Id,
                NomeEmpresa = c.NomeEmpresa,
                NomeBanco = c.NomeBanco,
                Servidor = c.Servidor,
                Datacenter = c.Datacenter,
                VersaoAtual = c.VersaoAtualConhecida,
                Status = emExecucao ? "Atualizando..." : c.Status,
                Aprovado = c.Aprovado,
                AtivoNaInstancia = c.AtivoNaInstancia,
                EmExecucao = emExecucao,
                QuantidadeScriptsPendentes = qtdScriptsPendentes,
                PacotesPendentes = pacotesPendentes.Select(p => p.NumeroVersao).ToList(),
                UltimaVerificacao = c.UltimaVerificacao,
                UltimaAtualizacao = c.UltimaAtualizacao,
                UltimoErroResumo = c.UltimoErroResumo,
                LogErros = errosCliente
            });
        }

        return resposta;
    }

    public async Task<BancoDeDadosClienteResponse> CadastrarClienteAsync(
        CriarClienteBancoRequest request,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(request.NomeEmpresa))
            throw new InvalidOperationException("Informe o nome da empresa.");
        if (string.IsNullOrWhiteSpace(request.NomeBanco))
            throw new InvalidOperationException("Informe o nome do banco de dados.");
        if (request.NomeBanco.Trim().StartsWith('_'))
            throw new InvalidOperationException("Bancos ativos não podem começar com '_' (convenção de bancos inativos da CenterSys).");

        var nomeBanco = request.NomeBanco.Trim();
        var servidor = string.IsNullOrWhiteSpace(request.Servidor) ? "SRV-SQL-01" : request.Servidor.Trim();
        var datacenter = string.IsNullOrWhiteSpace(request.Datacenter) ? "Datacenter 111" : request.Datacenter.Trim();
        var versaoInicial = string.IsNullOrWhiteSpace(request.VersaoInicial)
            ? "4.42.0.1"
            : VersionComparer.FormatCanonical(request.VersaoInicial);

        var jaExiste = await dbContext.ClientesBancos.AnyAsync(
            c => c.Servidor == servidor && c.NomeBanco == nomeBanco,
            cancellationToken);

        if (jaExiste)
            throw new InvalidOperationException($"O banco '{nomeBanco}' já está cadastrado no servidor '{servidor}'.");

        if (request.CriarBancoFisicoSeNaoExistir)
        {
            await repository.CriarEstruturaFisicaBancoClienteAsync(servidor, nomeBanco, versaoInicial, cancellationToken);
        }

        var (conectado, versaoReal, _) = await repository.LerVersaoRealBancoClienteAsync(servidor, nomeBanco, cancellationToken);
        var versaoEfetiva = !string.IsNullOrWhiteSpace(versaoReal) ? versaoReal : versaoInicial;
        var status = VersionComparer.Compare(versaoEfetiva, _settings.VersaoAlvoPadrao) >= 0
            ? "Atualizado"
            : "DESATUALIZADA";

        var novo = new ClienteBanco
        {
            NomeEmpresa = request.NomeEmpresa.Trim(),
            NomeBanco = nomeBanco,
            Servidor = servidor,
            Datacenter = datacenter,
            VersaoAtualConhecida = versaoEfetiva,
            Status = status,
            Aprovado = true,
            AtivoNaInstancia = conectado,
            UltimaVerificacao = DateTime.UtcNow
        };

        dbContext.ClientesBancos.Add(novo);
        await dbContext.SaveChangesAsync(cancellationToken);

        return new BancoDeDadosClienteResponse
        {
            Id = novo.Id,
            NomeEmpresa = novo.NomeEmpresa,
            NomeBanco = novo.NomeBanco,
            Servidor = novo.Servidor,
            Datacenter = novo.Datacenter,
            VersaoAtual = novo.VersaoAtualConhecida,
            Status = novo.Status,
            Aprovado = novo.Aprovado,
            AtivoNaInstancia = novo.AtivoNaInstancia,
            UltimaVerificacao = novo.UltimaVerificacao
        };
    }

    public async Task<BancoDeDadosClienteResponse> EditarClienteAsync(
        int id,
        EditarClienteBancoRequest request,
        CancellationToken cancellationToken = default)
    {
        var cliente = await dbContext.ClientesBancos.FirstOrDefaultAsync(c => c.Id == id, cancellationToken)
            ?? throw new KeyNotFoundException($"Cliente ID {id} não encontrado.");

        if (!string.IsNullOrWhiteSpace(request.NomeEmpresa))
            cliente.NomeEmpresa = request.NomeEmpresa.Trim();
        if (!string.IsNullOrWhiteSpace(request.Servidor))
            cliente.Servidor = request.Servidor.Trim();
        if (!string.IsNullOrWhiteSpace(request.Datacenter))
            cliente.Datacenter = request.Datacenter.Trim();

        cliente.Aprovado = request.Aprovado;
        await dbContext.SaveChangesAsync(cancellationToken);

        return new BancoDeDadosClienteResponse
        {
            Id = cliente.Id,
            NomeEmpresa = cliente.NomeEmpresa,
            NomeBanco = cliente.NomeBanco,
            Servidor = cliente.Servidor,
            Datacenter = cliente.Datacenter,
            VersaoAtual = cliente.VersaoAtualConhecida,
            Status = cliente.Status,
            Aprovado = cliente.Aprovado,
            AtivoNaInstancia = cliente.AtivoNaInstancia,
            UltimaVerificacao = cliente.UltimaVerificacao,
            UltimaAtualizacao = cliente.UltimaAtualizacao,
            UltimoErroResumo = cliente.UltimoErroResumo
        };
    }

    public async Task<TesteConexaoResponse> TestarConexaoClienteAsync(int id, CancellationToken cancellationToken = default)
    {
        var cliente = await repository.ObterClientePorIdAsync(id, cancellationToken)
            ?? throw new KeyNotFoundException($"Cliente ID {id} não encontrado.");

        return await repository.TestarConexaoClienteAsync(cliente, cancellationToken);
    }

    public async Task<IEnumerable<VersoesDisponiveisResponse>> GetVersoesDisponiveisAsync(CancellationToken cancellationToken = default)
    {
        await googleDriveService.SincronizarPacotesAsync(cancellationToken);

        var pacotes = await dbContext.PacotesVersao
            .AsNoTracking()
            .Include(p => p.Arquivos)
            .Where(p => p.Ativo)
            .ToListAsync(cancellationToken);

        return pacotes
            .OrderByDescending(p => p.NumeroVersao, Comparer<string>.Create(VersionComparer.Compare))
            .Select(MapearPacoteVersao)
            .ToList();
    }

    public async Task<VersoesDisponiveisResponse> CadastrarPacoteVersaoAsync(
        CadastrarPacoteVersaoRequest request,
        CancellationToken cancellationToken = default)
    {
        if (!VersionComparer.TryExtractVersion(request.NumeroVersao, out var versaoCanonica))
            throw new InvalidOperationException($"Formato de versão inválido: '{request.NumeroVersao}'. Exemplo válido: V4.49.0.0.");

        if (request.Arquivos is null || request.Arquivos.Count == 0)
            throw new InvalidOperationException("Informe ao menos um arquivo .sql para o pacote de versão.");

        var versaoNorm = VersionComparer.NormalizeForStorage(versaoCanonica);
        if (await dbContext.PacotesVersao.AnyAsync(p => p.VersaoNormalizada == versaoNorm, cancellationToken))
            throw new InvalidOperationException($"A versão '{versaoCanonica}' já está cadastrada.");

        var scriptsOrdenados = VersionComparer.OrderPackageScripts(request.Arquivos, a => a.NomeArquivo);
        var pacote = new PacoteVersao
        {
            NumeroVersao = versaoCanonica,
            VersaoNormalizada = versaoNorm,
            Descricao = string.IsNullOrWhiteSpace(request.Descricao)
                ? $"Pacote cadastrado via API ({versaoCanonica})"
                : request.Descricao.Trim(),
            Origem = "Upload",
            EhVersaoAlvoPadrao = request.DefinirComoPadrao,
            Ativo = true
        };

        var ordem = 1;
        foreach (var arq in scriptsOrdenados)
        {
            var analise = scriptAnalyzer.Analisar(arq.ConteudoSql, arq.NomeArquivo);
            if (!analise.Valido)
            {
                throw new InvalidOperationException(
                    $"Validação falhou para '{arq.NomeArquivo}': {string.Join(" | ", analise.ErrosBloqueantes)}");
            }

            pacote.Arquivos.Add(new ArquivoScript
            {
                NomeArquivo = Path.GetFileName(arq.NomeArquivo),
                OrdemExecucao = ordem++,
                ConteudoSql = arq.ConteudoSql,
                HashSha256 = analise.HashSha256,
                QuantidadeLotesGo = analise.Lotes.Count,
                ContemTransacaoInterna = analise.ContemTransacaoInterna,
                ContemOperacaoNaoTransacional = analise.ContemOperacaoNaoTransacional,
                AvisosValidacao = analise.Avisos.Count > 0 ? string.Join(" | ", analise.Avisos) : null
            });
        }

        if (request.DefinirComoPadrao)
        {
            await dbContext.PacotesVersao.ExecuteUpdateAsync(
                s => s.SetProperty(p => p.EhVersaoAlvoPadrao, false),
                cancellationToken);
        }

        dbContext.PacotesVersao.Add(pacote);
        await dbContext.SaveChangesAsync(cancellationToken);

        return MapearPacoteVersao(pacote);
    }

    public async Task<IEnumerable<BancosAtualizadosResponse>> AtualizarBancoDeDadosAsync(
        AtualizarVersoesRequest request,
        string disparadoPor = "Operador",
        string origem = "Manual",
        CancellationToken cancellationToken = default)
    {
        var lote = await CriarRegistroLoteInicialAsync(request, disparadoPor, origem, cancellationToken);
        var tokenLote = cancellationManager.RegistrarLote(lote.Id);
        using var linkedCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, tokenLote);

        try
        {
            await ProcessarLoteInternoAsync(lote.Id, request.PermiteOperacaoNaoTransacional, linkedCts.Token);
        }
        finally
        {
            cancellationManager.RemoverLote(lote.Id);
        }

        var statusFinal = await ObterStatusLoteAsync(lote.Id, CancellationToken.None);
        return statusFinal?.Bancos ?? [];
    }

    public async Task<StatusLoteExecucaoResponse> IniciarLoteAssincronoAsync(
        AtualizarVersoesRequest request,
        string disparadoPor = "Operador",
        string origem = "Manual",
        CancellationToken cancellationToken = default)
    {
        var lote = await CriarRegistroLoteInicialAsync(request, disparadoPor, origem, cancellationToken);
        var tokenLote = cancellationManager.RegistrarLote(lote.Id);
        var permiteNaoTransacional = request.PermiteOperacaoNaoTransacional;

        _ = Task.Run(async () =>
        {
            try
            {
                using var scope = scopeFactory.CreateScope();
                var scopedService = scope.ServiceProvider.GetRequiredService<VersaoService>();
                await scopedService.ProcessarLoteInternoAsync(lote.Id, permiteNaoTransacional, tokenLote);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Erro crítico não tratado no processamento em background do Lote #{LoteId}.", lote.Id);
            }
            finally
            {
                cancellationManager.RemoverLote(lote.Id);
            }
        }, CancellationToken.None);

        return (await ObterStatusLoteAsync(lote.Id, cancellationToken))!;
    }

    public async Task<bool> CancelarLoteAsync(int loteId, CancellationToken cancellationToken = default)
    {
        var lote = await dbContext.ExecucoesLote.FirstOrDefaultAsync(l => l.Id == loteId, cancellationToken);
        if (lote is null || lote.StatusLote != "EmExecucao")
            return false;

        lote.CancelamentoSolicitado = true;
        dbContext.LogsEventos.Add(new LogEventoLote
        {
            ExecucaoLoteId = loteId,
            Nivel = "WARN",
            Mensagem = $"Solicitação de cancelamento recebida para o Lote #{loteId}. Revertendo transação corrente / interrompendo próximos itens."
        });
        await dbContext.SaveChangesAsync(cancellationToken);

        cancellationManager.SolicitarCancelamento(loteId);
        return true;
    }

    public async Task<StatusLoteExecucaoResponse?> ObterStatusLoteAsync(int loteId, CancellationToken cancellationToken = default)
    {
        var lote = await dbContext.ExecucoesLote
            .AsNoTracking()
            .Include(l => l.Bancos)
            .Include(l => l.Logs)
            .FirstOrDefaultAsync(l => l.Id == loteId, cancellationToken);

        if (lote is null)
            return null;

        var logsOrdenados = lote.Logs
            .OrderBy(lg => lg.Id)
            .Select(MapearLogEvento)
            .ToList();

        var bancosDto = lote.Bancos
            .OrderBy(b => b.Id)
            .Select(b => new BancosAtualizadosResponse
            {
                Id = b.ClienteBancoId,
                ExecucaoLoteId = lote.Id,
                NomeEmpresa = b.NomeEmpresa,
                NomeBanco = b.NomeBanco,
                Servidor = b.Servidor,
                Datacenter = b.Datacenter,
                VersaoAnterior = b.VersaoOrigem,
                VersaoAlvo = b.VersaoAlvo,
                VersaoAtual = b.VersaoAlcancada,
                Status = b.Status,
                ProgressoPercentual = b.ProgressoPercentual,
                EtapaAtual = b.EtapaAtual,
                Mensagem = b.MensagemResumo,
                Sucesso = b.Sucesso,
                Logs = logsOrdenados.Where(l => l.Db == b.NomeBanco).ToList()
            })
            .ToList();

        var progressoGeral = bancosDto.Count > 0
            ? (int)Math.Round(bancosDto.Average(b => b.ProgressoPercentual))
            : 0;

        return new StatusLoteExecucaoResponse
        {
            LoteId = lote.Id,
            DisparadoPor = lote.DisparadoPor,
            Origem = lote.Origem,
            StatusLote = lote.StatusLote,
            TotalBancos = lote.TotalBancos,
            TotalSucesso = lote.TotalSucesso,
            TotalFalha = lote.TotalFalha,
            TotalCancelado = lote.TotalCancelado,
            ProgressoGeralPercentual = progressoGeral,
            EmExecucao = lote.StatusLote == "EmExecucao",
            CancelamentoSolicitado = lote.CancelamentoSolicitado,
            DataInicio = lote.DataInicio,
            DataFim = lote.DataFim,
            Bancos = bancosDto,
            Logs = logsOrdenados
        };
    }

    public async Task<IEnumerable<HistoricoExecucaoResumoDto>> ObterHistoricoExecucoesAsync(
        int limite = 25,
        CancellationToken cancellationToken = default)
    {
        var lotes = await dbContext.ExecucoesLote
            .AsNoTracking()
            .Include(l => l.Bancos)
            .OrderByDescending(l => l.DataInicio)
            .Take(Math.Clamp(limite, 1, 100))
            .ToListAsync(cancellationToken);

        return lotes.Select(l => new HistoricoExecucaoResumoDto
        {
            LoteId = l.Id,
            DisparadoPor = l.DisparadoPor,
            Origem = l.Origem,
            StatusLote = l.StatusLote,
            TotalBancos = l.TotalBancos,
            TotalSucesso = l.TotalSucesso,
            TotalFalha = l.TotalFalha,
            TotalCancelado = l.TotalCancelado,
            DataInicio = l.DataInicio,
            DataFim = l.DataFim,
            Bancos = l.Bancos.OrderBy(b => b.Id).Select(b => new BancosAtualizadosResponse
            {
                Id = b.ClienteBancoId,
                ExecucaoLoteId = l.Id,
                NomeEmpresa = b.NomeEmpresa,
                NomeBanco = b.NomeBanco,
                Servidor = b.Servidor,
                Datacenter = b.Datacenter,
                VersaoAnterior = b.VersaoOrigem,
                VersaoAlvo = b.VersaoAlvo,
                VersaoAtual = b.VersaoAlcancada,
                Status = b.Status,
                ProgressoPercentual = b.ProgressoPercentual,
                EtapaAtual = b.EtapaAtual,
                Mensagem = b.MensagemResumo,
                Sucesso = b.Sucesso
            }).ToList()
        }).ToList();
    }

    public async Task<IEnumerable<LogExecucaoDto>> ObterLogsRecentesAsync(
        int? loteId = null,
        int? clienteBancoId = null,
        int limite = 200,
        CancellationToken cancellationToken = default)
    {
        var query = dbContext.LogsEventos.AsNoTracking().AsQueryable();
        if (loteId.HasValue)
            query = query.Where(l => l.ExecucaoLoteId == loteId.Value);
        if (clienteBancoId.HasValue)
            query = query.Where(l => l.ClienteBancoId == clienteBancoId.Value);

        var logs = await query
            .OrderByDescending(l => l.Id)
            .Take(Math.Clamp(limite, 1, 500))
            .ToListAsync(cancellationToken);

        return logs.OrderBy(l => l.Id).Select(MapearLogEvento).ToList();
    }

    private async Task<ExecucaoLote> CriarRegistroLoteInicialAsync(
        AtualizarVersoesRequest request,
        string disparadoPor,
        string origem,
        CancellationToken cancellationToken)
    {
        if (request?.Versoes is null || request.Versoes.Count == 0)
            throw new InvalidOperationException("Selecione ao menos um banco de dados para iniciar a atualização.");

        await googleDriveService.SincronizarPacotesAsync(cancellationToken);

        var lote = new ExecucaoLote
        {
            DisparadoPor = string.IsNullOrWhiteSpace(disparadoPor) ? "Operador" : disparadoPor,
            Origem = origem,
            TotalBancos = request.Versoes.Count,
            StatusLote = "EmExecucao",
            DataInicio = DateTime.UtcNow
        };

        foreach (var item in request.Versoes)
        {
            ClienteBanco? cliente = null;
            if (item.IdClienteBanco.HasValue)
            {
                cliente = await repository.ObterClientePorIdAsync(item.IdClienteBanco.Value, cancellationToken);
            }
            cliente ??= await repository.ObterClientePorNomeBancoOuEmpresaAsync(item.NomeBanco, item.NomeEmpresa, cancellationToken);

            if (cliente is null)
            {
                throw new KeyNotFoundException(
                    $"Banco/Empresa não encontrado no catálogo aprovado: '{item.NomeBanco ?? item.NomeEmpresa}'.");
            }

            var ehCustom = !string.IsNullOrWhiteSpace(item.ScriptCustomizadoConteudo);
            var nomeCustom = !string.IsNullOrWhiteSpace(item.NomeScriptCustomizado)
                ? item.NomeScriptCustomizado
                : ehCustom ? item.VersaoAlvo : null;

            lote.Bancos.Add(new ExecucaoBanco
            {
                ClienteBancoId = cliente.Id,
                NomeEmpresa = cliente.NomeEmpresa,
                NomeBanco = cliente.NomeBanco,
                Servidor = cliente.Servidor,
                Datacenter = cliente.Datacenter,
                VersaoOrigem = cliente.VersaoAtualConhecida,
                VersaoAlvo = string.IsNullOrWhiteSpace(item.VersaoAlvo) ? _settings.VersaoAlvoPadrao : item.VersaoAlvo.Trim(),
                VersaoAlcancada = cliente.VersaoAtualConhecida,
                EhScriptCustomizado = ehCustom,
                NomeScriptCustomizado = nomeCustom,
                ConteudoScriptCustomizado = item.ScriptCustomizadoConteudo,
                Status = "Pendente",
                ProgressoPercentual = 0,
                EtapaAtual = "Aguardando fila"
            });
        }

        lote.Logs.Add(new LogEventoLote
        {
            Nivel = "SYSTEM",
            Mensagem = $"──── Lote #{lote.Bancos.Count} banco(s) enfileirado(s) por {lote.DisparadoPor} ({lote.Origem}) ────"
        });

        dbContext.ExecucoesLote.Add(lote);
        await dbContext.SaveChangesAsync(cancellationToken);

        return lote;
    }

    public async Task ProcessarLoteInternoAsync(
        int loteId,
        bool permiteOperacaoNaoTransacional,
        CancellationToken cancellationToken)
    {
        var lote = await dbContext.ExecucoesLote
            .Include(l => l.Bancos)
            .FirstOrDefaultAsync(l => l.Id == loteId, CancellationToken.None);

        if (lote is null)
            return;

        var pacotesAtivos = await dbContext.PacotesVersao
            .AsNoTracking()
            .Include(p => p.Arquivos)
            .Where(p => p.Ativo)
            .ToListAsync(CancellationToken.None);

        await RegistrarLogLoteAsync(
            lote.Id,
            null,
            null,
            "SYSTEM",
            $"──── Iniciando processamento do Lote #{lote.Id} · {lote.Bancos.Count} banco(s) selecionado(s) ────");

        foreach (var execBanco in lote.Bancos.OrderBy(b => b.Id))
        {
            if (cancellationToken.IsCancellationRequested || lote.CancelamentoSolicitado)
            {
                execBanco.Status = "Cancelado";
                execBanco.EtapaAtual = "Cancelado antes de iniciar";
                execBanco.MensagemResumo = "Operação cancelada pelo operador.";
                execBanco.DataFim = DateTime.UtcNow;
                lote.TotalCancelado++;
                await dbContext.SaveChangesAsync(CancellationToken.None);
                continue;
            }

            await ProcessarBancoIndividualAsync(
                lote,
                execBanco,
                pacotesAtivos,
                permiteOperacaoNaoTransacional,
                cancellationToken);
        }

        lote.DataFim = DateTime.UtcNow;
        lote.StatusLote = lote.TotalCancelado > 0
            ? "Cancelado"
            : lote.TotalFalha > 0 ? "ConcluidoComFalhas" : "Concluido";

        await RegistrarLogLoteAsync(
            lote.Id,
            null,
            null,
            lote.TotalFalha > 0 ? "WARN" : "SYSTEM",
            $"──── Lote #{lote.Id} finalizado · {lote.TotalSucesso} sucesso(s), {lote.TotalFalha} falha(s), {lote.TotalCancelado} cancelado(s) ────");

        await dbContext.SaveChangesAsync(CancellationToken.None);
    }

    private async Task ProcessarBancoIndividualAsync(
        ExecucaoLote lote,
        ExecucaoBanco execBanco,
        List<PacoteVersao> pacotesDisponiveis,
        bool permiteOperacaoNaoTransacional,
        CancellationToken cancellationToken)
    {
        var cliente = await dbContext.ClientesBancos
            .FirstOrDefaultAsync(c => c.Id == execBanco.ClienteBancoId, CancellationToken.None);

        if (cliente is null)
            return;

        if (!cliente.Aprovado)
        {
            await FinalizarBancoComFalhaAsync(
                lote,
                execBanco,
                cliente,
                "Operação bloqueada: banco não está aprovado no catálogo do orquestrador.");
            return;
        }

        var lockToken = Guid.NewGuid().ToString("N");
        var duracaoLock = TimeSpan.FromMinutes(Math.Max(2, _settings.LockTimeoutMinutos));

        await AtualizarProgressoBancoAsync(execBanco, cliente, 10, "Adquirindo lock");
        await RegistrarLogLoteAsync(lote.Id, cliente.Id, cliente.NomeBanco, "INFO",
            $"Adquirindo reserva exclusiva de execução (Lock) em {cliente.NomeBanco}...");

        var lockAdquirido = await repository.TentarAdquirirLockBancoAsync(
            cliente.Id,
            lockToken,
            duracaoLock,
            CancellationToken.None);

        if (!lockAdquirido)
        {
            await FinalizarBancoComFalhaAsync(
                lote,
                execBanco,
                cliente,
                $"Não foi possível adquirir lock exclusivo em '{cliente.NomeBanco}': já existe outra atualização em andamento.");
            return;
        }

        var statusAnteriorCliente = cliente.Status;
        cliente.Status = "Atualizando...";
        await dbContext.SaveChangesAsync(CancellationToken.None);

        try
        {
            await AtualizarProgressoBancoAsync(execBanco, cliente, 25, "Lendo versão atual");
            var (conectado, versaoLida, erroLeitura) = await repository.LerVersaoRealBancoClienteAsync(
                cliente.Servidor,
                cliente.NomeBanco,
                cancellationToken);

            if (!conectado || string.IsNullOrWhiteSpace(versaoLida))
            {
                await FinalizarBancoComFalhaAsync(
                    lote,
                    execBanco,
                    cliente,
                    $"Falha ao ler {_settings.TabelaVersaoCliente}.{_settings.ColunaVersaoCliente} em '{cliente.NomeBanco}': {erroLeitura}");
                return;
            }

            execBanco.VersaoOrigem = versaoLida;
            execBanco.VersaoAlcancada = versaoLida;
            cliente.VersaoAtualConhecida = versaoLida;

            await RegistrarLogLoteAsync(lote.Id, cliente.Id, cliente.NomeBanco, "INFO",
                $"Versão oficial lida em {_settings.TabelaVersaoCliente}: {versaoLida}.");

            if (execBanco.EhScriptCustomizado && !string.IsNullOrWhiteSpace(execBanco.ConteudoScriptCustomizado))
            {
                await ExecutarFluxoScriptCustomizadoAsync(
                    lote,
                    execBanco,
                    cliente,
                    permiteOperacaoNaoTransacional,
                    cancellationToken);
            }
            else
            {
                await ExecutarFluxoPacotesOficiaisAsync(
                    lote,
                    execBanco,
                    cliente,
                    versaoLida,
                    pacotesDisponiveis,
                    permiteOperacaoNaoTransacional,
                    cancellationToken);
            }
        }
        catch (OperationCanceledException)
        {
            cliente.Status = statusAnteriorCliente == "Atualizando..." ? "Pendente" : statusAnteriorCliente;
            execBanco.Status = "Cancelado";
            execBanco.EtapaAtual = "Cancelado";
            execBanco.MensagemResumo = "Execução interrompida por solicitação de cancelamento (ROLLBACK garantido).";
            execBanco.DataFim = DateTime.UtcNow;
            lote.TotalCancelado++;

            await RegistrarLogLoteAsync(lote.Id, cliente.Id, cliente.NomeBanco, "WARN",
                $"Atualização cancelada em {cliente.NomeBanco}. Versão mantida em {cliente.VersaoAtualConhecida}.");
            await dbContext.SaveChangesAsync(CancellationToken.None);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Erro inesperado ao atualizar banco {NomeBanco}.", cliente.NomeBanco);
            await FinalizarBancoComFalhaAsync(
                lote,
                execBanco,
                cliente,
                $"Erro interno durante atualização de '{cliente.NomeBanco}': {ex.Message}");
        }
        finally
        {
            await repository.LiberarLockBancoAsync(cliente.Id, lockToken, CancellationToken.None);
        }
    }

    private async Task ExecutarFluxoScriptCustomizadoAsync(
        ExecucaoLote lote,
        ExecucaoBanco execBanco,
        ClienteBanco cliente,
        bool permiteOperacaoNaoTransacional,
        CancellationToken cancellationToken)
    {
        var nomeScript = execBanco.NomeScriptCustomizado ?? "script_customizado.sql";
        await AtualizarProgressoBancoAsync(execBanco, cliente, 45, "Validando SHA-256 e AST");
        await RegistrarLogLoteAsync(lote.Id, cliente.Id, cliente.NomeBanco, "INFO",
            $"Executando pré-varredura sintática (ScriptDom) e cálculo SHA-256 em '{nomeScript}'...");

        var analise = scriptAnalyzer.Analisar(execBanco.ConteudoScriptCustomizado!, nomeScript);
        if (!analise.Valido)
        {
            var motivo = string.Join(" | ", analise.ErrosBloqueantes);
            RegistrarExecucaoScriptEntidade(execBanco, cliente.Id, nomeScript, nomeScript, analise.HashSha256, 1, false, false, false, 0, null, null, "WARN", motivo);
            await FinalizarBancoComFalhaAsync(lote, execBanco, cliente, motivo);
            return;
        }

        if (await repository.ScriptJaAplicadoComSucessoAsync(cliente.Id, analise.HashSha256, cancellationToken))
        {
            var msgIdempotente = $"Script customizado '{nomeScript}' (SHA-256 {analise.HashSha256[..12]}...) já foi aplicado anteriormente neste banco. Execução duplicada bloqueada com segurança.";
            await RegistrarLogLoteAsync(lote.Id, cliente.Id, cliente.NomeBanco, "INFO", msgIdempotente);
            RegistrarExecucaoScriptEntidade(execBanco, cliente.Id, nomeScript, nomeScript, analise.HashSha256, 1, true, true, false, 0, null, null, "INFO", msgIdempotente);
        }
        else
        {
            await AtualizarProgressoBancoAsync(execBanco, cliente, 75, "Aplicando script");
            await RegistrarLogLoteAsync(lote.Id, cliente.Id, cliente.NomeBanco, "EXEC",
                $"Aplicando '{nomeScript}' ({analise.Lotes.Count} lote(s) T-SQL) em transação isolada...");

            var resultado = await repository.ExecutarArquivoScriptAsync(
                cliente.Servidor,
                cliente.NomeBanco,
                analise,
                versaoFinalParaGravarNoCommit: null,
                permiteOperacaoNaoTransacional,
                cancellationToken);

            RegistrarExecucaoScriptEntidade(
                execBanco,
                cliente.Id,
                nomeScript,
                nomeScript,
                analise.HashSha256,
                1,
                resultado.Sucesso,
                false,
                resultado.ModoNaoTransacional,
                resultado.DuracaoMs,
                resultado.NumeroErroSql,
                resultado.LinhaErroSql,
                resultado.Sucesso ? "SUCCESS" : "WARN",
                resultado.Mensagem);

            if (!resultado.Sucesso)
            {
                await FinalizarBancoComFalhaAsync(lote, execBanco, cliente, resultado.Mensagem);
                return;
            }
        }

        var (_, novaVersaoLida, _) = await repository.LerVersaoRealBancoClienteAsync(
            cliente.Servidor,
            cliente.NomeBanco,
            CancellationToken.None);

        var versaoFinal = !string.IsNullOrWhiteSpace(novaVersaoLida) ? novaVersaoLida : cliente.VersaoAtualConhecida;
        await FinalizarBancoComSucessoAsync(
            lote,
            execBanco,
            cliente,
            versaoFinal,
            $"Script customizado '{nomeScript}' concluído com sucesso em {cliente.NomeBanco} (versão atual: {versaoFinal}).");
    }

    private async Task ExecutarFluxoPacotesOficiaisAsync(
        ExecucaoLote lote,
        ExecucaoBanco execBanco,
        ClienteBanco cliente,
        string versaoOrigemReal,
        List<PacoteVersao> pacotesDisponiveis,
        bool permiteOperacaoNaoTransacional,
        CancellationToken cancellationToken)
    {
        var versaoAlvoCanonica = VersionComparer.FormatCanonical(execBanco.VersaoAlvo);

        if (VersionComparer.Compare(versaoOrigemReal, versaoAlvoCanonica) >= 0)
        {
            await FinalizarBancoComSucessoAsync(
                lote,
                execBanco,
                cliente,
                versaoOrigemReal,
                $"O banco {cliente.NomeBanco} já se encontra alinhado ou acima da versão alvo ({versaoOrigemReal}). Nenhum script pendente.");
            return;
        }

        var pacotesParaAplicar = pacotesDisponiveis
            .Where(p => VersionComparer.Compare(p.NumeroVersao, versaoOrigemReal) > 0 &&
                        VersionComparer.Compare(p.NumeroVersao, versaoAlvoCanonica) <= 0)
            .OrderBy(p => p.NumeroVersao, Comparer<string>.Create(VersionComparer.Compare))
            .ToList();

        if (pacotesParaAplicar.Count == 0)
        {
            await FinalizarBancoComFalhaAsync(
                lote,
                execBanco,
                cliente,
                $"Nenhum pacote de scripts encontrado para levar '{cliente.NomeBanco}' de {versaoOrigemReal} até {versaoAlvoCanonica}.");
            return;
        }

        // Fase 1: Pré-varredura obrigatória de todos os arquivos antes de executar (Decisão 9.3)
        await AtualizarProgressoBancoAsync(execBanco, cliente, 45, "Validando SHA-256");
        var filaExecucao = new List<(PacoteVersao Pacote, ArquivoScript Arquivo, AnaliseScriptResultado Analise, bool EhUltimoDoPacote)>();

        foreach (var pacote in pacotesParaAplicar)
        {
            var arquivosOrdenados = VersionComparer.OrderPackageScripts(pacote.Arquivos, a => a.NomeArquivo);
            for (var i = 0; i < arquivosOrdenados.Count; i++)
            {
                var arq = arquivosOrdenados[i];
                var analise = scriptAnalyzer.Analisar(arq.ConteudoSql, arq.NomeArquivo);
                if (!analise.Valido)
                {
                    var erroValidacao = $"Pré-varredura reprovou '{arq.NomeArquivo}' do pacote {pacote.NumeroVersao}: {string.Join(" | ", analise.ErrosBloqueantes)}";
                    RegistrarExecucaoScriptEntidade(execBanco, cliente.Id, pacote.NumeroVersao, arq.NomeArquivo, analise.HashSha256, arq.OrdemExecucao, false, false, false, 0, null, null, "WARN", erroValidacao);
                    await FinalizarBancoComFalhaAsync(lote, execBanco, cliente, erroValidacao);
                    return;
                }

                filaExecucao.Add((pacote, arq, analise, i == arquivosOrdenados.Count - 1));
            }
        }

        await RegistrarLogLoteAsync(lote.Id, cliente.Id, cliente.NomeBanco, "INFO",
            $"Pré-varredura aprovada: {pacotesParaAplicar.Count} pacote(s) ({string.Join(" → ", pacotesParaAplicar.Select(p => p.NumeroVersao))}) totalizando {filaExecucao.Count} script(s).");

        // Fase 2: Execução sequencial transacional por arquivo
        var versaoAlcancada = versaoOrigemReal;
        for (var idx = 0; idx < filaExecucao.Count; idx++)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var (pacote, arquivo, analise, ehUltimoDoPacote) = filaExecucao[idx];

            var pct = 50 + (int)Math.Round(((idx + 0.5) / filaExecucao.Count) * 45);
            await AtualizarProgressoBancoAsync(execBanco, cliente, Math.Min(95, pct), $"Aplicando {pacote.NumeroVersao}");

            var jaAplicado = await repository.ScriptJaAplicadoComSucessoAsync(cliente.Id, analise.HashSha256, cancellationToken);
            if (jaAplicado && !ehUltimoDoPacote)
            {
                var msgSkip = $"[{pacote.NumeroVersao}] Script '{arquivo.NomeArquivo}' já aplicado anteriormente (SHA-256 idêntico) — pulando com segurança.";
                await RegistrarLogLoteAsync(lote.Id, cliente.Id, cliente.NomeBanco, "INFO", msgSkip);
                RegistrarExecucaoScriptEntidade(execBanco, cliente.Id, pacote.NumeroVersao, arquivo.NomeArquivo, analise.HashSha256, arquivo.OrdemExecucao, true, true, false, 0, null, null, "INFO", msgSkip);
                continue;
            }

            await RegistrarLogLoteAsync(lote.Id, cliente.Id, cliente.NomeBanco, "EXEC",
                $"[{pacote.NumeroVersao}] Executando '{arquivo.NomeArquivo}' ({analise.Lotes.Count} lote(s) GO)...");

            var versaoGravar = ehUltimoDoPacote ? pacote.NumeroVersao : null;
            var resultado = await repository.ExecutarArquivoScriptAsync(
                cliente.Servidor,
                cliente.NomeBanco,
                analise,
                versaoGravar,
                permiteOperacaoNaoTransacional,
                cancellationToken);

            RegistrarExecucaoScriptEntidade(
                execBanco,
                cliente.Id,
                pacote.NumeroVersao,
                arquivo.NomeArquivo,
                analise.HashSha256,
                arquivo.OrdemExecucao,
                resultado.Sucesso,
                false,
                resultado.ModoNaoTransacional,
                resultado.DuracaoMs,
                resultado.NumeroErroSql,
                resultado.LinhaErroSql,
                resultado.Sucesso ? "SUCCESS" : "WARN",
                resultado.Mensagem);

            if (!resultado.Sucesso)
            {
                // Se pacotes anteriores no mesmo lote já comitaram, preserva a versão efetivamente alcançada até então
                execBanco.VersaoAlcancada = versaoAlcancada;
                cliente.VersaoAtualConhecida = versaoAlcancada;
                await FinalizarBancoComFalhaAsync(lote, execBanco, cliente, resultado.Mensagem);
                return;
            }

            if (ehUltimoDoPacote)
            {
                versaoAlcancada = pacote.NumeroVersao;
                execBanco.VersaoAlcancada = versaoAlcancada;
                cliente.VersaoAtualConhecida = versaoAlcancada;
                cliente.UltimaAtualizacao = DateTime.UtcNow;
                await RegistrarLogLoteAsync(lote.Id, cliente.Id, cliente.NomeBanco, "SUCCESS",
                    $"Pacote {pacote.NumeroVersao} consolidado com COMMIT em {cliente.NomeBanco}.");
            }
        }

        await FinalizarBancoComSucessoAsync(
            lote,
            execBanco,
            cliente,
            versaoAlcancada,
            $"Commit realizado! Versão atualizada com sucesso em {cliente.NomeBanco} ({versaoOrigemReal} → {versaoAlcancada}).");
    }

    private async Task AtualizarProgressoBancoAsync(ExecucaoBanco execBanco, ClienteBanco cliente, int percentual, string etapa)
    {
        execBanco.Status = "Atualizando...";
        execBanco.ProgressoPercentual = percentual;
        execBanco.EtapaAtual = etapa;
        cliente.Status = "Atualizando...";
        await dbContext.SaveChangesAsync(CancellationToken.None);
    }

    private async Task FinalizarBancoComSucessoAsync(
        ExecucaoLote lote,
        ExecucaoBanco execBanco,
        ClienteBanco cliente,
        string versaoFinal,
        string mensagemSucesso)
    {
        var alvoGlobal = _settings.VersaoAlvoPadrao;
        var alinhadoAoPadrao = VersionComparer.Compare(versaoFinal, alvoGlobal) >= 0;

        execBanco.VersaoAlcancada = versaoFinal;
        execBanco.Status = "Atualizado";
        execBanco.ProgressoPercentual = 100;
        execBanco.EtapaAtual = "Concluído";
        execBanco.Sucesso = true;
        execBanco.MensagemResumo = mensagemSucesso;
        execBanco.DataFim = DateTime.UtcNow;

        cliente.VersaoAtualConhecida = versaoFinal;
        cliente.Status = alinhadoAoPadrao ? "Atualizado" : "Pendente";
        cliente.UltimaAtualizacao = DateTime.UtcNow;
        cliente.UltimaVerificacao = DateTime.UtcNow;
        cliente.UltimoErroResumo = null;

        lote.TotalSucesso++;

        await RegistrarLogLoteAsync(lote.Id, cliente.Id, cliente.NomeBanco, "SUCCESS", mensagemSucesso);
        await dbContext.SaveChangesAsync(CancellationToken.None);
    }

    private async Task FinalizarBancoComFalhaAsync(
        ExecucaoLote lote,
        ExecucaoBanco execBanco,
        ClienteBanco cliente,
        string mensagemErro)
    {
        execBanco.Status = "Falha";
        execBanco.EtapaAtual = "Falha (Rollback)";
        execBanco.Sucesso = false;
        execBanco.MensagemResumo = mensagemErro;
        execBanco.DataFim = DateTime.UtcNow;

        cliente.Status = "Falha";
        cliente.UltimaVerificacao = DateTime.UtcNow;
        cliente.UltimoErroResumo = mensagemErro.Length > 980 ? mensagemErro[..980] : mensagemErro;

        lote.TotalFalha++;

        await RegistrarLogLoteAsync(lote.Id, cliente.Id, cliente.NomeBanco, "WARN", mensagemErro);
        await dbContext.SaveChangesAsync(CancellationToken.None);
    }

    private void RegistrarExecucaoScriptEntidade(
        ExecucaoBanco execBanco,
        int clienteBancoId,
        string versaoPacote,
        string nomeArquivo,
        string hashSha256,
        int ordemExecucao,
        bool sucesso,
        bool ignoradoIdempotencia,
        bool modoNaoTransacional,
        int duracaoMs,
        int? numeroErroSql,
        int? linhaErroSql,
        string nivelLog,
        string mensagemLog)
    {
        dbContext.ExecucoesScript.Add(new ExecucaoScript
        {
            ExecucaoBancoId = execBanco.Id,
            ClienteBancoId = clienteBancoId,
            VersaoPacote = versaoPacote,
            NomeArquivo = nomeArquivo,
            HashSha256 = hashSha256,
            OrdemExecucao = ordemExecucao,
            Sucesso = sucesso,
            IgnoradoIdempotencia = ignoradoIdempotencia,
            ModoNaoTransacional = modoNaoTransacional,
            DuracaoMs = duracaoMs,
            NumeroErroSql = numeroErroSql,
            LinhaErroSql = linhaErroSql,
            NivelLog = nivelLog,
            MensagemLog = mensagemLog,
            DataExecucao = DateTime.UtcNow
        });
    }

    private async Task RegistrarLogLoteAsync(
        int loteId,
        int? clienteBancoId,
        string? nomeBanco,
        string nivel,
        string mensagem)
    {
        dbContext.LogsEventos.Add(new LogEventoLote
        {
            ExecucaoLoteId = loteId,
            ClienteBancoId = clienteBancoId,
            NomeBanco = nomeBanco,
            Nivel = nivel,
            Mensagem = mensagem,
            DataHora = DateTime.UtcNow
        });
        await dbContext.SaveChangesAsync(CancellationToken.None);
    }

    private string ObterVersaoAlvoPadraoEfetiva(List<PacoteVersao> pacotes)
    {
        var padraoDb = pacotes.FirstOrDefault(p => p.EhVersaoAlvoPadrao)?.NumeroVersao;
        if (!string.IsNullOrWhiteSpace(padraoDb))
            return padraoDb;

        return VersionComparer.FormatCanonical(_settings.VersaoAlvoPadrao);
    }

    private static VersoesDisponiveisResponse MapearPacoteVersao(PacoteVersao p)
    {
        return new VersoesDisponiveisResponse
        {
            Id = p.Id,
            Versao = p.NumeroVersao,
            Descricao = p.Descricao,
            Origem = p.Origem,
            IdPastaDrive = p.CaminhoOuDriveId,
            Padrao = p.EhVersaoAlvoPadrao,
            QuantidadeScripts = p.Arquivos.Count,
            CriadoEm = p.CriadoEm,
            Arquivos = p.Arquivos
                .OrderBy(a => a.OrdemExecucao)
                .Select(a => new ArquivoScriptResumoDto
                {
                    Id = a.Id,
                    NomeArquivo = a.NomeArquivo,
                    OrdemExecucao = a.OrdemExecucao,
                    HashSha256 = a.HashSha256,
                    QuantidadeLotesGo = a.QuantidadeLotesGo,
                    ContemTransacaoInterna = a.ContemTransacaoInterna,
                    ContemOperacaoNaoTransacional = a.ContemOperacaoNaoTransacional,
                    AvisosValidacao = a.AvisosValidacao
                }).ToList()
        };
    }

    private static LogExecucaoDto MapearLogEvento(LogEventoLote lg)
    {
        var local = lg.DataHora.ToLocalTime();
        return new LogExecucaoDto
        {
            Id = lg.Id,
            Time = $"{local:HH:mm:ss}.{local.Millisecond:D3}",
            Level = lg.Nivel,
            Db = lg.NomeBanco,
            Message = lg.Mensagem,
            DataHoraUtc = lg.DataHora
        };
    }
}
