namespace Centersys.AtualizadorVersoes.Api.Services;

public interface IGoogleDriveService
{
    Task<Stream> BaixarArquivoAsync(string idArquivo, CancellationToken cancellationToken = default);
    Task<int> SincronizarPacotesAsync(CancellationToken cancellationToken = default);
}
