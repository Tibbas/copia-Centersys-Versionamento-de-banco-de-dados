using System.Security.Cryptography;
using System.Text;
using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace Centersys.AtualizadorVersoes.Api.Services;

public sealed class AnaliseScriptResultado
{
    public required string NomeArquivo { get; init; }
    public required string HashSha256 { get; init; }
    public required List<LoteSqlExtraido> Lotes { get; init; }
    public bool Valido { get; init; }
    public bool ContemComandoUse { get; init; }
    public bool ContemTransacaoInterna { get; init; }
    public bool ContemRollbackExplicito { get; init; }
    public bool ContemOperacaoNaoTransacional { get; init; }
    public int QuantidadeBeginTran { get; init; }
    public int QuantidadeCommitTran { get; init; }
    public int QuantidadeRollbackTran { get; init; }
    public List<string> ErrosBloqueantes { get; init; } = [];
    public List<string> Avisos { get; init; } = [];
}

public sealed record LoteSqlExtraido(int Indice, int LinhaInicial, string SqlTexto);

public interface ISqlScriptAnalyzer
{
    AnaliseScriptResultado Analisar(string conteudoSql, string nomeArquivo = "script.sql");
    string CalcularSha256(string conteudoSql);
}

public sealed class SqlScriptAnalyzer : ISqlScriptAnalyzer
{
    public string CalcularSha256(string conteudoSql)
    {
        var normalizado = (conteudoSql ?? string.Empty).Replace("\r\n", "\n").Trim();
        var bytes = Encoding.UTF8.GetBytes(normalizado);
        var hash = SHA256.HashData(bytes);
        return Convert.ToHexStringLower(hash);
    }

    public AnaliseScriptResultado Analisar(string conteudoSql, string nomeArquivo = "script.sql")
    {
        var erros = new List<string>();
        var avisos = new List<string>();
        var lotes = new List<LoteSqlExtraido>();
        var hash = CalcularSha256(conteudoSql ?? string.Empty);

        if (string.IsNullOrWhiteSpace(conteudoSql))
        {
            erros.Add($"O arquivo '{nomeArquivo}' está vazio.");
            return new AnaliseScriptResultado
            {
                NomeArquivo = nomeArquivo,
                HashSha256 = hash,
                Lotes = lotes,
                Valido = false,
                ErrosBloqueantes = erros,
                Avisos = avisos
            };
        }

        var parser = new TSql160Parser(initialQuotedIdentifiers: true);
        using var reader = new StringReader(conteudoSql);
        var fragment = parser.Parse(reader, out var parseErrors);

        if (parseErrors is { Count: > 0 })
        {
            foreach (var err in parseErrors)
            {
                erros.Add($"Erro de sintaxe T-SQL em '{nomeArquivo}' (Linha {err.Line}, Coluna {err.Column}): {err.Message}");
            }
        }

        var visitor = new SegurancaScriptVisitor();
        fragment?.Accept(visitor);

        if (visitor.UsosDeBanco.Count > 0)
        {
            erros.Add(
                $"Comando proibido 'USE' detectado em '{nomeArquivo}' ({string.Join(", ", visitor.UsosDeBanco)}). " +
                "A seleção de banco é exclusiva do orquestrador para impedir execução no cliente errado.");
        }

        if (visitor.RollbackForaDeCatchCount > 0)
        {
            erros.Add(
                $"Comando 'ROLLBACK TRANSACTION' fora de bloco CATCH detectado em '{nomeArquivo}'. " +
                "Isso desfaria indevidamente a transação externa do orquestrador.");
        }

        if (visitor.BeginTranCount != visitor.CommitTranCount)
        {
            erros.Add(
                $"Transação interna desbalanceada em '{nomeArquivo}': {visitor.BeginTranCount} BEGIN TRAN para {visitor.CommitTranCount} COMMIT.");
        }
        else if (visitor.BeginTranCount > 0)
        {
            avisos.Add(
                $"Detectados {visitor.BeginTranCount} par(es) balanceado(s) de BEGIN/COMMIT TRANSACTION internos (compatível com @@TRANCOUNT).");
        }

        if (visitor.OperacoesNaoTransacionais.Count > 0)
        {
            avisos.Add(
                $"Operações não reversíveis por transação detectadas em '{nomeArquivo}': {string.Join(", ", visitor.OperacoesNaoTransacionais.Distinct())}.");
        }

        if (fragment is TSqlScript sqlScript)
        {
            var idx = 0;
            foreach (var batch in sqlScript.Batches)
            {
                if (batch.FragmentLength <= 0 || batch.StartOffset < 0 || batch.StartOffset + batch.FragmentLength > conteudoSql.Length)
                    continue;

                var batchText = conteudoSql.Substring(batch.StartOffset, batch.FragmentLength).Trim();
                if (!string.IsNullOrWhiteSpace(batchText))
                {
                    idx++;
                    lotes.Add(new LoteSqlExtraido(idx, batch.StartLine, batchText));
                }
            }
        }

        if (lotes.Count == 0 && erros.Count == 0)
        {
            erros.Add($"O arquivo '{nomeArquivo}' não contém instruções SQL executáveis.");
        }

        return new AnaliseScriptResultado
        {
            NomeArquivo = nomeArquivo,
            HashSha256 = hash,
            Lotes = lotes,
            Valido = erros.Count == 0,
            ContemComandoUse = visitor.UsosDeBanco.Count > 0,
            ContemTransacaoInterna = visitor.BeginTranCount > 0 || visitor.CommitTranCount > 0,
            ContemRollbackExplicito = visitor.RollbackCount > 0,
            ContemOperacaoNaoTransacional = visitor.OperacoesNaoTransacionais.Count > 0,
            QuantidadeBeginTran = visitor.BeginTranCount,
            QuantidadeCommitTran = visitor.CommitTranCount,
            QuantidadeRollbackTran = visitor.RollbackCount,
            ErrosBloqueantes = erros,
            Avisos = avisos
        };
    }

    private sealed class SegurancaScriptVisitor : TSqlFragmentVisitor
    {
        private int _catchDepth;
        public List<string> UsosDeBanco { get; } = [];
        public List<string> OperacoesNaoTransacionais { get; } = [];
        public int BeginTranCount { get; private set; }
        public int CommitTranCount { get; private set; }
        public int RollbackCount { get; private set; }
        public int RollbackForaDeCatchCount { get; private set; }

        public override void ExplicitVisit(TryCatchStatement node)
        {
            node.TryStatements?.Accept(this);
            _catchDepth++;
            node.CatchStatements?.Accept(this);
            _catchDepth--;
        }

        public override void Visit(UseStatement node)
        {
            UsosDeBanco.Add($"USE {node.DatabaseName?.Value} (linha {node.StartLine})");
            base.Visit(node);
        }

        public override void Visit(BeginTransactionStatement node)
        {
            BeginTranCount++;
            base.Visit(node);
        }

        public override void Visit(CommitTransactionStatement node)
        {
            CommitTranCount++;
            base.Visit(node);
        }

        public override void Visit(RollbackTransactionStatement node)
        {
            RollbackCount++;
            if (_catchDepth == 0)
            {
                RollbackForaDeCatchCount++;
            }
            base.Visit(node);
        }

        public override void Visit(AlterDatabaseStatement node)
        {
            OperacoesNaoTransacionais.Add($"ALTER DATABASE (linha {node.StartLine})");
            base.Visit(node);
        }

        public override void Visit(CreateDatabaseStatement node)
        {
            OperacoesNaoTransacionais.Add($"CREATE DATABASE (linha {node.StartLine})");
            base.Visit(node);
        }

        public override void Visit(DropDatabaseStatement node)
        {
            OperacoesNaoTransacionais.Add($"DROP DATABASE (linha {node.StartLine})");
            base.Visit(node);
        }

        public override void Visit(CreateFullTextCatalogStatement node)
        {
            OperacoesNaoTransacionais.Add($"CREATE FULLTEXT CATALOG (linha {node.StartLine})");
            base.Visit(node);
        }

        public override void Visit(AlterFullTextCatalogStatement node)
        {
            OperacoesNaoTransacionais.Add($"ALTER FULLTEXT CATALOG (linha {node.StartLine})");
            base.Visit(node);
        }

        public override void Visit(CreateFullTextIndexStatement node)
        {
            OperacoesNaoTransacionais.Add($"CREATE FULLTEXT INDEX (linha {node.StartLine})");
            base.Visit(node);
        }

        public override void Visit(BackupStatement node)
        {
            OperacoesNaoTransacionais.Add($"BACKUP (linha {node.StartLine})");
            base.Visit(node);
        }

        public override void Visit(RestoreStatement node)
        {
            OperacoesNaoTransacionais.Add($"RESTORE (linha {node.StartLine})");
            base.Visit(node);
        }

        public override void Visit(OnlineIndexOption node)
        {
            if (node.OptionState == OptionState.On)
            {
                OperacoesNaoTransacionais.Add($"INDEX ONLINE = ON (linha {node.StartLine})");
            }
            base.Visit(node);
        }
    }
}
