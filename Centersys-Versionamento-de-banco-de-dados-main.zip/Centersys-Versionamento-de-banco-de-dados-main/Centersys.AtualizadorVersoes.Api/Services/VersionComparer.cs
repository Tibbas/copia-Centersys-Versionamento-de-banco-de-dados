using System.Text.RegularExpressions;

namespace Centersys.AtualizadorVersoes.Api.Services;

public static partial class VersionComparer
{
    [GeneratedRegex(@"^(?:vers[aã]o[\s_]+)?[vV]?(\d+(?:\.\d+)+)$", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)]
    private static partial Regex VersionFolderRegex();

    [GeneratedRegex(@"^[vV]?(\d+(?:\.\d+)*)$", RegexOptions.CultureInvariant)]
    private static partial Regex CleanVersionRegex();

    public static bool TryExtractVersion(string rawNameOrVersion, out string canonicalVersion)
    {
        canonicalVersion = string.Empty;
        if (string.IsNullOrWhiteSpace(rawNameOrVersion))
            return false;

        var trimmed = rawNameOrVersion.Trim();
        var match = VersionFolderRegex().Match(trimmed);
        if (!match.Success)
        {
            match = CleanVersionRegex().Match(trimmed);
            if (!match.Success || !trimmed.Any(char.IsDigit))
                return false;
        }

        var numericPart = match.Groups[1].Value;
        var segments = numericPart.Split('.', StringSplitOptions.RemoveEmptyEntries);
        if (segments.Length < 2 || segments.Any(s => !int.TryParse(s, out _)))
            return false;

        canonicalVersion = $"V{string.Join('.', segments.Select(s => int.Parse(s).ToString()))}";
        return true;
    }

    public static int[] ParseSegments(string version)
    {
        if (string.IsNullOrWhiteSpace(version))
            return [0];

        var cleaned = version.Trim();
        if (TryExtractVersion(cleaned, out var canonical))
        {
            cleaned = canonical[1..];
        }
        else
        {
            cleaned = Regex.Replace(cleaned, @"^[vV]", "").Trim();
        }

        var parts = cleaned.Split('.', StringSplitOptions.RemoveEmptyEntries);
        var result = new int[parts.Length];
        for (var i = 0; i < parts.Length; i++)
        {
            result[i] = int.TryParse(parts[i], out var num) ? num : 0;
        }

        return result.Length == 0 ? [0] : result;
    }

    public static int Compare(string? versionA, string? versionB)
    {
        if (string.IsNullOrWhiteSpace(versionA) && string.IsNullOrWhiteSpace(versionB))
            return 0;
        if (string.IsNullOrWhiteSpace(versionA))
            return -1;
        if (string.IsNullOrWhiteSpace(versionB))
            return 1;

        var segA = ParseSegments(versionA);
        var segB = ParseSegments(versionB);
        var maxLen = Math.Max(segA.Length, segB.Length);

        for (var i = 0; i < maxLen; i++)
        {
            var valA = i < segA.Length ? segA[i] : 0;
            var valB = i < segB.Length ? segB[i] : 0;
            var cmp = valA.CompareTo(valB);
            if (cmp != 0)
                return cmp;
        }

        return 0;
    }

    public static string NormalizeForStorage(string version, int minSegments = 4)
    {
        var segments = ParseSegments(version);
        var total = Math.Max(segments.Length, minSegments);
        var padded = new string[total];
        for (var i = 0; i < total; i++)
        {
            var val = i < segments.Length ? segments[i] : 0;
            padded[i] = val.ToString("D6");
        }

        return string.Join('.', padded);
    }

    public static string FormatCanonical(string version)
    {
        return TryExtractVersion(version, out var canonical) ? canonical : version.Trim();
    }

    public static bool IsScriptVersaoFinal(string fileName)
    {
        var nameOnly = Path.GetFileName(fileName);
        return string.Equals(nameOnly, "scriptVersao.sql", StringComparison.OrdinalIgnoreCase)
            || string.Equals(nameOnly, "script_versao.sql", StringComparison.OrdinalIgnoreCase);
    }

    public static List<T> OrderPackageScripts<T>(IEnumerable<T> items, Func<T, string> fileNameSelector)
    {
        return items
            .OrderBy(item => IsScriptVersaoFinal(fileNameSelector(item)) ? 1 : 0)
            .ThenBy(item => Path.GetFileName(fileNameSelector(item)), NaturalFileNameComparer.Instance)
            .ToList();
    }

    private sealed class NaturalFileNameComparer : IComparer<string>
    {
        public static readonly NaturalFileNameComparer Instance = new();

        public int Compare(string? x, string? y)
        {
            if (ReferenceEquals(x, y)) return 0;
            if (x is null) return -1;
            if (y is null) return 1;

            var partsX = Regex.Split(x, @"(\d+)");
            var partsY = Regex.Split(y, @"(\d+)");
            var len = Math.Min(partsX.Length, partsY.Length);

            for (var i = 0; i < len; i++)
            {
                if (int.TryParse(partsX[i], out var numX) && int.TryParse(partsY[i], out var numY))
                {
                    var cmpNum = numX.CompareTo(numY);
                    if (cmpNum != 0) return cmpNum;
                }
                else
                {
                    var cmpStr = string.Compare(partsX[i], partsY[i], StringComparison.OrdinalIgnoreCase);
                    if (cmpStr != 0) return cmpStr;
                }
            }

            return partsX.Length.CompareTo(partsY.Length);
        }
    }
}
