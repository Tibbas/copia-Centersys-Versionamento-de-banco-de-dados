using System.Security.Cryptography;
using System.Text.RegularExpressions;
using Centersys.AtualizadorVersoes.Api.Configuration.Data;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace Centersys.AtualizadorVersoes.Api.Services;

public static class PasswordHasher
{
    private const int SaltSize = 16;
    private const int KeySize = 32;
    private const int Iterations = 100_000;

    public static string HashPassword(string password)
    {
        var salt = RandomNumberGenerator.GetBytes(SaltSize);
        var hash = Rfc2898DeriveBytes.Pbkdf2(password, salt, Iterations, HashAlgorithmName.SHA256, KeySize);
        return $"PBKDF2${Iterations}${Convert.ToBase64String(salt)}${Convert.ToBase64String(hash)}";
    }

    public static bool VerifyPassword(string password, string storedHash)
    {
        if (string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(storedHash))
            return false;

        var parts = storedHash.Split('$');
        if (parts.Length != 4 || parts[0] != "PBKDF2" || !int.TryParse(parts[1], out var iterations))
            return false;

        try
        {
            var salt = Convert.FromBase64String(parts[2]);
            var expectedHash = Convert.FromBase64String(parts[3]);
            var actualHash = Rfc2898DeriveBytes.Pbkdf2(password, salt, iterations, HashAlgorithmName.SHA256, expectedHash.Length);
            return CryptographicOperations.FixedTimeEquals(actualHash, expectedHash);
        }
        catch
        {
            return false;
        }
    }
}

public interface ICredentialProvider
{
    string CriptografarSenha(string senhaTextoClaro);
    Task<string> ObterConnectionStringInstanciaAsync(string? servidor, CancellationToken cancellationToken = default);
    Task<string> ObterConnectionStringClienteAsync(string? servidor, string nomeBanco, bool bloquearInativosComUnderline = true, CancellationToken cancellationToken = default);
    void ValidarNomeBancoCliente(string nomeBanco, bool bloquearInativosComUnderline = true);
}

public partial class DataProtectionCredentialProvider(
    ApplicationDbContext dbContext,
    IConfiguration configuration,
    IDataProtectionProvider dataProtectionProvider) : ICredentialProvider
{
    private readonly IDataProtector _protector = dataProtectionProvider.CreateProtector("Centersys.AtualizadorVersoes.Credenciais.v1");

    private static readonly HashSet<string> BancosSistemaProibidos = new(StringComparer.OrdinalIgnoreCase)
    {
        "master",
        "tempdb",
        "model",
        "msdb",
        "CentersysControle"
    };

    [GeneratedRegex(@"^[A-Za-z0-9_]{1,128}$", RegexOptions.CultureInvariant)]
    private static partial Regex SafeSqlIdentifierRegex();

    public string CriptografarSenha(string senhaTextoClaro)
    {
        return _protector.Protect(senhaTextoClaro);
    }

    public void ValidarNomeBancoCliente(string nomeBanco, bool bloquearInativosComUnderline = true)
    {
        if (string.IsNullOrWhiteSpace(nomeBanco) || !SafeSqlIdentifierRegex().IsMatch(nomeBanco))
        {
            throw new InvalidOperationException($"Identificador de banco de dados inválido: '{nomeBanco}'. Use apenas letras, números e '_'.");
        }

        if (BancosSistemaProibidos.Contains(nomeBanco))
        {
            throw new InvalidOperationException($"Operação bloqueada: '{nomeBanco}' é um banco reservado de sistema/controle.");
        }

        if (bloquearInativosComUnderline && nomeBanco.StartsWith('_'))
        {
            throw new InvalidOperationException($"Operação bloqueada: o banco '{nomeBanco}' inicia com '_' (convenção de cliente desativado da CenterSys).");
        }
    }

    public async Task<string> ObterConnectionStringInstanciaAsync(string? servidor, CancellationToken cancellationToken = default)
    {
        var baseConnString = configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("ConnectionString 'DefaultConnection' não configurada.");

        var builder = new SqlConnectionStringBuilder(baseConnString)
        {
            InitialCatalog = "master",
            ConnectTimeout = 15
        };

        if (!string.IsNullOrWhiteSpace(servidor))
        {
            var credencial = await dbContext.CredenciaisServidores
                .AsNoTracking()
                .FirstOrDefaultAsync(c => c.Servidor == servidor && c.Ativo, cancellationToken);

            if (credencial is not null)
            {
                builder.DataSource = credencial.Porta.HasValue
                    ? $"{credencial.HostInstancia},{credencial.Porta.Value}"
                    : credencial.HostInstancia;
                builder.TrustServerCertificate = credencial.TrustServerCertificate;

                if (credencial.UsarAutenticacaoWindows)
                {
                    builder.IntegratedSecurity = true;
                    builder.Remove("User ID");
                    builder.Remove("Password");
                }
                else if (!string.IsNullOrWhiteSpace(credencial.UsuarioSql) && !string.IsNullOrWhiteSpace(credencial.SenhaCriptografada))
                {
                    builder.IntegratedSecurity = false;
                    builder.UserID = credencial.UsuarioSql;
                    builder.Password = _protector.Unprotect(credencial.SenhaCriptografada);
                }
            }
        }

        return builder.ConnectionString;
    }

    public async Task<string> ObterConnectionStringClienteAsync(
        string? servidor,
        string nomeBanco,
        bool bloquearInativosComUnderline = true,
        CancellationToken cancellationToken = default)
    {
        ValidarNomeBancoCliente(nomeBanco, bloquearInativosComUnderline);
        var instanceConn = await ObterConnectionStringInstanciaAsync(servidor, cancellationToken);
        var builder = new SqlConnectionStringBuilder(instanceConn)
        {
            InitialCatalog = nomeBanco
        };

        return builder.ConnectionString;
    }
}
