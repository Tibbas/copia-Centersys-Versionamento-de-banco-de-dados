using System.Collections.Concurrent;

namespace Centersys.AtualizadorVersoes.Api.Services;

public interface ILoteCancellationManager
{
    CancellationToken RegistrarLote(int loteId);
    bool SolicitarCancelamento(int loteId);
    void RemoverLote(int loteId);
}

public sealed class LoteCancellationManager : ILoteCancellationManager
{
    private readonly ConcurrentDictionary<int, CancellationTokenSource> _tokens = new();

    public CancellationToken RegistrarLote(int loteId)
    {
        var cts = new CancellationTokenSource();
        _tokens[loteId] = cts;
        return cts.Token;
    }

    public bool SolicitarCancelamento(int loteId)
    {
        if (_tokens.TryGetValue(loteId, out var cts))
        {
            try
            {
                cts.Cancel();
                return true;
            }
            catch (ObjectDisposedException)
            {
                return false;
            }
        }

        return false;
    }

    public void RemoverLote(int loteId)
    {
        if (_tokens.TryRemove(loteId, out var cts))
        {
            cts.Dispose();
        }
    }
}
