using Centersys.AtualizadorVersoes.Api.DTOs;

namespace Centersys.AtualizadorVersoes.Api.Services;

public interface IVersaoService
{
    Task<IEnumerable<BancoDeDadosClienteResponse>> GetBancoDeDadosClientesAsync(bool sincronizarInstancia = true, CancellationToken cancellationToken = default);
    Task<BancoDeDadosClienteResponse> CadastrarClienteAsync(CriarClienteBancoRequest request, CancellationToken cancellationToken = default);
    Task<BancoDeDadosClienteResponse> EditarClienteAsync(int id, EditarClienteBancoRequest request, CancellationToken cancellationToken = default);
    Task<TesteConexaoResponse> TestarConexaoClienteAsync(int id, CancellationToken cancellationToken = default);

    Task<IEnumerable<VersoesDisponiveisResponse>> GetVersoesDisponiveisAsync(CancellationToken cancellationToken = default);
    Task<VersoesDisponiveisResponse> CadastrarPacoteVersaoAsync(CadastrarPacoteVersaoRequest request, CancellationToken cancellationToken = default);

    Task<IEnumerable<BancosAtualizadosResponse>> AtualizarBancoDeDadosAsync(AtualizarVersoesRequest request, string disparadoPor = "Operador", string origem = "Manual", CancellationToken cancellationToken = default);
    Task<StatusLoteExecucaoResponse> IniciarLoteAssincronoAsync(AtualizarVersoesRequest request, string disparadoPor = "Operador", string origem = "Manual", CancellationToken cancellationToken = default);
    Task<StatusLoteExecucaoResponse?> ObterStatusLoteAsync(int loteId, CancellationToken cancellationToken = default);
    Task<bool> CancelarLoteAsync(int loteId, CancellationToken cancellationToken = default);

    Task<IEnumerable<HistoricoExecucaoResumoDto>> ObterHistoricoExecucoesAsync(int limite = 25, CancellationToken cancellationToken = default);
    Task<IEnumerable<LogExecucaoDto>> ObterLogsRecentesAsync(int? loteId = null, int? clienteBancoId = null, int limite = 200, CancellationToken cancellationToken = default);
}
