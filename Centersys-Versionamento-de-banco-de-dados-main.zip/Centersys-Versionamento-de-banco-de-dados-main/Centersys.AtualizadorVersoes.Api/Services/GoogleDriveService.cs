using System.Text;
using Centersys.AtualizadorVersoes.Api.Configuration;
using Centersys.AtualizadorVersoes.Api.Configuration.Data;
using Centersys.AtualizadorVersoes.Api.Models;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Drive.v3;
using Google.Apis.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace Centersys.AtualizadorVersoes.Api.Services;

public class GoogleDriveService(
    ApplicationDbContext dbContext,
    ISqlScriptAnalyzer scriptAnalyzer,
    IWebHostEnvironment env,
    IOptions<OrquestradorSettings> orqOptions,
    IOptions<GoogleDriveSettings> driveOptions,
    ILogger<GoogleDriveService> logger) : IGoogleDriveService
{
    private readonly OrquestradorSettings _orqSettings = orqOptions.Value;
    private readonly GoogleDriveSettings _driveSettings = driveOptions.Value;

    public async Task<Stream> BaixarArquivoAsync(string idArquivo, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(idArquivo))
            throw new ArgumentException("O identificador do arquivo não pode ser vazio.", nameof(idArquivo));

        if (File.Exists(idArquivo))
        {
            var bytes = await File.ReadAllBytesAsync(idArquivo, cancellationToken);
            return new MemoryStream(bytes);
        }

        if (!_driveSettings.Habilitado || string.IsNullOrWhiteSpace(_driveSettings.CredenciaisJsonPath))
        {
            throw new InvalidOperationException(
                "A integração com Google Drive está desabilitada ou sem CredenciaisJsonPath configurado.");
        }

        using var drive = CriarClienteDrive();
        var request = drive.Files.Get(idArquivo);
        var stream = new MemoryStream();
        await request.DownloadAsync(stream, cancellationToken);
        stream.Position = 0;
        return stream;
    }

    public async Task<int> SincronizarPacotesAsync(CancellationToken cancellationToken = default)
    {
        var pacotesSincronizados = 0;
        pacotesSincronizados += await SincronizarPastaLocalAsync(cancellationToken);

        if (_driveSettings.Habilitado &&
            !string.IsNullOrWhiteSpace(_driveSettings.PastaRaizId) &&
            !string.IsNullOrWhiteSpace(_driveSettings.CredenciaisJsonPath) &&
            File.Exists(_driveSettings.CredenciaisJsonPath))
        {
            try
            {
                pacotesSincronizados += await SincronizarGoogleDriveRemotoAsync(cancellationToken);
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "Falha ao sincronizar pacotes a partir do Google Drive. Mantendo pacotes locais.");
            }
        }

        return pacotesSincronizados;
    }

    private async Task<int> SincronizarPastaLocalAsync(CancellationToken cancellationToken)
    {
        var baseDir = Path.IsPathRooted(_orqSettings.PastaScriptsLocais)
            ? _orqSettings.PastaScriptsLocais
            : Path.Combine(env.ContentRootPath, _orqSettings.PastaScriptsLocais);

        if (!Directory.Exists(baseDir))
        {
            var fallbackBinDir = Path.Combine(AppContext.BaseDirectory, _orqSettings.PastaScriptsLocais);
            if (Directory.Exists(fallbackBinDir))
                baseDir = fallbackBinDir;
            else
                return 0;
        }

        var sincronizados = 0;
        var subpastas = Directory.GetDirectories(baseDir);

        foreach (var pasta in subpastas)
        {
            var nomePasta = Path.GetFileName(pasta);
            if (!VersionComparer.TryExtractVersion(nomePasta, out var versaoCanonica))
                continue;

            var arquivosSql = Directory.GetFiles(pasta, "*.sql", SearchOption.TopDirectoryOnly);
            if (arquivosSql.Length == 0)
                continue;

            var arquivosOrdenados = VersionComparer.OrderPackageScripts(arquivosSql, Path.GetFileName);
            var listaScripts = new List<(string Nome, string Conteudo)>();

            foreach (var caminho in arquivosOrdenados)
            {
                var conteudo = await File.ReadAllTextAsync(caminho, Encoding.UTF8, cancellationToken);
                listaScripts.Add((Path.GetFileName(caminho), conteudo));
            }

            await UpsertPacoteVersaoAsync(
                versaoCanonica,
                $"Pacote oficial CenterSys ({nomePasta})",
                "Local",
                pasta,
                listaScripts,
                cancellationToken);

            sincronizados++;
        }

        return sincronizados;
    }

    private async Task<int> SincronizarGoogleDriveRemotoAsync(CancellationToken cancellationToken)
    {
        using var drive = CriarClienteDrive();
        var listFolders = drive.Files.List();
        listFolders.Q = $"'{_driveSettings.PastaRaizId}' in parents and mimeType = 'application/vnd.google-apps.folder' and trashed = false";
        listFolders.Fields = "files(id, name)";
        var foldersResult = await listFolders.ExecuteAsync(cancellationToken);

        if (foldersResult.Files is null || foldersResult.Files.Count == 0)
            return 0;

        var sincronizados = 0;
        foreach (var folder in foldersResult.Files)
        {
            if (!VersionComparer.TryExtractVersion(folder.Name, out var versaoCanonica))
                continue;

            var listFiles = drive.Files.List();
            listFiles.Q = $"'{folder.Id}' in parents and trashed = false";
            listFiles.Fields = "files(id, name)";
            var filesResult = await listFiles.ExecuteAsync(cancellationToken);
            if (filesResult.Files is null)
                continue;

            var sqlFiles = filesResult.Files
                .Where(f => f.Name.EndsWith(".sql", StringComparison.OrdinalIgnoreCase))
                .ToList();

            if (sqlFiles.Count == 0)
                continue;

            var ordenados = VersionComparer.OrderPackageScripts(sqlFiles, f => f.Name);
            var scriptsBaixados = new List<(string Nome, string Conteudo)>();

            foreach (var file in ordenados)
            {
                using var stream = await BaixarArquivoAsync(file.Id, cancellationToken);
                using var reader = new StreamReader(stream, Encoding.UTF8);
                var sql = await reader.ReadToEndAsync(cancellationToken);
                scriptsBaixados.Add((file.Name, sql));
            }

            await UpsertPacoteVersaoAsync(
                versaoCanonica,
                $"Pacote sincronizado do Google Drive ({folder.Name})",
                "GoogleDrive",
                folder.Id,
                scriptsBaixados,
                cancellationToken);

            sincronizados++;
        }

        return sincronizados;
    }

    private async Task UpsertPacoteVersaoAsync(
        string versaoCanonica,
        string descricao,
        string origem,
        string caminhoOuId,
        List<(string Nome, string Conteudo)> scripts,
        CancellationToken cancellationToken)
    {
        var versaoNorm = VersionComparer.NormalizeForStorage(versaoCanonica);
        var ehPadrao = VersionComparer.Compare(versaoCanonica, _orqSettings.VersaoAlvoPadrao) == 0;

        var pacote = await dbContext.PacotesVersao
            .Include(p => p.Arquivos)
            .FirstOrDefaultAsync(p => p.VersaoNormalizada == versaoNorm, cancellationToken);

        if (pacote is null)
        {
            pacote = new PacoteVersao
            {
                NumeroVersao = versaoCanonica,
                VersaoNormalizada = versaoNorm,
                Descricao = descricao,
                Origem = origem,
                CaminhoOuDriveId = caminhoOuId,
                EhVersaoAlvoPadrao = ehPadrao,
                Ativo = true
            };
            dbContext.PacotesVersao.Add(pacote);
        }
        else
        {
            pacote.CaminhoOuDriveId = caminhoOuId;
            if (ehPadrao)
                pacote.EhVersaoAlvoPadrao = true;
        }

        var ordem = 1;
        foreach (var (nome, conteudo) in scripts)
        {
            var analise = scriptAnalyzer.Analisar(conteudo, nome);
            var avisosTexto = analise.ErrosBloqueantes.Concat(analise.Avisos).ToList();
            var avisoConsolidado = avisosTexto.Count > 0 ? string.Join(" | ", avisosTexto) : null;

            var existente = pacote.Arquivos.FirstOrDefault(a =>
                string.Equals(a.NomeArquivo, nome, StringComparison.OrdinalIgnoreCase));

            if (existente is null)
            {
                pacote.Arquivos.Add(new ArquivoScript
                {
                    NomeArquivo = nome,
                    OrdemExecucao = ordem,
                    ConteudoSql = conteudo,
                    HashSha256 = analise.HashSha256,
                    QuantidadeLotesGo = Math.Max(1, analise.Lotes.Count),
                    ContemTransacaoInterna = analise.ContemTransacaoInterna,
                    ContemOperacaoNaoTransacional = analise.ContemOperacaoNaoTransacional,
                    AvisosValidacao = avisoConsolidado
                });
            }
            else
            {
                existente.OrdemExecucao = ordem;
                existente.ConteudoSql = conteudo;
                existente.HashSha256 = analise.HashSha256;
                existente.QuantidadeLotesGo = Math.Max(1, analise.Lotes.Count);
                existente.ContemTransacaoInterna = analise.ContemTransacaoInterna;
                existente.ContemOperacaoNaoTransacional = analise.ContemOperacaoNaoTransacional;
                existente.AvisosValidacao = avisoConsolidado;
            }

            ordem++;
        }

        await dbContext.SaveChangesAsync(cancellationToken);
    }

    private DriveService CriarClienteDrive()
    {
        GoogleCredential credential;
        using (var stream = new FileStream(_driveSettings.CredenciaisJsonPath!, FileMode.Open, FileAccess.Read))
        {
#pragma warning disable CS0618
            credential = GoogleCredential.FromStream(stream).CreateScoped(DriveService.ScopeConstants.DriveReadonly);
#pragma warning restore CS0618
        }

        return new DriveService(new BaseClientService.Initializer
        {
            HttpClientInitializer = credential,
            ApplicationName = _driveSettings.ApplicationName
        });
    }
}
