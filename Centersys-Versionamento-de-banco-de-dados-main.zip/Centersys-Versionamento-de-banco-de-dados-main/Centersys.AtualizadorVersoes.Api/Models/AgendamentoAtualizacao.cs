namespace Centersys.AtualizadorVersoes.Api.Models;

public class AgendamentoAtualizacao
{
    public int Id { get; set; }
    public required string Descricao { get; set; }
    public required string VersaoAlvo { get; set; }
    public string? DatacenterEscopo { get; set; }
    public string? IdsClientesCsv { get; set; }
    public DateTime DataHoraProgramada { get; set; }
    public string Status { get; set; } = "Pendente";
    public int? ExecucaoLoteId { get; set; }
    public string CriadoPor { get; set; } = "Operador";
    public string? MensagemResultado { get; set; }
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
    public DateTime? ExecutadoEm { get; set; }
}
