namespace Centersys.AtualizadorVersoes.Api.Models;

public class ExecucaoLote
{
    public int Id { get; set; }
    public string DisparadoPor { get; set; } = "Operador";
    public string Origem { get; set; } = "Manual";
    public int TotalBancos { get; set; }
    public int TotalSucesso { get; set; }
    public int TotalFalha { get; set; }
    public int TotalCancelado { get; set; }
    public string StatusLote { get; set; } = "EmExecucao";
    public bool CancelamentoSolicitado { get; set; } = false;
    public DateTime DataInicio { get; set; } = DateTime.UtcNow;
    public DateTime? DataFim { get; set; }

    public ICollection<ExecucaoBanco> Bancos { get; set; } = [];
    public ICollection<LogEventoLote> Logs { get; set; } = [];
}

public class ExecucaoBanco
{
    public int Id { get; set; }
    public int ExecucaoLoteId { get; set; }
    public ExecucaoLote ExecucaoLote { get; set; } = null!;
    public int ClienteBancoId { get; set; }
    public ClienteBanco ClienteBanco { get; set; } = null!;
    public required string NomeEmpresa { get; set; }
    public required string NomeBanco { get; set; }
    public required string Servidor { get; set; }
    public required string Datacenter { get; set; }
    public required string VersaoOrigem { get; set; }
    public required string VersaoAlvo { get; set; }
    public required string VersaoAlcancada { get; set; }
    public bool EhScriptCustomizado { get; set; }
    public string? NomeScriptCustomizado { get; set; }
    public string? ConteudoScriptCustomizado { get; set; }
    public string Status { get; set; } = "Pendente";
    public int ProgressoPercentual { get; set; } = 0;
    public string EtapaAtual { get; set; } = "Na fila";
    public bool Sucesso { get; set; }
    public string? MensagemResumo { get; set; }
    public DateTime DataInicio { get; set; } = DateTime.UtcNow;
    public DateTime? DataFim { get; set; }

    public ICollection<ExecucaoScript> ScriptsExecutados { get; set; } = [];
}

public class ExecucaoScript
{
    public int Id { get; set; }
    public int ExecucaoBancoId { get; set; }
    public ExecucaoBanco ExecucaoBanco { get; set; } = null!;
    public int ClienteBancoId { get; set; }
    public ClienteBanco ClienteBanco { get; set; } = null!;
    public required string VersaoPacote { get; set; }
    public required string NomeArquivo { get; set; }
    public required string HashSha256 { get; set; }
    public int OrdemExecucao { get; set; }
    public bool Sucesso { get; set; }
    public bool IgnoradoIdempotencia { get; set; }
    public bool ModoNaoTransacional { get; set; }
    public int DuracaoMs { get; set; }
    public int? NumeroErroSql { get; set; }
    public int? LinhaErroSql { get; set; }
    public string NivelLog { get; set; } = "INFO";
    public required string MensagemLog { get; set; }
    public DateTime DataExecucao { get; set; } = DateTime.UtcNow;
}

public class LogEventoLote
{
    public int Id { get; set; }
    public int? ExecucaoLoteId { get; set; }
    public ExecucaoLote? ExecucaoLote { get; set; }
    public int? ClienteBancoId { get; set; }
    public string? NomeBanco { get; set; }
    public string Nivel { get; set; } = "INFO";
    public required string Mensagem { get; set; }
    public DateTime DataHora { get; set; } = DateTime.UtcNow;
}
