namespace Centersys.AtualizadorVersoes.Api.Models;

public class UsuarioSistema
{
    public int Id { get; set; }
    public required string Nome { get; set; }
    public required string Email { get; set; }
    public required string SenhaHash { get; set; }
    public string Perfil { get; set; } = "Admin";
    public bool Ativo { get; set; } = true;
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
}
