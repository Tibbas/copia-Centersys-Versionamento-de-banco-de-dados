namespace Centersys.AtualizadorVersoes.Api.Models;

public class ClienteBanco
{
    public int Id { get; set; }
    public required string NomeEmpresa { get; set; }
    public required string NomeBanco { get; set; }
    public string Servidor { get; set; } = "SRV-SQL-01";
    public string Datacenter { get; set; } = "Datacenter 111";
    public string VersaoAtualConhecida { get; set; } = "4.42.0.1";
    public string Status { get; set; } = "DESATUALIZADA";
    public bool Aprovado { get; set; } = true;
    public bool DescobertoAutomaticamente { get; set; } = false;
    public bool AtivoNaInstancia { get; set; } = true;
    public bool EmExecucaoLock { get; set; } = false;
    public string? LockToken { get; set; }
    public DateTime? LockExpiracao { get; set; }
    public DateTime? UltimaVerificacao { get; set; }
    public DateTime? UltimaAtualizacao { get; set; }
    public string? UltimoErroResumo { get; set; }
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;

    public ICollection<ExecucaoBanco> Execucoes { get; set; } = [];
    public ICollection<ExecucaoScript> ExecucoesScripts { get; set; } = [];
}
