namespace Centersys.AtualizadorVersoes.Api.Models;

public class PacoteVersao
{
    public int Id { get; set; }
    public required string NumeroVersao { get; set; }
    public required string VersaoNormalizada { get; set; }
    public string? Descricao { get; set; }
    public string Origem { get; set; } = "Local";
    public string? CaminhoOuDriveId { get; set; }
    public bool EhVersaoAlvoPadrao { get; set; } = false;
    public bool Ativo { get; set; } = true;
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;

    public ICollection<ArquivoScript> Arquivos { get; set; } = [];
}

public class ArquivoScript
{
    public int Id { get; set; }
    public int PacoteVersaoId { get; set; }
    public PacoteVersao PacoteVersao { get; set; } = null!;
    public required string NomeArquivo { get; set; }
    public int OrdemExecucao { get; set; }
    public required string ConteudoSql { get; set; }
    public required string HashSha256 { get; set; }
    public int QuantidadeLotesGo { get; set; } = 1;
    public bool ContemTransacaoInterna { get; set; } = false;
    public bool ContemOperacaoNaoTransacional { get; set; } = false;
    public string? AvisosValidacao { get; set; }
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
}
