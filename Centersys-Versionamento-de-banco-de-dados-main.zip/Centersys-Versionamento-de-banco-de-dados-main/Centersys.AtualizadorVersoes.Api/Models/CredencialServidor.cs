namespace Centersys.AtualizadorVersoes.Api.Models;

public class CredencialServidor
{
    public int Id { get; set; }
    public required string Servidor { get; set; }
    public required string Datacenter { get; set; }
    public required string HostInstancia { get; set; }
    public int? Porta { get; set; }
    public bool UsarAutenticacaoWindows { get; set; } = true;
    public string? UsuarioSql { get; set; }
    public string? SenhaCriptografada { get; set; }
    public bool TrustServerCertificate { get; set; } = true;
    public bool Ativo { get; set; } = true;
    public bool? UltimaConexaoOk { get; set; }
    public DateTime? UltimaVerificacaoConexao { get; set; }
    public string? MensagemStatusConexao { get; set; }
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
}
