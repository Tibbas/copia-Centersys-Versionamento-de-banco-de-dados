-- Pacote Versão 4.48.0.0 - Fechamento de versão oficial na tabela fonte da verdade
UPDATE dbo.Log_Acesso
SET cNumVersao = 'V4.48.0.0',
    dDataAtualizacao = SYSDATETIME();
GO
