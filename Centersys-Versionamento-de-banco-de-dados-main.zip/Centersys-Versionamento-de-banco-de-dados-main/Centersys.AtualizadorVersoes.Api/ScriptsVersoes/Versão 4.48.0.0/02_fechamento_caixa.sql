-- Pacote Versão 4.48.0.0 - Script 02: Procedure de Diagnóstico e Fechamento
-- CREATE OR ALTER PROCEDURE exige isolamento de lote via GO no SQL Server

CREATE OR ALTER PROCEDURE dbo.sp_ResumoVersaoBanco
AS
BEGIN
    SET NOCOUNT ON;
    SELECT TOP 1
        DB_NAME() AS NomeBanco,
        cNumVersao AS VersaoInstalada,
        dDataAtualizacao AS UltimaAtualizacao
    FROM dbo.Log_Acesso;
END
GO
