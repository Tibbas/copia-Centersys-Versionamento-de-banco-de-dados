-- Pacote Versão 4.48.0.0 - Script 01: Otimização de Estoque
IF OBJECT_ID('dbo.Movimentacao_Estoque', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Movimentacao_Estoque (
        Id BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Movimentacao_Estoque PRIMARY KEY,
        CodigoProduto VARCHAR(50) NOT NULL,
        TipoMovimento CHAR(1) NOT NULL CONSTRAINT CK_Movimentacao_Tipo CHECK (TipoMovimento IN ('E', 'S')),
        Quantidade DECIMAL(18,4) NOT NULL,
        DataMovimento DATETIME2 NOT NULL CONSTRAINT DF_Movimentacao_Data DEFAULT (SYSDATETIME())
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Movimentacao_Estoque_Produto' AND object_id = OBJECT_ID('dbo.Movimentacao_Estoque'))
BEGIN
    CREATE NONCLUSTERED INDEX IX_Movimentacao_Estoque_Produto
        ON dbo.Movimentacao_Estoque (CodigoProduto, DataMovimento DESC);
END
GO
