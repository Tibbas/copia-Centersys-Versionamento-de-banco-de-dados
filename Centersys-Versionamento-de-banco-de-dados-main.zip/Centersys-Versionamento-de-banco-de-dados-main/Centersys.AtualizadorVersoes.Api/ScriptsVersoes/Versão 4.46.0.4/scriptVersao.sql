-- Pacote Versão 4.46.0.4 - Fechamento de versão oficial na tabela fonte da verdade
UPDATE dbo.Log_Acesso
SET cNumVersao = 'V4.46.0.4',
    dDataAtualizacao = SYSDATETIME();
GO
