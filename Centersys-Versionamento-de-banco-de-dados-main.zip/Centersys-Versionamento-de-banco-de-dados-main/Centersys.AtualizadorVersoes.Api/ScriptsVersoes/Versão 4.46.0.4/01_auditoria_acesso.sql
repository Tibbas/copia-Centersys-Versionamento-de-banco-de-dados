-- Pacote Versão 4.46.0.4 - Script 01: Estrutura de Auditoria
-- Contém literais com a palavra 'GO' para validar o parser léxico (ScriptDom)

IF OBJECT_ID('dbo.Auditoria_Sistema', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Auditoria_Sistema (
        Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Auditoria_Sistema PRIMARY KEY,
        Modulo VARCHAR(80) NOT NULL,
        Descricao NVARCHAR(300) NOT NULL,
        UfReferencia CHAR(2) NOT NULL CONSTRAINT DF_Auditoria_Uf DEFAULT ('GO'),
        DataRegistro DATETIME2 NOT NULL CONSTRAINT DF_Auditoria_Data DEFAULT (SYSDATETIME())
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Auditoria_Sistema_Data' AND object_id = OBJECT_ID('dbo.Auditoria_Sistema'))
BEGIN
    CREATE NONCLUSTERED INDEX IX_Auditoria_Sistema_Data ON dbo.Auditoria_Sistema (DataRegistro DESC);
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Auditoria_Sistema WHERE Modulo = 'ORQUESTRADOR_4_46_0_4')
BEGIN
    INSERT INTO dbo.Auditoria_Sistema (Modulo, Descricao, UfReferencia)
    VALUES ('ORQUESTRADOR_4_46_0_4', N'Pacote 4.46.0.4 aplicado (teste literal GO / Goiás sem quebrar lote)', 'GO');
END
GO
