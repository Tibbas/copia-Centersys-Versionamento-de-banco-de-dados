-- Pacote Versão 4.47.0.0 - Script 01: Parâmetros Fiscais
-- Reproduz o padrão real do SSMS da CenterSys com BEGIN TRANSACTION / COMMIT balanceados internos

BEGIN TRANSACTION
GO

IF OBJECT_ID('dbo.Parametros_Fiscais', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Parametros_Fiscais (
        Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Parametros_Fiscais PRIMARY KEY,
        Chave VARCHAR(100) NOT NULL UNIQUE,
        Valor VARCHAR(250) NOT NULL,
        Ativo BIT NOT NULL CONSTRAINT DF_Parametros_Fiscais_Ativo DEFAULT (1),
        AtualizadoEm DATETIME2 NOT NULL CONSTRAINT DF_Parametros_Fiscais_Data DEFAULT (SYSDATETIME())
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Parametros_Fiscais WHERE Chave = 'REGIME_TRIBUTARIO_PADRAO')
BEGIN
    INSERT INTO dbo.Parametros_Fiscais (Chave, Valor)
    VALUES ('REGIME_TRIBUTARIO_PADRAO', 'SIMPLES_NACIONAL');
END
GO

COMMIT TRANSACTION
GO
