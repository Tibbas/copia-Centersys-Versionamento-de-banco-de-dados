using System.Text;
using Centersys.AtualizadorVersoes.Api.Configuration;
using Centersys.AtualizadorVersoes.Api.Configuration.Data;
using Centersys.AtualizadorVersoes.Api.Controllers;
using Centersys.AtualizadorVersoes.Api.Repositories;
using Centersys.AtualizadorVersoes.Api.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);

builder.Services.Configure<OrquestradorSettings>(
    builder.Configuration.GetSection(OrquestradorSettings.SectionName));
builder.Services.Configure<JwtSettings>(
    builder.Configuration.GetSection(JwtSettings.SectionName));
builder.Services.Configure<GoogleDriveSettings>(
    builder.Configuration.GetSection(GoogleDriveSettings.SectionName));

builder.Services.AddDataProtection();
builder.Services.AddControllers();
builder.Services.AddOpenApi();

var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("ConnectionString 'DefaultConnection' não configurada.");

builder.Services.AddDbContext<ApplicationDbContext>(options =>
{
    options.UseSqlServer(connectionString);
});

builder.Services.AddSingleton<ISqlScriptAnalyzer, SqlScriptAnalyzer>();
builder.Services.AddSingleton<ILoteCancellationManager, LoteCancellationManager>();
builder.Services.AddScoped<ICredentialProvider, DataProtectionCredentialProvider>();
builder.Services.AddScoped<IBancoClientesRepository, BancoClientesRepository>();
builder.Services.AddScoped<IGoogleDriveService, GoogleDriveService>();
builder.Services.AddScoped<VersaoService>();
builder.Services.AddScoped<IVersaoService>(sp => sp.GetRequiredService<VersaoService>());
builder.Services.AddHostedService<AgendamentoWorker>();

builder.Services.AddCors(options =>
{
    options.AddPolicy("FrontendPolicy", policy =>
    {
        var origensExtras = builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>() ?? [];
        var origensPadrao = new[]
        {
            "http://localhost:3000",
            "http://127.0.0.1:3000",
            "http://localhost:5173",
            "http://127.0.0.1:5173"
        };

        policy.WithOrigins(origensPadrao.Concat(origensExtras).Distinct().ToArray())
            .AllowAnyHeader()
            .AllowAnyMethod();
    });
});

var jwtSettings = builder.Configuration.GetSection(JwtSettings.SectionName).Get<JwtSettings>() ?? new JwtSettings();
var jwtSecretKey = AuthController.ObterChaveJwtEfetiva(builder.Configuration, jwtSettings);

builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = jwtSettings.Issuer,
            ValidAudience = jwtSettings.Audience,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSecretKey)),
            ClockSkew = TimeSpan.FromMinutes(1)
        };
    });

builder.Services.AddAuthorization();

var app = builder.Build();

app.UseExceptionHandler(errorApp =>
{
    errorApp.Run(async context =>
    {
        var feature = context.Features.Get<IExceptionHandlerFeature>();
        var exception = feature?.Error;

        var statusCode = exception switch
        {
            KeyNotFoundException => StatusCodes.Status404NotFound,
            UnauthorizedAccessException => StatusCodes.Status401Unauthorized,
            InvalidOperationException or ArgumentException => StatusCodes.Status400BadRequest,
            _ => StatusCodes.Status500InternalServerError
        };

        context.Response.StatusCode = statusCode;
        context.Response.ContentType = "application/json; charset=utf-8";

        var mensagem = statusCode == StatusCodes.Status500InternalServerError
            ? "Ocorreu um erro interno ao processar a solicitação."
            : exception?.Message ?? "Erro na requisição.";

        await context.Response.WriteAsJsonAsync(new { erro = mensagem });
    });
});

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseCors("FrontendPolicy");
app.UseAuthentication();
app.UseAuthorization();

app.MapGet("/api/health", () => Results.Ok(new
{
    status = "Healthy",
    servico = "Centersys.AtualizadorVersoes.Api",
    timestampUtc = DateTime.UtcNow
})).AllowAnonymous();

app.MapControllers();

await DbInitializer.InitializeAsync(app.Services);

app.Run();

public partial class Program;
