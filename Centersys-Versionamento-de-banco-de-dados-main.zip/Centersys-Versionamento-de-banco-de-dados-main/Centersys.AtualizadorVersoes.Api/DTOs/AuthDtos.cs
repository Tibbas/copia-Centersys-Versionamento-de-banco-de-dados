namespace Centersys.AtualizadorVersoes.Api.DTOs;

public class LoginRequest
{
    public required string Email { get; set; }
    public required string Senha { get; set; }
}

public class LoginResponse
{
    public required string Token { get; set; }
    public required DateTime ExpiraEm { get; set; }
    public required UsuarioInfoDto Usuario { get; set; }
}

public class UsuarioInfoDto
{
    public int Id { get; set; }
    public required string Nome { get; set; }
    public required string Email { get; set; }
    public required string Perfil { get; set; }
}
