﻿namespace Centersys.AtualizadorVersoes.Api.DTOs;

public class VersoesDisponiveisResponse
{
    public int Id { get; set; }
    public required string Versao { get; set; }
    public string? Descricao { get; set; }
    public string Origem { get; set; } = "Local";
    public string? IdPastaDrive { get; set; }
    public bool Padrao { get; set; }
    public int QuantidadeScripts { get; set; }
    public DateTime CriadoEm { get; set; }
    public List<ArquivoScriptResumoDto> Arquivos { get; set; } = [];
}

public class ArquivoScriptResumoDto
{
    public int Id { get; set; }
    public required string NomeArquivo { get; set; }
    public int OrdemExecucao { get; set; }
    public required string HashSha256 { get; set; }
    public int QuantidadeLotesGo { get; set; }
    public bool ContemTransacaoInterna { get; set; }
    public bool ContemOperacaoNaoTransacional { get; set; }
    public string? AvisosValidacao { get; set; }
}

public class CadastrarPacoteVersaoRequest
{
    public required string NumeroVersao { get; set; }
    public string? Descricao { get; set; }
    public bool DefinirComoPadrao { get; set; } = false;
    public List<NovoArquivoScriptItem> Arquivos { get; set; } = [];
}

public class NovoArquivoScriptItem
{
    public required string NomeArquivo { get; set; }
    public required string ConteudoSql { get; set; }
}
