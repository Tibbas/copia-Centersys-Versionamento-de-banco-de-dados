namespace Centersys.AtualizadorVersoes.Api.DTOs;

public class BancosAtualizadosResponse
{
    public int Id { get; set; }
    public int ExecucaoLoteId { get; set; }
    public required string NomeEmpresa { get; set; }
    public required string NomeBanco { get; set; }
    public string Servidor { get; set; } = string.Empty;
    public string Datacenter { get; set; } = string.Empty;
    public required string VersaoAnterior { get; set; }
    public required string VersaoAlvo { get; set; }
    public required string VersaoAtual { get; set; }
    public required string Status { get; set; }
    public int ProgressoPercentual { get; set; }
    public string EtapaAtual { get; set; } = string.Empty;
    public string? Mensagem { get; set; }
    public bool Sucesso { get; set; }
    public List<LogExecucaoDto> Logs { get; set; } = [];
}

public class LogExecucaoDto
{
    public int Id { get; set; }
    public required string Time { get; set; }
    public required string Level { get; set; }
    public string? Db { get; set; }
    public required string Message { get; set; }
    public DateTime DataHoraUtc { get; set; }
}
