namespace Centersys.AtualizadorVersoes.Api.DTOs;

public class AtualizarVersoesRequest
{
    public List<AtualizarVersaoItem> Versoes { get; set; } = [];
    public bool PermiteOperacaoNaoTransacional { get; set; } = false;
}

public class AtualizarVersaoItem
{
    public int? IdClienteBanco { get; set; }
    public string NomeEmpresa { get; set; } = string.Empty;
    public string? NomeBanco { get; set; }
    public string VersaoAtual { get; set; } = string.Empty;
    public string VersaoAlvo { get; set; } = string.Empty;
    public string? NomeScriptCustomizado { get; set; }
    public string? ScriptCustomizadoConteudo { get; set; }
}
