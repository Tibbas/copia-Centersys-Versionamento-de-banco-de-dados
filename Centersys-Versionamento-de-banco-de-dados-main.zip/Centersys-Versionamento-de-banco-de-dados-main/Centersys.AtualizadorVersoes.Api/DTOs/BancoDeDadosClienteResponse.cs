namespace Centersys.AtualizadorVersoes.Api.DTOs;

public class BancoDeDadosClienteResponse
{
    public int Id { get; set; }
    public required string NomeEmpresa { get; set; }
    public required string NomeBanco { get; set; }
    public string Servidor { get; set; } = "SRV-SQL-01";
    public string Datacenter { get; set; } = "Datacenter 111";
    public required string VersaoAtual { get; set; }
    public string Status { get; set; } = "DESATUALIZADA";
    public bool Aprovado { get; set; } = true;
    public bool AtivoNaInstancia { get; set; } = true;
    public bool EmExecucao { get; set; } = false;
    public int QuantidadeScriptsPendentes { get; set; }
    public List<string> PacotesPendentes { get; set; } = [];
    public DateTime? UltimaVerificacao { get; set; }
    public DateTime? UltimaAtualizacao { get; set; }
    public string? UltimoErroResumo { get; set; }
    public List<string> LogErros { get; set; } = [];
}
