namespace Centersys.AtualizadorVersoes.Api.DTOs;

public class CriarClienteBancoRequest
{
    public required string NomeEmpresa { get; set; }
    public required string NomeBanco { get; set; }
    public string Servidor { get; set; } = "SRV-SQL-01";
    public string Datacenter { get; set; } = "Datacenter 111";
    public string VersaoInicial { get; set; } = "4.42.0.1";
    public bool CriarBancoFisicoSeNaoExistir { get; set; } = true;
}

public class EditarClienteBancoRequest
{
    public required string NomeEmpresa { get; set; }
    public required string Servidor { get; set; }
    public required string Datacenter { get; set; }
    public bool Aprovado { get; set; } = true;
}

public class TesteConexaoResponse
{
    public int ClienteBancoId { get; set; }
    public required string NomeBanco { get; set; }
    public required string Servidor { get; set; }
    public bool Conectado { get; set; }
    public string? VersaoLida { get; set; }
    public int LatenciaMs { get; set; }
    public required string Mensagem { get; set; }
}

public class StatusLoteExecucaoResponse
{
    public int LoteId { get; set; }
    public required string DisparadoPor { get; set; }
    public required string Origem { get; set; }
    public required string StatusLote { get; set; }
    public int TotalBancos { get; set; }
    public int TotalSucesso { get; set; }
    public int TotalFalha { get; set; }
    public int TotalCancelado { get; set; }
    public int ProgressoGeralPercentual { get; set; }
    public bool EmExecucao { get; set; }
    public bool CancelamentoSolicitado { get; set; }
    public DateTime DataInicio { get; set; }
    public DateTime? DataFim { get; set; }
    public List<BancosAtualizadosResponse> Bancos { get; set; } = [];
    public List<LogExecucaoDto> Logs { get; set; } = [];
}

public class HistoricoExecucaoResumoDto
{
    public int LoteId { get; set; }
    public required string DisparadoPor { get; set; }
    public required string Origem { get; set; }
    public required string StatusLote { get; set; }
    public int TotalBancos { get; set; }
    public int TotalSucesso { get; set; }
    public int TotalFalha { get; set; }
    public int TotalCancelado { get; set; }
    public DateTime DataInicio { get; set; }
    public DateTime? DataFim { get; set; }
    public List<BancosAtualizadosResponse> Bancos { get; set; } = [];
}

public class CriarAgendamentoRequest
{
    public required string Descricao { get; set; }
    public required string VersaoAlvo { get; set; }
    public string? DatacenterEscopo { get; set; }
    public List<int>? IdsClientes { get; set; }
    public DateTime DataHoraProgramada { get; set; }
}

public class AgendamentoResponse
{
    public int Id { get; set; }
    public required string Descricao { get; set; }
    public required string VersaoAlvo { get; set; }
    public string? DatacenterEscopo { get; set; }
    public DateTime DataHoraProgramada { get; set; }
    public required string Status { get; set; }
    public int? ExecucaoLoteId { get; set; }
    public string? MensagemResultado { get; set; }
    public DateTime CriadoEm { get; set; }
    public DateTime? ExecutadoEm { get; set; }
}

public class SalvarCredencialServidorRequest
{
    public required string Servidor { get; set; }
    public required string Datacenter { get; set; }
    public required string HostInstancia { get; set; }
    public int? Porta { get; set; }
    public bool UsarAutenticacaoWindows { get; set; } = true;
    public string? UsuarioSql { get; set; }
    public string? SenhaSql { get; set; }
    public bool TrustServerCertificate { get; set; } = true;
}

public class CredencialServidorResponse
{
    public int Id { get; set; }
    public required string Servidor { get; set; }
    public required string Datacenter { get; set; }
    public required string HostInstancia { get; set; }
    public int? Porta { get; set; }
    public bool UsarAutenticacaoWindows { get; set; }
    public string? UsuarioSql { get; set; }
    public bool PossuiSenhaConfigurada { get; set; }
    public bool TrustServerCertificate { get; set; }
    public bool? UltimaConexaoOk { get; set; }
    public DateTime? UltimaVerificacaoConexao { get; set; }
    public string? MensagemStatusConexao { get; set; }
}
