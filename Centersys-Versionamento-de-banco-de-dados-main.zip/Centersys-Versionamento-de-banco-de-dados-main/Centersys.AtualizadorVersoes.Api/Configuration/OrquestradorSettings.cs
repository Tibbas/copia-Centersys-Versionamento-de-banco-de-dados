namespace Centersys.AtualizadorVersoes.Api.Configuration;

public class OrquestradorSettings
{
    public const string SectionName = "OrquestradorSettings";

    /// <summary>
    /// Tabela que armazena a versão oficial dentro do banco de dados de cada cliente (ex: dbo.Log_Acesso).
    /// </summary>
    public string TabelaVersaoCliente { get; set; } = "dbo.Log_Acesso";

    /// <summary>
    /// Coluna que armazena o texto da versão instalada (ex: cNumVersao).
    /// </summary>
    public string ColunaVersaoCliente { get; set; } = "cNumVersao";

    /// <summary>
    /// Coluna opcional de data de atualização na tabela de versão do cliente.
    /// </summary>
    public string ColunaDataVersaoCliente { get; set; } = "dDataAtualizacao";

    /// <summary>
    /// Versão alvo oficial padrão exibida inicialmente no painel.
    /// </summary>
    public string VersaoAlvoPadrao { get; set; } = "V4.48.0.0";

    /// <summary>
    /// Diretório local contendo as pastas "Versão X.X.X.X" com scripts .sql.
    /// </summary>
    public string PastaScriptsLocais { get; set; } = "ScriptsVersoes";

    /// <summary>
    /// Tempo máximo (em segundos) para cada lote (batch) de comando SQL em um banco de cliente.
    /// </summary>
    public int CommandTimeoutSegundos { get; set; } = 300;

    /// <summary>
    /// Tempo de expiração automática (em minutos) de locks órfãos sobre bancos de clientes.
    /// </summary>
    public int LockTimeoutMinutos { get; set; } = 15;

    /// <summary>
    /// Grau máximo de paralelismo entre diferentes bancos de clientes em um lote.
    /// </summary>
    public int MaxGrauParalelismoPorLote { get; set; } = 2;

    /// <summary>
    /// Em ambiente de desenvolvimento, cria automaticamente os bancos de clientes de demonstração no LocalDB.
    /// </summary>
    public bool CriarBancosDemonstracaoNoStartup { get; set; } = true;
}

public class JwtSettings
{
    public const string SectionName = "JwtSettings";

    public string Issuer { get; set; } = "Centersys.AtualizadorVersoes.Api";
    public string Audience { get; set; } = "Centersys.AtualizadorVersoes.Frontend";
    public string SecretKey { get; set; } = string.Empty;
    public int ExpiracaoHoras { get; set; } = 8;
}

public class GoogleDriveSettings
{
    public const string SectionName = "GoogleDriveSettings";

    public bool Habilitado { get; set; } = false;
    public string? PastaRaizId { get; set; }
    public string? CredenciaisJsonPath { get; set; }
    public string ApplicationName { get; set; } = "CentersysAtualizadorVersoes";
}
