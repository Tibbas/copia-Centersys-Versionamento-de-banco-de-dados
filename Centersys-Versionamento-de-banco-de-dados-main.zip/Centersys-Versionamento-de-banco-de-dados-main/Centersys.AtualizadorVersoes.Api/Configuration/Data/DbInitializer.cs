using Centersys.AtualizadorVersoes.Api.Models;
using Centersys.AtualizadorVersoes.Api.Repositories;
using Centersys.AtualizadorVersoes.Api.Services;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace Centersys.AtualizadorVersoes.Api.Configuration.Data;

public static class DbInitializer
{
    public static async Task InitializeAsync(IServiceProvider rootServices)
    {
        using var scope = rootServices.CreateScope();
        var logger = scope.ServiceProvider.GetRequiredService<ILoggerFactory>().CreateLogger("DbInitializer");
        var dbContext = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
        var repository = scope.ServiceProvider.GetRequiredService<IBancoClientesRepository>();
        var driveService = scope.ServiceProvider.GetRequiredService<IGoogleDriveService>();
        var configuration = scope.ServiceProvider.GetRequiredService<IConfiguration>();
        var settings = scope.ServiceProvider.GetRequiredService<IOptions<OrquestradorSettings>>().Value;

        try
        {
            await dbContext.Database.EnsureCreatedAsync();

            // Limpa eventuais locks órfãos caso o processo tenha sido reiniciado anteriormente
            await dbContext.ClientesBancos
                .Where(c => c.EmExecucaoLock)
                .ExecuteUpdateAsync(s => s
                    .SetProperty(c => c.EmExecucaoLock, false)
                    .SetProperty(c => c.LockToken, (string?)null)
                    .SetProperty(c => c.LockExpiracao, (DateTime?)null));

            // Marca lotes inacabados de reinicializações anteriores como interrompidos
            await dbContext.ExecucoesLote
                .Where(l => l.StatusLote == "EmExecucao")
                .ExecuteUpdateAsync(s => s
                    .SetProperty(l => l.StatusLote, "Interrompido")
                    .SetProperty(l => l.DataFim, DateTime.UtcNow));

            // Seed de usuário administrador inicial (senha com PBKDF2-SHA256)
            if (!await dbContext.Usuarios.AnyAsync())
            {
                dbContext.Usuarios.Add(new UsuarioSistema
                {
                    Nome = "Operador CenterSys",
                    Email = "admin@centersys.com.br",
                    SenhaHash = PasswordHasher.HashPassword("CenterSys@2026"),
                    Perfil = "Admin",
                    Ativo = true
                });
                await dbContext.SaveChangesAsync();
            }

            // Seed das credenciais lógicas de servidores apontando para a instância local configurada
            var defaultConn = configuration.GetConnectionString("DefaultConnection") ?? string.Empty;
            var sqlBuilder = new SqlConnectionStringBuilder(defaultConn);
            var hostPadrao = string.IsNullOrWhiteSpace(sqlBuilder.DataSource)
                ? @"(localdb)\MSSQLLocalDB"
                : sqlBuilder.DataSource;

            if (!await dbContext.CredenciaisServidores.AnyAsync())
            {
                var servidoresIniciais = new (string Servidor, string Datacenter)[]
                {
                    ("SRV-SQL-01", "Datacenter 111"),
                    ("SRV-SQL-02", "Datacenter 111"),
                    ("SRV-SQL-03", "Datacenter 222"),
                    ("SRV-SQL-04", "Datacenter 222"),
                    ("SRV-SQL-05", "Datacenter 111")
                };

                foreach (var (srv, dc) in servidoresIniciais)
                {
                    dbContext.CredenciaisServidores.Add(new CredencialServidor
                    {
                        Servidor = srv,
                        Datacenter = dc,
                        HostInstancia = hostPadrao,
                        UsarAutenticacaoWindows = sqlBuilder.IntegratedSecurity || string.IsNullOrWhiteSpace(sqlBuilder.UserID),
                        TrustServerCertificate = true,
                        Ativo = true,
                        UltimaConexaoOk = true,
                        UltimaVerificacaoConexao = DateTime.UtcNow,
                        MensagemStatusConexao = "Instância configurada na inicialização."
                    });
                }

                await dbContext.SaveChangesAsync();
            }

            // Sincroniza pacotes de versão da pasta ScriptsVersoes/
            await driveService.SincronizarPacotesAsync();

            // Em ambiente de desenvolvimento, cria os bancos físicos de demonstração + banco inativo '_'
            if (settings.CriarBancosDemonstracaoNoStartup && !await dbContext.ClientesBancos.AnyAsync())
            {
                logger.LogInformation("Provisionando bancos de dados multicliente de desenvolvimento no SQL Server...");

                var clientesDemo = new (string Empresa, string Banco, string Servidor, string Datacenter, string Versao, string Status)[]
                {
                    ("Farmácia Boa Saúde",    "db_boasaude_prod",      "SRV-SQL-01", "Datacenter 111", "V4.48.0.0", "Atualizado"),
                    ("Supermercado Central",  "db_central_erp",        "SRV-SQL-02", "Datacenter 111", "V4.46.0.1", "Pendente"),
                    ("Ferragens Silva",       "db_ferragens_prod",     "SRV-SQL-02", "Datacenter 111", "V4.46.0.3", "Pendente"),
                    ("Clínica Vida",          "db_vida_gestao",        "SRV-SQL-03", "Datacenter 222", "V4.45.2.0", "Falha"),
                    ("Autopeças Horizonte",   "db_autohorizonte_prod", "SRV-SQL-04", "Datacenter 222", "V4.48.0.0", "Atualizado"),
                    ("Empório Minas",         "db_emporio_erp",        "SRV-SQL-01", "Datacenter 111", "V4.48.0.0", "Atualizado"),
                    ("Distribuidora Aliança", "db_alianca_prod",       "SRV-SQL-04", "Datacenter 222", "V4.47.0.0", "Pendente"),
                    ("Ótica Visão",           "db_visao_prod",         "SRV-SQL-03", "Datacenter 222", "V4.48.0.0", "Atualizado"),
                    ("Grupo Horizonte",       "DB_Horizonte_Prod",     "SRV-SQL-04", "Datacenter 111", "4.42.0.1",  "DESATUALIZADA")
                };

                foreach (var item in clientesDemo)
                {
                    await repository.CriarEstruturaFisicaBancoClienteAsync(item.Servidor, item.Banco, item.Versao);

                    dbContext.ClientesBancos.Add(new ClienteBanco
                    {
                        NomeEmpresa = item.Empresa,
                        NomeBanco = item.Banco,
                        Servidor = item.Servidor,
                        Datacenter = item.Datacenter,
                        VersaoAtualConhecida = item.Versao,
                        Status = item.Status,
                        Aprovado = true,
                        AtivoNaInstancia = true,
                        UltimaVerificacao = DateTime.UtcNow,
                        UltimoErroResumo = item.Status == "Falha"
                            ? "Falha anterior registrada na última janela de atualização."
                            : null
                    });
                }

                // Cria também um banco começando com '_' (cliente inativo CenterSys) para comprovar o descarte automático!
                await repository.CriarEstruturaFisicaBancoClienteAsync("SRV-SQL-01", "_db_inativo_teste", "4.40.0.0");

                await dbContext.SaveChangesAsync();
                logger.LogInformation("Provisionamento de bancos de clientes concluído com sucesso.");
            }
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Erro ao inicializar o Banco de Controle SQL Server.");
            throw;
        }
    }
}
