using Centersys.AtualizadorVersoes.Api.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Centersys.AtualizadorVersoes.Api.Configuration.Data;

public class UsuarioSistemaConfiguration : IEntityTypeConfiguration<UsuarioSistema>
{
    public void Configure(EntityTypeBuilder<UsuarioSistema> builder)
    {
        builder.ToTable("Usuarios");
        builder.HasKey(u => u.Id);
        builder.Property(u => u.Nome).HasMaxLength(150).IsRequired();
        builder.Property(u => u.Email).HasMaxLength(180).IsRequired();
        builder.Property(u => u.SenhaHash).HasMaxLength(512).IsRequired();
        builder.Property(u => u.Perfil).HasMaxLength(40).IsRequired();
        builder.HasIndex(u => u.Email).IsUnique();
    }
}

public class CredencialServidorConfiguration : IEntityTypeConfiguration<CredencialServidor>
{
    public void Configure(EntityTypeBuilder<CredencialServidor> builder)
    {
        builder.ToTable("CredenciaisServidores");
        builder.HasKey(c => c.Id);
        builder.Property(c => c.Servidor).HasMaxLength(128).IsRequired();
        builder.Property(c => c.Datacenter).HasMaxLength(100).IsRequired();
        builder.Property(c => c.HostInstancia).HasMaxLength(256).IsRequired();
        builder.Property(c => c.UsuarioSql).HasMaxLength(128);
        builder.Property(c => c.SenhaCriptografada).HasMaxLength(2048);
        builder.Property(c => c.MensagemStatusConexao).HasMaxLength(1000);
        builder.HasIndex(c => c.Servidor).IsUnique();
    }
}

public class ClienteBancoConfiguration : IEntityTypeConfiguration<ClienteBanco>
{
    public void Configure(EntityTypeBuilder<ClienteBanco> builder)
    {
        builder.ToTable("ClientesBancos");
        builder.HasKey(c => c.Id);
        builder.Property(c => c.NomeEmpresa).HasMaxLength(150).IsRequired();
        builder.Property(c => c.NomeBanco).HasMaxLength(128).IsRequired();
        builder.Property(c => c.Servidor).HasMaxLength(128).IsRequired();
        builder.Property(c => c.Datacenter).HasMaxLength(100).IsRequired();
        builder.Property(c => c.VersaoAtualConhecida).HasMaxLength(50).IsRequired();
        builder.Property(c => c.Status).HasMaxLength(30).IsRequired();
        builder.Property(c => c.LockToken).HasMaxLength(64);
        builder.Property(c => c.UltimoErroResumo).HasMaxLength(1000);

        builder.HasIndex(c => new { c.Servidor, c.NomeBanco }).IsUnique();
        builder.HasIndex(c => new { c.Status, c.Datacenter });
    }
}

public class PacoteVersaoConfiguration : IEntityTypeConfiguration<PacoteVersao>
{
    public void Configure(EntityTypeBuilder<PacoteVersao> builder)
    {
        builder.ToTable("PacotesVersao");
        builder.HasKey(p => p.Id);
        builder.Property(p => p.NumeroVersao).HasMaxLength(50).IsRequired();
        builder.Property(p => p.VersaoNormalizada).HasMaxLength(120).IsRequired();
        builder.Property(p => p.Descricao).HasMaxLength(500);
        builder.Property(p => p.Origem).HasMaxLength(40).IsRequired();
        builder.Property(p => p.CaminhoOuDriveId).HasMaxLength(500);

        builder.HasIndex(p => p.VersaoNormalizada).IsUnique();
    }
}

public class ArquivoScriptConfiguration : IEntityTypeConfiguration<ArquivoScript>
{
    public void Configure(EntityTypeBuilder<ArquivoScript> builder)
    {
        builder.ToTable("ArquivosScript");
        builder.HasKey(a => a.Id);
        builder.Property(a => a.NomeArquivo).HasMaxLength(260).IsRequired();
        builder.Property(a => a.ConteudoSql).IsRequired();
        builder.Property(a => a.HashSha256).HasMaxLength(64).IsFixedLength().IsRequired();
        builder.Property(a => a.AvisosValidacao).HasMaxLength(1000);

        builder.HasOne(a => a.PacoteVersao)
            .WithMany(p => p.Arquivos)
            .HasForeignKey(a => a.PacoteVersaoId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.HasIndex(a => new { a.PacoteVersaoId, a.NomeArquivo }).IsUnique();
    }
}

public class ExecucaoLoteConfiguration : IEntityTypeConfiguration<ExecucaoLote>
{
    public void Configure(EntityTypeBuilder<ExecucaoLote> builder)
    {
        builder.ToTable("ExecucoesLote");
        builder.HasKey(l => l.Id);
        builder.Property(l => l.DisparadoPor).HasMaxLength(150).IsRequired();
        builder.Property(l => l.Origem).HasMaxLength(40).IsRequired();
        builder.Property(l => l.StatusLote).HasMaxLength(40).IsRequired();
        builder.HasIndex(l => l.DataInicio);
    }
}

public class ExecucaoBancoConfiguration : IEntityTypeConfiguration<ExecucaoBanco>
{
    public void Configure(EntityTypeBuilder<ExecucaoBanco> builder)
    {
        builder.ToTable("ExecucoesBanco");
        builder.HasKey(e => e.Id);
        builder.Property(e => e.NomeEmpresa).HasMaxLength(150).IsRequired();
        builder.Property(e => e.NomeBanco).HasMaxLength(128).IsRequired();
        builder.Property(e => e.Servidor).HasMaxLength(128).IsRequired();
        builder.Property(e => e.Datacenter).HasMaxLength(100).IsRequired();
        builder.Property(e => e.VersaoOrigem).HasMaxLength(50).IsRequired();
        builder.Property(e => e.VersaoAlvo).HasMaxLength(260).IsRequired();
        builder.Property(e => e.VersaoAlcancada).HasMaxLength(260).IsRequired();
        builder.Property(e => e.NomeScriptCustomizado).HasMaxLength(260);
        builder.Property(e => e.Status).HasMaxLength(40).IsRequired();
        builder.Property(e => e.EtapaAtual).HasMaxLength(150).IsRequired();
        builder.Property(e => e.MensagemResumo).HasMaxLength(1000);

        builder.HasOne(e => e.ExecucaoLote)
            .WithMany(l => l.Bancos)
            .HasForeignKey(e => e.ExecucaoLoteId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.HasOne(e => e.ClienteBanco)
            .WithMany(c => c.Execucoes)
            .HasForeignKey(e => e.ClienteBancoId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.HasIndex(e => new { e.ClienteBancoId, e.DataInicio });
    }
}

public class ExecucaoScriptConfiguration : IEntityTypeConfiguration<ExecucaoScript>
{
    public void Configure(EntityTypeBuilder<ExecucaoScript> builder)
    {
        builder.ToTable("ExecucoesScript");
        builder.HasKey(s => s.Id);
        builder.Property(s => s.VersaoPacote).HasMaxLength(260).IsRequired();
        builder.Property(s => s.NomeArquivo).HasMaxLength(260).IsRequired();
        builder.Property(s => s.HashSha256).HasMaxLength(64).IsFixedLength().IsRequired();
        builder.Property(s => s.NivelLog).HasMaxLength(20).IsRequired();
        builder.Property(s => s.MensagemLog).IsRequired();

        builder.HasOne(s => s.ExecucaoBanco)
            .WithMany(e => e.ScriptsExecutados)
            .HasForeignKey(s => s.ExecucaoBancoId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.HasOne(s => s.ClienteBanco)
            .WithMany(c => c.ExecucoesScripts)
            .HasForeignKey(s => s.ClienteBancoId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.HasIndex(s => new { s.ClienteBancoId, s.HashSha256, s.Sucesso });
    }
}

public class LogEventoLoteConfiguration : IEntityTypeConfiguration<LogEventoLote>
{
    public void Configure(EntityTypeBuilder<LogEventoLote> builder)
    {
        builder.ToTable("LogsEventos");
        builder.HasKey(l => l.Id);
        builder.Property(l => l.NomeBanco).HasMaxLength(128);
        builder.Property(l => l.Nivel).HasMaxLength(20).IsRequired();
        builder.Property(l => l.Mensagem).IsRequired();

        builder.HasOne(l => l.ExecucaoLote)
            .WithMany(e => e.Logs)
            .HasForeignKey(l => l.ExecucaoLoteId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.HasIndex(l => new { l.ExecucaoLoteId, l.Id });
        builder.HasIndex(l => l.DataHora);
    }
}

public class AgendamentoConfiguration : IEntityTypeConfiguration<AgendamentoAtualizacao>
{
    public void Configure(EntityTypeBuilder<AgendamentoAtualizacao> builder)
    {
        builder.ToTable("Agendamentos");
        builder.HasKey(a => a.Id);
        builder.Property(a => a.Descricao).HasMaxLength(200).IsRequired();
        builder.Property(a => a.VersaoAlvo).HasMaxLength(50).IsRequired();
        builder.Property(a => a.DatacenterEscopo).HasMaxLength(100);
        builder.Property(a => a.IdsClientesCsv).HasMaxLength(1000);
        builder.Property(a => a.Status).HasMaxLength(30).IsRequired();
        builder.Property(a => a.CriadoPor).HasMaxLength(150).IsRequired();
        builder.Property(a => a.MensagemResultado).HasMaxLength(1000);
        builder.HasIndex(a => new { a.Status, a.DataHoraProgramada });
    }
}
