using Centersys.AtualizadorVersoes.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace Centersys.AtualizadorVersoes.Api.Configuration.Data;

public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : DbContext(options)
{
    public DbSet<UsuarioSistema> Usuarios => Set<UsuarioSistema>();
    public DbSet<CredencialServidor> CredenciaisServidores => Set<CredencialServidor>();
    public DbSet<ClienteBanco> ClientesBancos => Set<ClienteBanco>();
    public DbSet<PacoteVersao> PacotesVersao => Set<PacoteVersao>();
    public DbSet<ArquivoScript> ArquivosScript => Set<ArquivoScript>();
    public DbSet<ExecucaoLote> ExecucoesLote => Set<ExecucaoLote>();
    public DbSet<ExecucaoBanco> ExecucoesBanco => Set<ExecucaoBanco>();
    public DbSet<ExecucaoScript> ExecucoesScript => Set<ExecucaoScript>();
    public DbSet<LogEventoLote> LogsEventos => Set<LogEventoLote>();
    public DbSet<AgendamentoAtualizacao> Agendamentos => Set<AgendamentoAtualizacao>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(ApplicationDbContext).Assembly);
    }
}
