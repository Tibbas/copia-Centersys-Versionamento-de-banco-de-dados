using Centersys.AtualizadorVersoes.Api.DTOs;
using Centersys.AtualizadorVersoes.Api.Models;

namespace Centersys.AtualizadorVersoes.Api.Repositories;

public sealed record ResultadoExecucaoScriptSql(
    bool Sucesso,
    bool ModoNaoTransacional,
    int DuracaoMs,
    int? NumeroErroSql,
    int? LinhaErroSql,
    string Mensagem);

public interface IBancoClientesRepository
{
    Task<List<ClienteBanco>> ObterTodosClientesCatalogoAsync(CancellationToken cancellationToken = default);
    Task<ClienteBanco?> ObterClientePorIdAsync(int id, CancellationToken cancellationToken = default);
    Task<ClienteBanco?> ObterClientePorNomeBancoOuEmpresaAsync(string? nomeBanco, string? nomeEmpresa, CancellationToken cancellationToken = default);
    Task<int> SincronizarDescobertaBancosInstanciaAsync(string? servidorPadrao = null, string? datacenterPadrao = null, CancellationToken cancellationToken = default);
    Task<(bool Conectado, string? VersaoLida, string? Erro)> LerVersaoRealBancoClienteAsync(string servidor, string nomeBanco, CancellationToken cancellationToken = default);
    Task<TesteConexaoResponse> TestarConexaoClienteAsync(ClienteBanco cliente, CancellationToken cancellationToken = default);
    Task CriarEstruturaFisicaBancoClienteAsync(string servidor, string nomeBanco, string versaoInicial, CancellationToken cancellationToken = default);
    Task<bool> TentarAdquirirLockBancoAsync(int clienteBancoId, string lockToken, TimeSpan duracaoLock, CancellationToken cancellationToken = default);
    Task LiberarLockBancoAsync(int clienteBancoId, string lockToken, CancellationToken cancellationToken = default);
    Task<bool> ScriptJaAplicadoComSucessoAsync(int clienteBancoId, string hashSha256, CancellationToken cancellationToken = default);
    Task<ResultadoExecucaoScriptSql> ExecutarArquivoScriptAsync(
        string servidor,
        string nomeBanco,
        Services.AnaliseScriptResultado analise,
        string? versaoFinalParaGravarNoCommit,
        bool permiteOperacaoNaoTransacional,
        CancellationToken cancellationToken = default);
}
