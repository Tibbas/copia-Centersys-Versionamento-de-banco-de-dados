using System.Data;
using System.Diagnostics;
using System.Text.RegularExpressions;
using Centersys.AtualizadorVersoes.Api.Configuration;
using Centersys.AtualizadorVersoes.Api.Configuration.Data;
using Centersys.AtualizadorVersoes.Api.DTOs;
using Centersys.AtualizadorVersoes.Api.Models;
using Centersys.AtualizadorVersoes.Api.Services;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace Centersys.AtualizadorVersoes.Api.Repositories;

public partial class BancoClientesRepository(
    ApplicationDbContext dbContext,
    ICredentialProvider credentialProvider,
    IOptions<OrquestradorSettings> settingsOptions,
    ILogger<BancoClientesRepository> logger) : IBancoClientesRepository
{
    private readonly OrquestradorSettings _settings = settingsOptions.Value;

    [GeneratedRegex(@"^(?:[A-Za-z0-9_]+\.)?[A-Za-z0-9_]+$", RegexOptions.CultureInvariant)]
    private static partial Regex SafeTableIdentifierRegex();

    [GeneratedRegex(@"^[A-Za-z0-9_]+$", RegexOptions.CultureInvariant)]
    private static partial Regex SafeColumnIdentifierRegex();

    public async Task<List<ClienteBanco>> ObterTodosClientesCatalogoAsync(CancellationToken cancellationToken = default)
    {
        return await dbContext.ClientesBancos
            .OrderBy(c => c.Id)
            .ToListAsync(cancellationToken);
    }

    public async Task<ClienteBanco?> ObterClientePorIdAsync(int id, CancellationToken cancellationToken = default)
    {
        return await dbContext.ClientesBancos.FirstOrDefaultAsync(c => c.Id == id, cancellationToken);
    }

    public async Task<ClienteBanco?> ObterClientePorNomeBancoOuEmpresaAsync(
        string? nomeBanco,
        string? nomeEmpresa,
        CancellationToken cancellationToken = default)
    {
        if (!string.IsNullOrWhiteSpace(nomeBanco))
        {
            var porBanco = await dbContext.ClientesBancos
                .FirstOrDefaultAsync(c => c.NomeBanco == nomeBanco, cancellationToken);
            if (porBanco is not null)
                return porBanco;
        }

        if (!string.IsNullOrWhiteSpace(nomeEmpresa))
        {
            return await dbContext.ClientesBancos
                .FirstOrDefaultAsync(c => c.NomeEmpresa == nomeEmpresa, cancellationToken);
        }

        return null;
    }

    public async Task<int> SincronizarDescobertaBancosInstanciaAsync(
        string? servidorPadrao = null,
        string? datacenterPadrao = null,
        CancellationToken cancellationToken = default)
    {
        var servidor = string.IsNullOrWhiteSpace(servidorPadrao) ? "SRV-SQL-01" : servidorPadrao;
        var datacenter = string.IsNullOrWhiteSpace(datacenterPadrao) ? "Datacenter 111" : datacenterPadrao;

        string connString;
        try
        {
            connString = await credentialProvider.ObterConnectionStringInstanciaAsync(servidor, cancellationToken);
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Não foi possível obter connection string para descoberta na instância {Servidor}.", servidor);
            return 0;
        }

        var bancosAtivosDescobertos = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        try
        {
            await using var conn = new SqlConnection(connString);
            await conn.OpenAsync(cancellationToken);

            // Regra oficial CenterSys (B9): descartar bancos de sistema, banco central e bancos que começam com '_'
            const string sqlDescoberta = """
                SELECT name
                FROM sys.databases
                WHERE state = 0
                  AND database_id > 4
                  AND name <> N'CentersysControle'
                  AND name NOT LIKE N'\_%' ESCAPE N'\'
                ORDER BY name;
                """;

            await using var cmd = new SqlCommand(sqlDescoberta, conn) { CommandTimeout = 15 };
            await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                var dbName = reader.GetString(0);
                bancosAtivosDescobertos.Add(dbName);
            }
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Falha ao consultar sys.databases na instância {Servidor}.", servidor);
            return 0;
        }

        var existentes = await dbContext.ClientesBancos.ToListAsync(cancellationToken);
        var novosAdicionados = 0;

        foreach (var dbName in bancosAtivosDescobertos)
        {
            var cadastro = existentes.FirstOrDefault(e =>
                string.Equals(e.NomeBanco, dbName, StringComparison.OrdinalIgnoreCase));

            var (conectado, versaoLida, _) = await LerVersaoRealBancoClienteAsync(servidor, dbName, cancellationToken);
            if (!conectado || string.IsNullOrWhiteSpace(versaoLida))
                continue; // Ignora outros bancos aleatórios da máquina que não possuem a tabela dbo.Log_Acesso

            if (cadastro is null)
            {
                var statusInicial = VersionComparer.Compare(versaoLida, _settings.VersaoAlvoPadrao) >= 0
                    ? "Atualizado"
                    : "DESATUALIZADA";

                dbContext.ClientesBancos.Add(new ClienteBanco
                {
                    NomeEmpresa = FormatarNomeEmpresaAmigavel(dbName),
                    NomeBanco = dbName,
                    Servidor = servidor,
                    Datacenter = datacenter,
                    VersaoAtualConhecida = versaoLida,
                    Status = statusInicial,
                    Aprovado = true,
                    DescobertoAutomaticamente = true,
                    AtivoNaInstancia = true,
                    UltimaVerificacao = DateTime.UtcNow
                });
                novosAdicionados++;
            }
            else
            {
                cadastro.AtivoNaInstancia = true;
                cadastro.VersaoAtualConhecida = versaoLida;
                cadastro.UltimaVerificacao = DateTime.UtcNow;

                if (cadastro.Status != "Atualizando..." && cadastro.Status != "Falha")
                {
                    cadastro.Status = VersionComparer.Compare(versaoLida, _settings.VersaoAlvoPadrao) >= 0
                        ? "Atualizado"
                        : cadastro.Status == "Pendente" ? "Pendente" : "DESATUALIZADA";
                }
            }
        }

        await dbContext.SaveChangesAsync(cancellationToken);
        return novosAdicionados;
    }

    public async Task<(bool Conectado, string? VersaoLida, string? Erro)> LerVersaoRealBancoClienteAsync(
        string servidor,
        string nomeBanco,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var (tabelaSql, colunaVersaoSql, _) = ObterIdentificadoresTabelaVersaoSeguros();
            var connString = await credentialProvider.ObterConnectionStringClienteAsync(
                servidor,
                nomeBanco,
                bloquearInativosComUnderline: true,
                cancellationToken);

            await using var conn = new SqlConnection(connString);
            await conn.OpenAsync(cancellationToken);

            var sql = $"SELECT TOP (1) {colunaVersaoSql} FROM {tabelaSql};";
            await using var cmd = new SqlCommand(sql, conn) { CommandTimeout = 15 };
            var result = await cmd.ExecuteScalarAsync(cancellationToken);

            if (result is null || result == DBNull.Value)
                return (true, null, $"A tabela {_settings.TabelaVersaoCliente} está vazia no banco '{nomeBanco}'.");

            return (true, Convert.ToString(result)?.Trim(), null);
        }
        catch (SqlException ex)
        {
            return (false, null, $"Erro SQL ({ex.Number}): {ex.Message}");
        }
        catch (Exception ex)
        {
            return (false, null, ex.Message);
        }
    }

    public async Task<TesteConexaoResponse> TestarConexaoClienteAsync(
        ClienteBanco cliente,
        CancellationToken cancellationToken = default)
    {
        var sw = Stopwatch.StartNew();
        var (conectado, versaoLida, erro) = await LerVersaoRealBancoClienteAsync(
            cliente.Servidor,
            cliente.NomeBanco,
            cancellationToken);
        sw.Stop();

        cliente.UltimaVerificacao = DateTime.UtcNow;
        cliente.AtivoNaInstancia = conectado;
        if (conectado && !string.IsNullOrWhiteSpace(versaoLida))
        {
            cliente.VersaoAtualConhecida = versaoLida;
        }
        await dbContext.SaveChangesAsync(cancellationToken);

        return new TesteConexaoResponse
        {
            ClienteBancoId = cliente.Id,
            NomeBanco = cliente.NomeBanco,
            Servidor = cliente.Servidor,
            Conectado = conectado,
            VersaoLida = versaoLida,
            LatenciaMs = (int)sw.ElapsedMilliseconds,
            Mensagem = conectado
                ? $"Conexão estabelecida com sucesso ({sw.ElapsedMilliseconds} ms). Versão lida em {_settings.TabelaVersaoCliente}: {versaoLida ?? "N/D"}."
                : $"Falha ao conectar em '{cliente.NomeBanco}': {erro}"
        };
    }

    public async Task CriarEstruturaFisicaBancoClienteAsync(
        string servidor,
        string nomeBanco,
        string versaoInicial,
        CancellationToken cancellationToken = default)
    {
        credentialProvider.ValidarNomeBancoCliente(nomeBanco, bloquearInativosComUnderline: false);
        var instanceConn = await credentialProvider.ObterConnectionStringInstanciaAsync(servidor, cancellationToken);

        await using (var masterConn = new SqlConnection(instanceConn))
        {
            await masterConn.OpenAsync(cancellationToken);
            const string createDbSql = """
                IF DB_ID(@dbName) IS NULL
                BEGIN
                    DECLARE @sql NVARCHAR(400) = N'CREATE DATABASE ' + QUOTENAME(@dbName) + N';';
                    EXEC sp_executesql @sql;
                END
                """;
            await using var createCmd = new SqlCommand(createDbSql, masterConn) { CommandTimeout = 60 };
            createCmd.Parameters.AddWithValue("@dbName", nomeBanco);
            await createCmd.ExecuteNonQueryAsync(cancellationToken);
        }

        var clientConnStr = await credentialProvider.ObterConnectionStringClienteAsync(
            servidor,
            nomeBanco,
            bloquearInativosComUnderline: false,
            cancellationToken);

        await using var clientConn = new SqlConnection(clientConnStr);
        await clientConn.OpenAsync(cancellationToken);

        const string createTableSql = """
            IF OBJECT_ID('dbo.Log_Acesso', 'U') IS NULL
            BEGIN
                CREATE TABLE dbo.Log_Acesso (
                    Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Log_Acesso PRIMARY KEY,
                    cNumVersao VARCHAR(50) NOT NULL,
                    dDataAtualizacao DATETIME2 NOT NULL CONSTRAINT DF_Log_Acesso_Data DEFAULT (SYSDATETIME())
                );
            END

            IF NOT EXISTS (SELECT 1 FROM dbo.Log_Acesso)
            BEGIN
                INSERT INTO dbo.Log_Acesso (cNumVersao, dDataAtualizacao)
                VALUES (@versao, SYSDATETIME());
            END
            """;

        await using var tableCmd = new SqlCommand(createTableSql, clientConn) { CommandTimeout = 30 };
        tableCmd.Parameters.AddWithValue("@versao", versaoInicial);
        await tableCmd.ExecuteNonQueryAsync(cancellationToken);
    }

    public async Task<bool> TentarAdquirirLockBancoAsync(
        int clienteBancoId,
        string lockToken,
        TimeSpan duracaoLock,
        CancellationToken cancellationToken = default)
    {
        var agora = DateTime.UtcNow;
        var expiracao = agora.Add(duracaoLock);

        var linhasAfetadas = await dbContext.ClientesBancos
            .Where(c => c.Id == clienteBancoId &&
                        (!c.EmExecucaoLock || c.LockExpiracao == null || c.LockExpiracao < agora))
            .ExecuteUpdateAsync(setters => setters
                .SetProperty(c => c.EmExecucaoLock, true)
                .SetProperty(c => c.LockToken, lockToken)
                .SetProperty(c => c.LockExpiracao, expiracao),
                cancellationToken);

        return linhasAfetadas > 0;
    }

    public async Task LiberarLockBancoAsync(
        int clienteBancoId,
        string lockToken,
        CancellationToken cancellationToken = default)
    {
        await dbContext.ClientesBancos
            .Where(c => c.Id == clienteBancoId && c.LockToken == lockToken)
            .ExecuteUpdateAsync(setters => setters
                .SetProperty(c => c.EmExecucaoLock, false)
                .SetProperty(c => c.LockToken, (string?)null)
                .SetProperty(c => c.LockExpiracao, (DateTime?)null),
                cancellationToken);
    }

    public async Task<bool> ScriptJaAplicadoComSucessoAsync(
        int clienteBancoId,
        string hashSha256,
        CancellationToken cancellationToken = default)
    {
        return await dbContext.ExecucoesScript
            .AsNoTracking()
            .AnyAsync(s => s.ClienteBancoId == clienteBancoId &&
                           s.HashSha256 == hashSha256 &&
                           s.Sucesso,
                cancellationToken);
    }

    public async Task<ResultadoExecucaoScriptSql> ExecutarArquivoScriptAsync(
        string servidor,
        string nomeBanco,
        AnaliseScriptResultado analise,
        string? versaoFinalParaGravarNoCommit,
        bool permiteOperacaoNaoTransacional,
        CancellationToken cancellationToken = default)
    {
        if (!analise.Valido)
        {
            return new ResultadoExecucaoScriptSql(
                Sucesso: false,
                ModoNaoTransacional: false,
                DuracaoMs: 0,
                NumeroErroSql: null,
                LinhaErroSql: null,
                Mensagem: string.Join(" | ", analise.ErrosBloqueantes));
        }

        if (analise.ContemOperacaoNaoTransacional && !permiteOperacaoNaoTransacional)
        {
            return new ResultadoExecucaoScriptSql(
                Sucesso: false,
                ModoNaoTransacional: true,
                DuracaoMs: 0,
                NumeroErroSql: null,
                LinhaErroSql: null,
                Mensagem: $"Script '{analise.NomeArquivo}' recusado por segurança: contém operações não transacionais ({string.Join(", ", analise.Avisos)}) e a flag PermiteOperacaoNaoTransacional não foi habilitada.");
        }

        var usarModoNaoTransacional = analise.ContemOperacaoNaoTransacional && permiteOperacaoNaoTransacional;
        var sw = Stopwatch.StartNew();
        var (tabelaSql, colunaVersaoSql, colunaDataSql) = ObterIdentificadoresTabelaVersaoSeguros();

        var connString = await credentialProvider.ObterConnectionStringClienteAsync(
            servidor,
            nomeBanco,
            bloquearInativosComUnderline: true,
            cancellationToken);

        await using var conn = new SqlConnection(connString);
        await conn.OpenAsync(cancellationToken);

        SqlTransaction? transaction = null;
        var loteAtualLinhaBase = 1;

        try
        {
            if (!usarModoNaoTransacional)
            {
                transaction = (SqlTransaction)await conn.BeginTransactionAsync(IsolationLevel.ReadCommitted, cancellationToken);

                await using var xactCmd = new SqlCommand("SET XACT_ABORT ON;", conn, transaction)
                {
                    CommandTimeout = 15
                };
                await xactCmd.ExecuteNonQueryAsync(cancellationToken);
            }

            foreach (var lote in analise.Lotes)
            {
                cancellationToken.ThrowIfCancellationRequested();
                loteAtualLinhaBase = lote.LinhaInicial;

                await using var batchCmd = new SqlCommand(lote.SqlTexto, conn, transaction)
                {
                    CommandTimeout = Math.Max(30, _settings.CommandTimeoutSegundos)
                };
                await batchCmd.ExecuteNonQueryAsync(cancellationToken);
            }

            // Garante gravação da versão de destino dentro da mesma transação do último script do pacote (Decisão 9.1/9.2)
            if (!string.IsNullOrWhiteSpace(versaoFinalParaGravarNoCommit))
            {
                var sqlUpdateVersao = $"""
                    IF COL_LENGTH('{_settings.TabelaVersaoCliente}', '{_settings.ColunaDataVersaoCliente}') IS NOT NULL
                        UPDATE {tabelaSql} SET {colunaVersaoSql} = @novaVersao, {colunaDataSql} = SYSDATETIME();
                    ELSE
                        UPDATE {tabelaSql} SET {colunaVersaoSql} = @novaVersao;
                    """;

                await using var versionCmd = new SqlCommand(sqlUpdateVersao, conn, transaction)
                {
                    CommandTimeout = 30
                };
                versionCmd.Parameters.AddWithValue("@novaVersao", versaoFinalParaGravarNoCommit);
                var updated = await versionCmd.ExecuteNonQueryAsync(cancellationToken);
                if (updated == 0)
                {
                    var sqlInsertVersao = $"INSERT INTO {tabelaSql} ({colunaVersaoSql}) VALUES (@novaVersao);";
                    await using var insertCmd = new SqlCommand(sqlInsertVersao, conn, transaction) { CommandTimeout = 30 };
                    insertCmd.Parameters.AddWithValue("@novaVersao", versaoFinalParaGravarNoCommit);
                    await insertCmd.ExecuteNonQueryAsync(cancellationToken);
                }
            }

            if (transaction is not null)
            {
                await transaction.CommitAsync(cancellationToken);
            }

            sw.Stop();
            return new ResultadoExecucaoScriptSql(
                Sucesso: true,
                ModoNaoTransacional: usarModoNaoTransacional,
                DuracaoMs: (int)sw.ElapsedMilliseconds,
                NumeroErroSql: null,
                LinhaErroSql: null,
                Mensagem: $"Script '{analise.NomeArquivo}' aplicado com sucesso ({analise.Lotes.Count} lote(s), {sw.ElapsedMilliseconds} ms).");
        }
        catch (SqlException sqlEx)
        {
            sw.Stop();
            var rollbackMsg = "MODO NÃO TRANSACIONAL (reversão automática indisponível)";
            if (transaction is not null)
            {
                try
                {
                    await transaction.RollbackAsync(CancellationToken.None);
                    rollbackMsg = "ROLLBACK executado com sucesso (banco mantido íntegro)";
                }
                catch (Exception rbEx)
                {
                    rollbackMsg = $"Alerta ao reverter transação: {rbEx.Message}";
                }
            }

            var linhaRealNoArquivo = Math.Max(1, loteAtualLinhaBase + sqlEx.LineNumber - 1);
            return new ResultadoExecucaoScriptSql(
                Sucesso: false,
                ModoNaoTransacional: usarModoNaoTransacional,
                DuracaoMs: (int)sw.ElapsedMilliseconds,
                NumeroErroSql: sqlEx.Number,
                LinhaErroSql: linhaRealNoArquivo,
                Mensagem: $"Falha SQL ({sqlEx.Number}) em '{analise.NomeArquivo}' na linha {linhaRealNoArquivo}: {sqlEx.Message} — {rollbackMsg}.");
        }
        catch (OperationCanceledException)
        {
            sw.Stop();
            if (transaction is not null)
            {
                try { await transaction.RollbackAsync(CancellationToken.None); } catch { /* ignore */ }
            }

            return new ResultadoExecucaoScriptSql(
                Sucesso: false,
                ModoNaoTransacional: usarModoNaoTransacional,
                DuracaoMs: (int)sw.ElapsedMilliseconds,
                NumeroErroSql: null,
                LinhaErroSql: null,
                Mensagem: $"Execução de '{analise.NomeArquivo}' cancelada pelo operador — ROLLBACK aplicado.");
        }
        catch (Exception ex)
        {
            sw.Stop();
            if (transaction is not null)
            {
                try { await transaction.RollbackAsync(CancellationToken.None); } catch { /* ignore */ }
            }

            return new ResultadoExecucaoScriptSql(
                Sucesso: false,
                ModoNaoTransacional: usarModoNaoTransacional,
                DuracaoMs: (int)sw.ElapsedMilliseconds,
                NumeroErroSql: null,
                LinhaErroSql: null,
                Mensagem: $"Erro inesperado ao executar '{analise.NomeArquivo}': {ex.Message} — ROLLBACK aplicado.");
        }
        finally
        {
            if (transaction is not null)
            {
                await transaction.DisposeAsync();
            }
        }
    }

    private (string TabelaQuotada, string ColunaVersaoQuotada, string ColunaDataQuotada) ObterIdentificadoresTabelaVersaoSeguros()
    {
        if (!SafeTableIdentifierRegex().IsMatch(_settings.TabelaVersaoCliente))
            throw new InvalidOperationException("Configuração TabelaVersaoCliente contém caracteres inválidos.");
        if (!SafeColumnIdentifierRegex().IsMatch(_settings.ColunaVersaoCliente))
            throw new InvalidOperationException("Configuração ColunaVersaoCliente contém caracteres inválidos.");
        if (!SafeColumnIdentifierRegex().IsMatch(_settings.ColunaDataVersaoCliente))
            throw new InvalidOperationException("Configuração ColunaDataVersaoCliente contém caracteres inválidos.");

        var partesTabela = _settings.TabelaVersaoCliente.Split('.');
        var tabelaQuotada = partesTabela.Length == 2
            ? $"[{partesTabela[0]}].[{partesTabela[1]}]"
            : $"[dbo].[{partesTabela[0]}]";

        return (tabelaQuotada, $"[{_settings.ColunaVersaoCliente}]", $"[{_settings.ColunaDataVersaoCliente}]");
    }

    private static string FormatarNomeEmpresaAmigavel(string dbName)
    {
        var limpo = Regex.Replace(dbName, @"^(db_|DB_)", "");
        limpo = Regex.Replace(limpo, @"(_prod|_Prod|_erp|_gestao)$", "");
        return $"Cliente {limpo}";
    }
}
