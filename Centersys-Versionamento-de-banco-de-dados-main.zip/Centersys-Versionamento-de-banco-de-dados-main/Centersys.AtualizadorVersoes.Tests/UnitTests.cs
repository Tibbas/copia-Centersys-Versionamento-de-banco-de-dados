using Centersys.AtualizadorVersoes.Api.Configuration.Data;
using Centersys.AtualizadorVersoes.Api.Services;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace Centersys.AtualizadorVersoes.Tests;

public class UnitTests
{
    [Theory]
    [InlineData("4.5.0.0", "4.10.0.0", -1)]
    [InlineData("V4.48.0.0", "4.48.0.0", 0)]
    [InlineData("4.48.0.1", "V4.48.0.0", 1)]
    [InlineData("4.46.0", "4.46.0.0", 0)]
    [InlineData("4.46.0.4", "4.46.0.3.9", 1)]
    public void VersionComparer_DeveCompararNSegmentosNumericamente(string v1, string v2, int esperado)
    {
        var resultado = Math.Sign(VersionComparer.Compare(v1, v2));
        Assert.Equal(esperado, resultado);
    }

    [Theory]
    [InlineData("Versão 4.46.0.4", true, "V4.46.0.4")]
    [InlineData("versao_4.47.0.0", true, "V4.47.0.0")]
    [InlineData("V4.48.0.0", true, "V4.48.0.0")]
    [InlineData("4.42.0.1", true, "V4.42.0.1")]
    [InlineData("pasta_invalida", false, "")]
    public void VersionComparer_DeveExtrairVersaoDeNomesDePastasReais(string entrada, bool deveExtrair, string versaoEsperada)
    {
        var ok = VersionComparer.TryExtractVersion(entrada, out var extraida);
        Assert.Equal(deveExtrair, ok);
        Assert.Equal(versaoEsperada, extraida);
    }

    [Fact]
    public void VersionComparer_DeveGarantirScriptVersaoPorUltimoEOrdemNatural()
    {
        var arquivos = new[]
        {
            "scriptVersao.sql",
            "script10.sql",
            "script2.sql",
            "script1.sql"
        };

        var ordenados = VersionComparer.OrderPackageScripts(arquivos, x => x);

        Assert.Equal(["script1.sql", "script2.sql", "script10.sql", "scriptVersao.sql"], ordenados);
    }

    [Fact]
    public void SqlScriptAnalyzer_DeveSepararLotesGoSemQuebrarEmStringsOuComentarios()
    {
        var analyzer = new SqlScriptAnalyzer();
        const string sql = """
            /* Comentário contendo GO em bloco
               GO */
            INSERT INTO dbo.Teste (Cidade, Uf) VALUES ('Goiânia - GO', 'GO');
            GO
            -- Comentário de linha com GO
            UPDATE dbo.Teste SET Uf = 'GO' WHERE Uf = 'GO';
            GO
            """;

        var resultado = analyzer.Analisar(sql, "teste_go.sql");

        Assert.True(resultado.Valido);
        Assert.Equal(2, resultado.Lotes.Count);
        Assert.Contains("'Goiânia - GO'", resultado.Lotes[0].SqlTexto);
        Assert.DoesNotContain("\nGO", resultado.Lotes[0].SqlTexto);
    }

    [Fact]
    public void SqlScriptAnalyzer_DeveBloquearComandoUseProibido()
    {
        var analyzer = new SqlScriptAnalyzer();
        const string sql = """
            USE master;
            GO
            SELECT 1;
            """;

        var resultado = analyzer.Analisar(sql, "proibido_use.sql");

        Assert.False(resultado.Valido);
        Assert.True(resultado.ContemComandoUse);
        Assert.Contains(resultado.ErrosBloqueantes, e => e.Contains("USE", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public void SqlScriptAnalyzer_DeveBloquearRollbackForaDeCatchETransacaoDesbalanceada()
    {
        var analyzer = new SqlScriptAnalyzer();
        const string sqlDesbalanceado = """
            BEGIN TRANSACTION;
            UPDATE dbo.Tabela SET Ativo = 1;
            """;

        var res1 = analyzer.Analisar(sqlDesbalanceado, "desbalanceado.sql");
        Assert.False(res1.Valido);

        const string sqlRollbackSolto = """
            UPDATE dbo.Tabela SET Ativo = 1;
            ROLLBACK TRANSACTION;
            """;

        var res2 = analyzer.Analisar(sqlRollbackSolto, "rollback_solto.sql");
        Assert.False(res2.Valido);
        Assert.True(res2.ContemRollbackExplicito);
    }

    [Fact]
    public void SqlScriptAnalyzer_DeveAceitarBeginCommitBalanceadosEDetectarOperacaoNaoTransacional()
    {
        var analyzer = new SqlScriptAnalyzer();
        const string sqlBalanceado = """
            BEGIN TRANSACTION
            GO
            CREATE TABLE dbo.Exemplo (Id INT PRIMARY KEY);
            GO
            COMMIT TRANSACTION
            GO
            """;

        var resBalanceado = analyzer.Analisar(sqlBalanceado, "ssms_padrao.sql");
        Assert.True(resBalanceado.Valido);
        Assert.True(resBalanceado.ContemTransacaoInterna);
        Assert.Equal(3, resBalanceado.Lotes.Count);

        const string sqlNaoTransacional = "ALTER DATABASE CURRENT SET RECOVERY SIMPLE;";
        var resNaoTran = analyzer.Analisar(sqlNaoTransacional, "alter_db.sql");
        Assert.True(resNaoTran.Valido);
        Assert.True(resNaoTran.ContemOperacaoNaoTransacional);
    }

    [Fact]
    public void PasswordHasher_DeveGerarHashSalgadoEValidarComSeguranca()
    {
        var hash = PasswordHasher.HashPassword("SenhaForte@2026!");
        Assert.True(PasswordHasher.VerifyPassword("SenhaForte@2026!", hash));
        Assert.False(PasswordHasher.VerifyPassword("SenhaErrada", hash));
    }

    [Theory]
    [InlineData("master")]
    [InlineData("CentersysControle")]
    [InlineData("_db_inativo_teste")]
    [InlineData("db_teste; DROP DATABASE master;--")]
    public void CredentialProvider_DeveBloquearBancosProibidosInativosESqlInjection(string nomeBancoInvalido)
    {
        var options = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseSqlServer("Server=(localdb)\\MSSQLLocalDB;Database=Dummy;Trusted_Connection=True;")
            .Options;
        using var ctx = new ApplicationDbContext(options);

        var config = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["ConnectionStrings:DefaultConnection"] = "Server=(localdb)\\MSSQLLocalDB;Database=CentersysControle;Trusted_Connection=True;"
            })
            .Build();

        var provider = new DataProtectionCredentialProvider(
            ctx,
            config,
            DataProtectionProvider.Create("Tests"));

        Assert.Throws<InvalidOperationException>(() => provider.ValidarNomeBancoCliente(nomeBancoInvalido, bloquearInativosComUnderline: true));
    }
}
