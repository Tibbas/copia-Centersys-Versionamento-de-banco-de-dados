using Centersys.AtualizadorVersoes.Api.Configuration;
using Centersys.AtualizadorVersoes.Api.Configuration.Data;
using Centersys.AtualizadorVersoes.Api.DTOs;
using Centersys.AtualizadorVersoes.Api.Models;
using Centersys.AtualizadorVersoes.Api.Repositories;
using Centersys.AtualizadorVersoes.Api.Services;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Options;

namespace Centersys.AtualizadorVersoes.Tests;

public sealed class SqlServerIntegrationTests : IAsyncLifetime
{
    private readonly string _controlDbName = $"CentersysCtrl_Test_{Guid.NewGuid():N}"[..28];
    private readonly string _clientDbA = $"db_test_cliA_{Guid.NewGuid():N}"[..24];
    private readonly string _clientDbB = $"db_test_cliB_{Guid.NewGuid():N}"[..24];
    private readonly string _inactiveDb = $"_db_test_inativo_{Guid.NewGuid():N}"[..26];
    private ServiceProvider _serviceProvider = null!;

    public async Task InitializeAsync()
    {
        var connString = $"Server=(localdb)\\MSSQLLocalDB;Database={_controlDbName};Trusted_Connection=True;TrustServerCertificate=True;MultipleActiveResultSets=True;";
        var apiProjectPath = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "Centersys.AtualizadorVersoes.Api"));

        var configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["ConnectionStrings:DefaultConnection"] = connString,
                ["CENTERSYS_JWT_SECRET"] = "TEST_ONLY_JWT_SECRET_KEY_WITH_AT_LEAST_32_BYTES_2026"
            })
            .Build();

        var services = new ServiceCollection();
        services.AddLogging();
        services.AddDataProtection();
        services.AddSingleton<IConfiguration>(configuration);
        services.AddSingleton<IWebHostEnvironment>(new FakeWebHostEnvironment(apiProjectPath));

        services.Configure<OrquestradorSettings>(opt =>
        {
            opt.PastaScriptsLocais = Path.Combine(apiProjectPath, "ScriptsVersoes");
            opt.VersaoAlvoPadrao = "V4.48.0.0";
            opt.CriarBancosDemonstracaoNoStartup = false;
        });
        services.Configure<GoogleDriveSettings>(opt => opt.Habilitado = false);

        services.AddDbContext<ApplicationDbContext>(opt => opt.UseSqlServer(connString));
        services.AddSingleton<ISqlScriptAnalyzer, SqlScriptAnalyzer>();
        services.AddSingleton<ILoteCancellationManager, LoteCancellationManager>();
        services.AddScoped<ICredentialProvider, DataProtectionCredentialProvider>();
        services.AddScoped<IBancoClientesRepository, BancoClientesRepository>();
        services.AddScoped<IGoogleDriveService, GoogleDriveService>();
        services.AddScoped<VersaoService>();
        services.AddScoped<IVersaoService>(sp => sp.GetRequiredService<VersaoService>());

        _serviceProvider = services.BuildServiceProvider();

        using var scope = _serviceProvider.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
        var repo = scope.ServiceProvider.GetRequiredService<IBancoClientesRepository>();
        var drive = scope.ServiceProvider.GetRequiredService<IGoogleDriveService>();

        await db.Database.EnsureCreatedAsync();

        db.CredenciaisServidores.Add(new CredencialServidor
        {
            Servidor = "SRV-TEST-01",
            Datacenter = "Datacenter 111",
            HostInstancia = @"(localdb)\MSSQLLocalDB",
            UsarAutenticacaoWindows = true,
            TrustServerCertificate = true,
            Ativo = true
        });
        await db.SaveChangesAsync();

        await drive.SincronizarPacotesAsync();

        // Cria bancos físicos temporários para os testes reais de SQL Server
        await repo.CriarEstruturaFisicaBancoClienteAsync("SRV-TEST-01", _clientDbA, "4.42.0.1");
        await repo.CriarEstruturaFisicaBancoClienteAsync("SRV-TEST-01", _clientDbB, "V4.46.0.4");
        await repo.CriarEstruturaFisicaBancoClienteAsync("SRV-TEST-01", _inactiveDb, "4.40.0.0");

        db.ClientesBancos.AddRange(
            new ClienteBanco
            {
                NomeEmpresa = "Empresa Teste A",
                NomeBanco = _clientDbA,
                Servidor = "SRV-TEST-01",
                Datacenter = "Datacenter 111",
                VersaoAtualConhecida = "4.42.0.1",
                Status = "DESATUALIZADA",
                Aprovado = true
            },
            new ClienteBanco
            {
                NomeEmpresa = "Empresa Teste B",
                NomeBanco = _clientDbB,
                Servidor = "SRV-TEST-01",
                Datacenter = "Datacenter 111",
                VersaoAtualConhecida = "V4.46.0.4",
                Status = "Pendente",
                Aprovado = true
            });

        await db.SaveChangesAsync();
    }

    [Fact]
    public async Task FluxoCompleto_DescobertaUnderline_AtualizacaoMultiPacote_RollbackIsolado_E_Idempotencia()
    {
        using var scope = _serviceProvider.CreateScope();
        var service = scope.ServiceProvider.GetRequiredService<IVersaoService>();
        var repo = scope.ServiceProvider.GetRequiredService<IBancoClientesRepository>();

        // 1. Verifica que bancos iniciados por '_' jamais entram na listagem/descoberta
        var listaInicial = (await service.GetBancoDeDadosClientesAsync(sincronizarInstancia: true)).ToList();
        Assert.Contains(listaInicial, c => c.NomeBanco == _clientDbA && c.VersaoAtual == "4.42.0.1");
        Assert.Contains(listaInicial, c => c.NomeBanco == _clientDbB && c.VersaoAtual == "V4.46.0.4");
        Assert.DoesNotContain(listaInicial, c => c.NomeBanco == _inactiveDb);

        // 2. Testa concorrência: Lock exclusivo impede execução paralela duplicada no mesmo banco
        var cliA = listaInicial.First(c => c.NomeBanco == _clientDbA);
        var lock1 = await repo.TentarAdquirirLockBancoAsync(cliA.Id, "token-1", TimeSpan.FromMinutes(5));
        var lock2 = await repo.TentarAdquirirLockBancoAsync(cliA.Id, "token-2", TimeSpan.FromMinutes(5));
        Assert.True(lock1);
        Assert.False(lock2);
        await repo.LiberarLockBancoAsync(cliA.Id, "token-1");

        // 3. Testa Lote com Falha em Cliente A (deve fazer ROLLBACK total) + Sucesso em Cliente B (deve aplicar 4.47 e 4.48)
        const string scriptComErroNoSegundoLote = """
            CREATE TABLE dbo.Tabela_Deve_Sofrer_Rollback (Id INT PRIMARY KEY);
            GO
            INSERT INTO dbo.Tabela_Inexistente_Para_Forcar_Erro (Coluna) VALUES (1);
            GO
            """;

        var loteMisto = (await service.AtualizarBancoDeDadosAsync(new AtualizarVersoesRequest
        {
            Versoes =
            [
                new AtualizarVersaoItem
                {
                    IdClienteBanco = cliA.Id,
                    NomeEmpresa = cliA.NomeEmpresa,
                    NomeBanco = _clientDbA,
                    VersaoAtual = "4.42.0.1",
                    VersaoAlvo = "script_erro.sql",
                    NomeScriptCustomizado = "script_erro.sql",
                    ScriptCustomizadoConteudo = scriptComErroNoSegundoLote
                },
                new AtualizarVersaoItem
                {
                    NomeEmpresa = "Empresa Teste B",
                    NomeBanco = _clientDbB,
                    VersaoAtual = "V4.46.0.4",
                    VersaoAlvo = "V4.48.0.0"
                }
            ]
        }, "Tester", "TesteIntegrado")).ToList();

        var resA = loteMisto.First(r => r.NomeBanco == _clientDbA);
        var resB = loteMisto.First(r => r.NomeBanco == _clientDbB);

        // Cliente A falhou e sofreu Rollback (a tabela do lote 1 não pode existir e a versão segue 4.42.0.1!)
        Assert.False(resA.Sucesso);
        Assert.Equal("Falha", resA.Status);
        Assert.Equal("4.42.0.1", resA.VersaoAtual);
        Assert.False(await TabelaExisteNoBancoAsync(_clientDbA, "dbo.Tabela_Deve_Sofrer_Rollback"));

        // Cliente B teve sucesso no MESMO lote, provando isolamento entre clientes!
        Assert.True(resB.Sucesso);
        Assert.Equal("Atualizado", resB.Status);
        Assert.Equal("V4.48.0.0", resB.VersaoAtual);
        var (_, versaoRealB, _) = await repo.LerVersaoRealBancoClienteAsync("SRV-TEST-01", _clientDbB);
        Assert.Equal("V4.48.0.0", versaoRealB);

        // 4. Agora atualiza Cliente A da 4.42.0.1 até V4.48.0.0 passando pelos 3 pacotes oficiais (4.46.0.4 -> 4.47.0.0 -> 4.48.0.0)
        var resRecuperacaoA = (await service.AtualizarBancoDeDadosAsync(new AtualizarVersoesRequest
        {
            Versoes =
            [
                new AtualizarVersaoItem
                {
                    IdClienteBanco = cliA.Id,
                    NomeEmpresa = cliA.NomeEmpresa,
                    NomeBanco = _clientDbA,
                    VersaoAtual = "4.42.0.1",
                    VersaoAlvo = "V4.48.0.0"
                }
            ]
        })).Single();

        Assert.True(resRecuperacaoA.Sucesso);
        Assert.Equal("V4.48.0.0", resRecuperacaoA.VersaoAtual);
        Assert.True(await TabelaExisteNoBancoAsync(_clientDbA, "dbo.Auditoria_Sistema"));
        Assert.True(await TabelaExisteNoBancoAsync(_clientDbA, "dbo.Parametros_Fiscais"));
        Assert.True(await TabelaExisteNoBancoAsync(_clientDbA, "dbo.Movimentacao_Estoque"));

        // 5. Teste de Idempotência (Execução Duplicada por SHA-256):
        const string scriptCustomOk = """
            IF OBJECT_ID('dbo.Tabela_Custom_Unica', 'U') IS NULL
                CREATE TABLE dbo.Tabela_Custom_Unica (Id INT IDENTITY(1,1) PRIMARY KEY, Criado DATETIME2 DEFAULT SYSDATETIME());
            INSERT INTO dbo.Tabela_Custom_Unica DEFAULT VALUES;
            """;

        await service.AtualizarBancoDeDadosAsync(new AtualizarVersoesRequest
        {
            Versoes =
            [
                new AtualizarVersaoItem
                {
                    IdClienteBanco = cliA.Id,
                    NomeEmpresa = cliA.NomeEmpresa,
                    NomeBanco = _clientDbA,
                    VersaoAtual = "V4.48.0.0",
                    VersaoAlvo = "hotfix_unico.sql",
                    NomeScriptCustomizado = "hotfix_unico.sql",
                    ScriptCustomizadoConteudo = scriptCustomOk
                }
            ]
        });

        // Segunda tentativa com o MESMO script deve ser bloqueada pela checagem SHA-256 (continuará tendo apenas 1 linha!)
        await service.AtualizarBancoDeDadosAsync(new AtualizarVersoesRequest
        {
            Versoes =
            [
                new AtualizarVersaoItem
                {
                    IdClienteBanco = cliA.Id,
                    NomeEmpresa = cliA.NomeEmpresa,
                    NomeBanco = _clientDbA,
                    VersaoAtual = "V4.48.0.0",
                    VersaoAlvo = "hotfix_unico.sql",
                    NomeScriptCustomizado = "hotfix_unico.sql",
                    ScriptCustomizadoConteudo = scriptCustomOk
                }
            ]
        });

        Assert.Equal(1, await ContarLinhasAsync(_clientDbA, "dbo.Tabela_Custom_Unica"));
    }

    private static async Task<bool> TabelaExisteNoBancoAsync(string dbName, string objectName)
    {
        await using var conn = new SqlConnection($"Server=(localdb)\\MSSQLLocalDB;Database={dbName};Trusted_Connection=True;TrustServerCertificate=True;");
        await conn.OpenAsync();
        await using var cmd = new SqlCommand("SELECT CASE WHEN OBJECT_ID(@obj, 'U') IS NOT NULL THEN 1 ELSE 0 END;", conn);
        cmd.Parameters.AddWithValue("@obj", objectName);
        return Convert.ToInt32(await cmd.ExecuteScalarAsync()) == 1;
    }

    private static async Task<int> ContarLinhasAsync(string dbName, string tableName)
    {
        await using var conn = new SqlConnection($"Server=(localdb)\\MSSQLLocalDB;Database={dbName};Trusted_Connection=True;TrustServerCertificate=True;");
        await conn.OpenAsync();
        await using var cmd = new SqlCommand($"SELECT COUNT(*) FROM {tableName};", conn);
        return Convert.ToInt32(await cmd.ExecuteScalarAsync());
    }

    public async Task DisposeAsync()
    {
        var dbsToDrop = new[] { _controlDbName, _clientDbA, _clientDbB, _inactiveDb };
        await using var masterConn = new SqlConnection("Server=(localdb)\\MSSQLLocalDB;Database=master;Trusted_Connection=True;TrustServerCertificate=True;");
        await masterConn.OpenAsync();

        foreach (var db in dbsToDrop)
        {
            try
            {
                var dropSql = $"""
                    IF DB_ID(N'{db}') IS NOT NULL
                    BEGIN
                        ALTER DATABASE [{db}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
                        DROP DATABASE [{db}];
                    END
                    """;
                await using var cmd = new SqlCommand(dropSql, masterConn) { CommandTimeout = 30 };
                await cmd.ExecuteNonQueryAsync();
            }
            catch
            {
                // Ignora erros de limpeza em teardown
            }
        }

        await _serviceProvider.DisposeAsync();
    }

    private sealed class FakeWebHostEnvironment(string contentRoot) : IWebHostEnvironment
    {
        public string WebRootPath { get; set; } = contentRoot;
        public IFileProvider WebRootFileProvider { get; set; } = new NullFileProvider();
        public string ApplicationName { get; set; } = "Tests";
        public IFileProvider ContentRootFileProvider { get; set; } = new NullFileProvider();
        public string ContentRootPath { get; set; } = contentRoot;
        public string EnvironmentName { get; set; } = "Development";
    }
}
