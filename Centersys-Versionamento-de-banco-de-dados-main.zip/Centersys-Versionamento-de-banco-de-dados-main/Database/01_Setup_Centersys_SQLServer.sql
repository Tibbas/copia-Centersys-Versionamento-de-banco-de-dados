-- ============================================================================
-- CENTERSYS — ORQUESTRADOR DE ATUALIZAÇÕES DE BANCO DE DADOS MULTICLIENTE
-- Script Oficial de Criação do Banco Central (CentersysControle) e
-- Provisionamento Inicial dos Bancos Individuais dos Clientes (Homologação/Dev)
-- ============================================================================

IF DB_ID(N'CentersysControle') IS NULL
BEGIN
    CREATE DATABASE [CentersysControle];
END
GO

USE [CentersysControle];
GO

-- 1. Usuários e Permissões da API (Autenticação JWT)
IF OBJECT_ID(N'dbo.Usuarios', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Usuarios (
        Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Usuarios PRIMARY KEY,
        Nome NVARCHAR(150) NOT NULL,
        Email NVARCHAR(180) NOT NULL,
        SenhaHash NVARCHAR(512) NOT NULL,
        Perfil NVARCHAR(40) NOT NULL CONSTRAINT DF_Usuarios_Perfil DEFAULT (N'Admin'),
        Ativo BIT NOT NULL CONSTRAINT DF_Usuarios_Ativo DEFAULT (1),
        CriadoEm DATETIME2 NOT NULL CONSTRAINT DF_Usuarios_CriadoEm DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT UQ_Usuarios_Email UNIQUE (Email)
    );
END
GO

-- 2. Credenciais Criptografadas por Servidor/Instância SQL
IF OBJECT_ID(N'dbo.CredenciaisServidores', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.CredenciaisServidores (
        Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_CredenciaisServidores PRIMARY KEY,
        Servidor NVARCHAR(128) NOT NULL,
        Datacenter NVARCHAR(100) NOT NULL,
        HostInstancia NVARCHAR(256) NOT NULL,
        Porta INT NULL,
        UsarAutenticacaoWindows BIT NOT NULL CONSTRAINT DF_Credenciais_WinAuth DEFAULT (1),
        UsuarioSql NVARCHAR(128) NULL,
        SenhaCriptografada NVARCHAR(2048) NULL,
        TrustServerCertificate BIT NOT NULL CONSTRAINT DF_Credenciais_Trust DEFAULT (1),
        Ativo BIT NOT NULL CONSTRAINT DF_Credenciais_Ativo DEFAULT (1),
        UltimaConexaoOk BIT NULL,
        UltimaVerificacaoConexao DATETIME2 NULL,
        MensagemStatusConexao NVARCHAR(1000) NULL,
        CriadoEm DATETIME2 NOT NULL CONSTRAINT DF_Credenciais_CriadoEm DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT UQ_CredenciaisServidores_Servidor UNIQUE (Servidor)
    );
END
GO

-- 3. Catálogo Central de Bancos de Dados de Clientes
IF OBJECT_ID(N'dbo.ClientesBancos', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ClientesBancos (
        Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ClientesBancos PRIMARY KEY,
        NomeEmpresa NVARCHAR(150) NOT NULL,
        NomeBanco NVARCHAR(128) NOT NULL,
        Servidor NVARCHAR(128) NOT NULL CONSTRAINT DF_ClientesBancos_Servidor DEFAULT (N'SRV-SQL-01'),
        Datacenter NVARCHAR(100) NOT NULL CONSTRAINT DF_ClientesBancos_Datacenter DEFAULT (N'Datacenter 111'),
        VersaoAtualConhecida NVARCHAR(50) NOT NULL,
        Status NVARCHAR(30) NOT NULL CONSTRAINT DF_ClientesBancos_Status DEFAULT (N'DESATUALIZADA'),
        Aprovado BIT NOT NULL CONSTRAINT DF_ClientesBancos_Aprovado DEFAULT (1),
        DescobertoAutomaticamente BIT NOT NULL CONSTRAINT DF_ClientesBancos_Descoberto DEFAULT (0),
        AtivoNaInstancia BIT NOT NULL CONSTRAINT DF_ClientesBancos_Ativo DEFAULT (1),
        EmExecucaoLock BIT NOT NULL CONSTRAINT DF_ClientesBancos_Lock DEFAULT (0),
        LockToken NVARCHAR(64) NULL,
        LockExpiracao DATETIME2 NULL,
        UltimaVerificacao DATETIME2 NULL,
        UltimaAtualizacao DATETIME2 NULL,
        UltimoErroResumo NVARCHAR(1000) NULL,
        CriadoEm DATETIME2 NOT NULL CONSTRAINT DF_ClientesBancos_CriadoEm DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT UQ_ClientesBancos_Servidor_NomeBanco UNIQUE (Servidor, NomeBanco)
    );

    CREATE NONCLUSTERED INDEX IX_ClientesBancos_Status_Datacenter
        ON dbo.ClientesBancos (Status, Datacenter);
END
GO

-- 4. Catálogo de Pacotes de Versão e Arquivos de Script (.sql)
IF OBJECT_ID(N'dbo.PacotesVersao', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.PacotesVersao (
        Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_PacotesVersao PRIMARY KEY,
        NumeroVersao NVARCHAR(50) NOT NULL,
        VersaoNormalizada NVARCHAR(120) NOT NULL,
        Descricao NVARCHAR(500) NULL,
        Origem NVARCHAR(40) NOT NULL CONSTRAINT DF_PacotesVersao_Origem DEFAULT (N'Local'),
        CaminhoOuDriveId NVARCHAR(500) NULL,
        EhVersaoAlvoPadrao BIT NOT NULL CONSTRAINT DF_PacotesVersao_Padrao DEFAULT (0),
        Ativo BIT NOT NULL CONSTRAINT DF_PacotesVersao_Ativo DEFAULT (1),
        CriadoEm DATETIME2 NOT NULL CONSTRAINT DF_PacotesVersao_CriadoEm DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT UQ_PacotesVersao_VersaoNormalizada UNIQUE (VersaoNormalizada)
    );
END
GO

IF OBJECT_ID(N'dbo.ArquivosScript', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ArquivosScript (
        Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ArquivosScript PRIMARY KEY,
        PacoteVersaoId INT NOT NULL,
        NomeArquivo NVARCHAR(260) NOT NULL,
        OrdemExecucao INT NOT NULL,
        ConteudoSql NVARCHAR(MAX) NOT NULL,
        HashSha256 NCHAR(64) NOT NULL,
        QuantidadeLotesGo INT NOT NULL CONSTRAINT DF_ArquivosScript_Lotes DEFAULT (1),
        ContemTransacaoInterna BIT NOT NULL CONSTRAINT DF_ArquivosScript_Tran DEFAULT (0),
        ContemOperacaoNaoTransacional BIT NOT NULL CONSTRAINT DF_ArquivosScript_NonTran DEFAULT (0),
        AvisosValidacao NVARCHAR(1000) NULL,
        CriadoEm DATETIME2 NOT NULL CONSTRAINT DF_ArquivosScript_CriadoEm DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT FK_ArquivosScript_PacotesVersao FOREIGN KEY (PacoteVersaoId)
            REFERENCES dbo.PacotesVersao(Id) ON DELETE CASCADE,
        CONSTRAINT UQ_ArquivosScript_Pacote_Nome UNIQUE (PacoteVersaoId, NomeArquivo)
    );
END
GO

-- 5. Execuções de Lote, Bancos, Scripts (Idempotência SHA-256) e Eventos de Log
IF OBJECT_ID(N'dbo.ExecucoesLote', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ExecucoesLote (
        Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ExecucoesLote PRIMARY KEY,
        DisparadoPor NVARCHAR(150) NOT NULL,
        Origem NVARCHAR(40) NOT NULL,
        TotalBancos INT NOT NULL,
        TotalSucesso INT NOT NULL DEFAULT (0),
        TotalFalha INT NOT NULL DEFAULT (0),
        TotalCancelado INT NOT NULL DEFAULT (0),
        StatusLote NVARCHAR(40) NOT NULL,
        CancelamentoSolicitado BIT NOT NULL DEFAULT (0),
        DataInicio DATETIME2 NOT NULL DEFAULT (SYSUTCDATETIME()),
        DataFim DATETIME2 NULL
    );

    CREATE NONCLUSTERED INDEX IX_ExecucoesLote_DataInicio ON dbo.ExecucoesLote (DataInicio DESC);
END
GO

IF OBJECT_ID(N'dbo.ExecucoesBanco', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ExecucoesBanco (
        Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ExecucoesBanco PRIMARY KEY,
        ExecucaoLoteId INT NOT NULL,
        ClienteBancoId INT NOT NULL,
        NomeEmpresa NVARCHAR(150) NOT NULL,
        NomeBanco NVARCHAR(128) NOT NULL,
        Servidor NVARCHAR(128) NOT NULL,
        Datacenter NVARCHAR(100) NOT NULL,
        VersaoOrigem NVARCHAR(50) NOT NULL,
        VersaoAlvo NVARCHAR(260) NOT NULL,
        VersaoAlcancada NVARCHAR(260) NOT NULL,
        EhScriptCustomizado BIT NOT NULL DEFAULT (0),
        NomeScriptCustomizado NVARCHAR(260) NULL,
        ConteudoScriptCustomizado NVARCHAR(MAX) NULL,
        Status NVARCHAR(40) NOT NULL,
        ProgressoPercentual INT NOT NULL DEFAULT (0),
        EtapaAtual NVARCHAR(150) NOT NULL,
        Sucesso BIT NOT NULL DEFAULT (0),
        MensagemResumo NVARCHAR(1000) NULL,
        DataInicio DATETIME2 NOT NULL DEFAULT (SYSUTCDATETIME()),
        DataFim DATETIME2 NULL,
        CONSTRAINT FK_ExecucoesBanco_Lote FOREIGN KEY (ExecucaoLoteId)
            REFERENCES dbo.ExecucoesLote(Id) ON DELETE CASCADE,
        CONSTRAINT FK_ExecucoesBanco_Cliente FOREIGN KEY (ClienteBancoId)
            REFERENCES dbo.ClientesBancos(Id)
    );

    CREATE NONCLUSTERED INDEX IX_ExecucoesBanco_Cliente_Data
        ON dbo.ExecucoesBanco (ClienteBancoId, DataInicio DESC);
END
GO

IF OBJECT_ID(N'dbo.ExecucoesScript', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ExecucoesScript (
        Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ExecucoesScript PRIMARY KEY,
        ExecucaoBancoId INT NOT NULL,
        ClienteBancoId INT NOT NULL,
        VersaoPacote NVARCHAR(260) NOT NULL,
        NomeArquivo NVARCHAR(260) NOT NULL,
        HashSha256 NCHAR(64) NOT NULL,
        OrdemExecucao INT NOT NULL,
        Sucesso BIT NOT NULL,
        IgnoradoIdempotencia BIT NOT NULL DEFAULT (0),
        ModoNaoTransacional BIT NOT NULL DEFAULT (0),
        DuracaoMs INT NOT NULL DEFAULT (0),
        NumeroErroSql INT NULL,
        LinhaErroSql INT NULL,
        NivelLog NVARCHAR(20) NOT NULL,
        MensagemLog NVARCHAR(MAX) NOT NULL,
        DataExecucao DATETIME2 NOT NULL DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT FK_ExecucoesScript_ExecucaoBanco FOREIGN KEY (ExecucaoBancoId)
            REFERENCES dbo.ExecucoesBanco(Id) ON DELETE CASCADE,
        CONSTRAINT FK_ExecucoesScript_Cliente FOREIGN KEY (ClienteBancoId)
            REFERENCES dbo.ClientesBancos(Id)
    );

    CREATE NONCLUSTERED INDEX IX_ExecucoesScript_Idempotencia
        ON dbo.ExecucoesScript (ClienteBancoId, HashSha256, Sucesso);
END
GO

IF OBJECT_ID(N'dbo.LogsEventos', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.LogsEventos (
        Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_LogsEventos PRIMARY KEY,
        ExecucaoLoteId INT NULL,
        ClienteBancoId INT NULL,
        NomeBanco NVARCHAR(128) NULL,
        Nivel NVARCHAR(20) NOT NULL,
        Mensagem NVARCHAR(MAX) NOT NULL,
        DataHora DATETIME2 NOT NULL DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT FK_LogsEventos_Lote FOREIGN KEY (ExecucaoLoteId)
            REFERENCES dbo.ExecucoesLote(Id) ON DELETE CASCADE
    );

    CREATE NONCLUSTERED INDEX IX_LogsEventos_Lote_Id ON dbo.LogsEventos (ExecucaoLoteId, Id);
END
GO

IF OBJECT_ID(N'dbo.Agendamentos', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Agendamentos (
        Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Agendamentos PRIMARY KEY,
        Descricao NVARCHAR(200) NOT NULL,
        VersaoAlvo NVARCHAR(50) NOT NULL,
        DatacenterEscopo NVARCHAR(100) NULL,
        IdsClientesCsv NVARCHAR(1000) NULL,
        DataHoraProgramada DATETIME2 NOT NULL,
        Status NVARCHAR(30) NOT NULL DEFAULT (N'Pendente'),
        ExecucaoLoteId INT NULL,
        CriadoPor NVARCHAR(150) NOT NULL DEFAULT (N'Operador'),
        MensagemResultado NVARCHAR(1000) NULL,
        CriadoEm DATETIME2 NOT NULL DEFAULT (SYSUTCDATETIME()),
        ExecutadoEm DATETIME2 NULL
    );

    CREATE NONCLUSTERED INDEX IX_Agendamentos_Status_Data
        ON dbo.Agendamentos (Status, DataHoraProgramada);
END
GO

-- ============================================================================
-- 6. PROVISIONAMENTO DE BANCOS DE CLIENTES DE HOMOLOGAÇÃO + dbo.Log_Acesso
-- ============================================================================
DECLARE @BancosClientes TABLE (NomeBanco SYSNAME, VersaoInicial VARCHAR(50));
INSERT INTO @BancosClientes (NomeBanco, VersaoInicial) VALUES
    (N'db_boasaude_prod',      'V4.48.0.0'),
    (N'db_central_erp',        'V4.46.0.1'),
    (N'db_ferragens_prod',     'V4.46.0.3'),
    (N'db_vida_gestao',        'V4.45.2.0'),
    (N'db_autohorizonte_prod', 'V4.48.0.0'),
    (N'db_emporio_erp',        'V4.48.0.0'),
    (N'db_alianca_prod',       'V4.47.0.0'),
    (N'db_visao_prod',         'V4.48.0.0'),
    (N'DB_Horizonte_Prod',     '4.42.0.1'),
    (N'_db_inativo_teste',     '4.40.0.0'); -- Banco inativo (começa com '_') ignorado pela descoberta!

DECLARE @Db SYSNAME, @Ver VARCHAR(50), @Cmd NVARCHAR(MAX);
DECLARE cur_db CURSOR LOCAL FAST_FORWARD FOR SELECT NomeBanco, VersaoInicial FROM @BancosClientes;
OPEN cur_db;
FETCH NEXT FROM cur_db INTO @Db, @Ver;

WHILE @@FETCH_STATUS = 0
BEGIN
    IF DB_ID(@Db) IS NULL
    BEGIN
        SET @Cmd = N'CREATE DATABASE ' + QUOTENAME(@Db) + N';';
        EXEC sp_executesql @Cmd;
    END

    SET @Cmd = N'
        USE ' + QUOTENAME(@Db) + N';
        IF OBJECT_ID(''dbo.Log_Acesso'', ''U'') IS NULL
        BEGIN
            CREATE TABLE dbo.Log_Acesso (
                Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Log_Acesso PRIMARY KEY,
                cNumVersao VARCHAR(50) NOT NULL,
                dDataAtualizacao DATETIME2 NOT NULL CONSTRAINT DF_Log_Acesso_Data DEFAULT (SYSDATETIME())
            );
            INSERT INTO dbo.Log_Acesso (cNumVersao) VALUES (@v);
        END';
    EXEC sp_executesql @Cmd, N'@v VARCHAR(50)', @v = @Ver;

    FETCH NEXT FROM cur_db INTO @Db, @Ver;
END

CLOSE cur_db;
DEALLOCATE cur_db;
GO
