# CenterSys — Orquestrador de Atualizações de Banco de Dados em Ambiente Multicliente

Sistema completo (**API .NET 10 + Painel React 19/TypeScript + Microsoft SQL Server**) para descoberta, validação sintática T-SQL, execução transacional controlada, auditoria e agendamento de atualizações de banco de dados em múltiplos clientes.

---

## 1. Visão Geral da Arquitetura

O sistema separa estritamente a **gestão e auditoria centralizada** da **execução transacional isolada nos bancos individuais dos clientes**:

```mermaid
flowchart TB
    subgraph Front["Frontend React 19 + TypeScript (Porta 3000)"]
        LOGIN["Autenticação JWT"]
        DASH["Visão Geral & Frota de Bancos"]
        ORCH["Orquestrador em Lote & Console Ao Vivo"]
        OPS["Histórico, Agendamentos & Credenciais"]
    end

    subgraph API["Backend ASP.NET Core .NET 10 (Porta 5119 / 7115)"]
        AUTH["AuthController (JWT + PBKDF2)"]
        VERS["VersoesController / Agendamentos / Credenciais"]
        SVC["VersaoService + AgendamentoWorker"]
        PARSER["SqlScriptAnalyzer (ScriptDom TSql160Parser + SHA-256)"]
        CRED["DataProtectionCredentialProvider"]
        REPO["BancoClientesRepository (EF Core + SqlClient)"]
    end

    subgraph SQL["Microsoft SQL Server"]
        CTRL[("CentersysControle (Banco Central)\n- Usuarios\n- CredenciaisServidores\n- ClientesBancos\n- PacotesVersao / ArquivosScript\n- ExecucoesLote / ExecucoesBanco / ExecucoesScript\n- LogsEventos / Agendamentos")]
        TENANTS[("Bancos dos Clientes (Multi-Tenant)\n- db_boasaude_prod (dbo.Log_Acesso)\n- db_central_erp (dbo.Log_Acesso)\n- ...\n- _db_inativo_teste (Ignorado por '_')")]
    end

    Front <-->|"HTTP JSON + Bearer JWT"| API
    AUTH & VERS --> SVC
    SVC --> PARSER
    SVC --> REPO
    REPO --> CRED
    REPO <-->|"EF Core"| CTRL
    REPO <-->|"Microsoft.Data.SqlClient + SqlTransaction"| TENANTS
```

---

## 2. Estrutura do Banco Central e dos Bancos dos Clientes

### 2.1 Banco Central (`CentersysControle`)
Gerenciado pelo `ApplicationDbContext` (EF Core) e documentado no script [`Database/01_Setup_Centersys_SQLServer.sql`](./Database/01_Setup_Centersys_SQLServer.sql):

| Tabela | Responsabilidade |
| :--- | :--- |
| `dbo.Usuarios` | Operadores e administradores autenticados com hash salgado `PBKDF2-HMACSHA256`. |
| `dbo.CredenciaisServidores` | Instâncias SQL Server por servidor/datacenter com senhas cifradas via ASP.NET Core `DataProtection`. |
| `dbo.ClientesBancos` | Catálogo de bancos de clientes aprovados, versão conhecida, status e controle de lock atômico (`EmExecucaoLock`). |
| `dbo.PacotesVersao` / `dbo.ArquivosScript` | Pacotes de versão (`V4.46.0.4`, `V4.47.0.0`, `V4.48.0.0`, etc.), scripts `.sql` ordenados, quantidade de lotes `GO` e checksum `SHA-256`. |
| `dbo.ExecucoesLote` / `dbo.ExecucoesBanco` | Cabeçalho de cada lote (manual ou agendado) e progresso/status individual de cada cliente. |
| `dbo.ExecucoesScript` | Auditoria por arquivo `.sql` executado: duração (ms), hash `SHA-256` (bloqueio de reexecução duplicada), número/linha de erro SQL e status de rollback. |
| `dbo.LogsEventos` | Trilha cronológica de eventos (`SYSTEM`, `INFO`, `EXEC`, `SUCCESS`, `WARN`) exibida no console ao vivo. |
| `dbo.Agendamentos` | Janelas programadas executadas internamente pelo `AgendamentoWorker` (`BackgroundService`). |

### 2.2 Bancos Individuais dos Clientes
Seguindo a convenção oficial da CenterSys:
- **Fonte da verdade da versão instalada:** Tabela `dbo.Log_Acesso`, coluna `cNumVersao` (`VARCHAR(50)`), linha única por cliente (parametrizável via `OrquestradorSettings`).
- **Descarte de clientes inativos:** Qualquer banco na instância cujo nome inicie com underline (`_`, ex.: `_db_inativo_teste`) ou bancos de sistema (`master`, `model`, `msdb`, `tempdb`, `CentersysControle`) são automaticamente ignorados na descoberta e bloqueados para execução.

---

## 3. Pré-requisitos e Instalação

- **.NET SDK 10.0+**
- **Node.js 20+ / npm**
- **Microsoft SQL Server** (Express, Developer, Standard ou **SQL Server LocalDB** `(localdb)\MSSQLLocalDB`)

### Inicialização do SQL Server
Em ambiente de desenvolvimento (`ASPNETCORE_ENVIRONMENT=Development`), o `DbInitializer` da API cria automaticamente:
1. O banco central `CentersysControle` com todas as tabelas e índices;
2. Os pacotes oficiais da pasta `Centersys.AtualizadorVersoes.Api/ScriptsVersoes/`;
3. Os 9 bancos de clientes de homologação (`db_boasaude_prod`, `db_central_erp`, `db_ferragens_prod`, `db_vida_gestao`, `db_autohorizonte_prod`, `db_emporio_erp`, `db_alianca_prod`, `db_visao_prod`, `DB_Horizonte_Prod`) + `_db_inativo_teste` para validação da regra do underline.

Caso prefira provisionar manualmente no SSMS ou em outra instância SQL Server, execute o script [`Database/01_Setup_Centersys_SQLServer.sql`](./Database/01_Setup_Centersys_SQLServer.sql).

---

## 4. Configuração e Execução

### 4.1 Variáveis e `appsettings.json`
No arquivo `Centersys.AtualizadorVersoes.Api/appsettings.json`:
- `ConnectionStrings:DefaultConnection`: String de conexão apontando para `CentersysControle`.
- `CENTERSYS_JWT_SECRET` (variável de ambiente recomendada para produção): chave simétrica com no mínimo 32 caracteres para assinatura dos tokens JWT. Em desenvolvimento local, `appsettings.Development.json` fornece uma chave exclusiva de desenvolvimento.
- `OrquestradorSettings`: permite parametrizar `TabelaVersaoCliente`, `ColunaVersaoCliente`, `CommandTimeoutSegundos` e `LockTimeoutMinutos`.

### 4.2 Executando o Backend (API .NET)
Na raiz do repositório:
```powershell
sqllocaldb start MSSQLLocalDB
dotnet run --project Centersys.AtualizadorVersoes.Api/Centersys.AtualizadorVersoes.Api.csproj --launch-profile http
```
A API responderá em `http://localhost:5119` (Health check em `GET http://localhost:5119/api/health`).

### 4.3 Executando o Frontend (React + Vite)
Em outro terminal:
```powershell
cd "frontend/a3 centersys"
npm install
npm run dev
```
Acesse **`http://localhost:3000`** no navegador.

**Credenciais iniciais de homologação local:**
- **E-mail:** `admin@centersys.com.br`
- **Senha:** `CenterSys@2026`

---

## 5. Guia de Operação no Sistema

1. **Cadastro e Teste de Clientes:**
   - Na aba **Visão geral**, clique em **Cadastrar Cliente / Banco** para registrar uma empresa (com opção de criar o banco físico e `dbo.Log_Acesso` na instância).
   - Use o ícone de **tomada/raio** na linha de qualquer cliente para testar a conectividade em tempo real e ler `dbo.Log_Acesso.cNumVersao`.
   - Use **Sincronizar SQL Server** para descobrir novos bancos criados diretamente na instância SQL Server (descartando nomes com `_`).
2. **Cadastro de Versões e Scripts SQL:**
   - Coloque novas pastas no formato `Versão X.X.X.X` dentro de `Centersys.AtualizadorVersoes.Api/ScriptsVersoes/` (com `scriptVersao.sql` ao final) **ou** clique em **+ Nova Versão** no painel para enviar os arquivos `.sql` pela interface.
   - Todo script é validado pelo parser oficial `Microsoft.SqlServer.TransactSql.ScriptDom` antes de ser aceito.
3. **Execução Individual, em Lote e Scripts Customizados:**
   - Na aba **Orquestrador de atualizações**, selecione um ou vários bancos, defina a versão alvo global/individual (ou anexe um `.sql` exclusivo), revise o modal de confirmação e clique em **Iniciar Atualização**.
   - Cada arquivo `.sql` roda com `SET XACT_ABORT ON` dentro de uma `SqlTransaction` isolada. Se um script falhar em um cliente, ocorre `ROLLBACK` imediato daquele banco sem interromper os demais clientes do lote.

---

## 6. Execução dos Testes Automatizados

O projeto `Centersys.AtualizadorVersoes.Tests` inclui testes unitários (comparador de N segmentos, ordenação de `scriptVersao.sql`, parser `ScriptDom` com literais `GO`, bloqueio de `USE`/`ROLLBACK`, PBKDF2 e proteção contra SQL Injection) e **testes reais de integração no SQL Server** (descoberta com underline, progressão multi-pacote, rollback em falha no meio de múltiplos lotes `GO`, isolamento entre clientes, concorrência de lock e idempotência por SHA-256):

```powershell
dotnet test Centersys.AtualizadorVersoes.Api.slnx
```

---

## 7. Segurança e Limitações Conhecidas

### Mecanismos de Segurança Implementados
- **Autenticação e Autorização:** JWT Bearer (`[Authorize]`) nas rotas operacionais e `[Authorize(Roles = "Admin")]` na gestão de credenciais; senhas de usuários com `PBKDF2-HMACSHA256` (100.000 iterações + salt aleatório).
- **Proteção de Credenciais SQL:** Senhas de instâncias SQL criptografadas em repouso via `IDataProtectionProvider`; jamais retornadas em endpoints `GET` ou gravadas em logs.
- **Blindagem Multi-Tenant:** Bloqueio de bancos de sistema, bloqueio de bancos inativos (`_`), validação estrita de identificadores SQL e rejeição estática na árvore sintática (`ScriptDom`) de qualquer instrução `USE <outro_banco>` ou `ROLLBACK` fora de bloco `CATCH`.

### Limitações Conhecidas
- **Operações DDL Não Transacionais no SQL Server:** Instruções como `ALTER DATABASE`, `CREATE FULLTEXT CATALOG` ou `BACKUP/RESTORE` não suportam rollback transacional pelo próprio motor do SQL Server. O `SqlScriptAnalyzer` detecta automaticamente essas instruções na pré-varredura e **bloqueia a execução por padrão**, exigindo confirmação explícita (`PermiteOperacaoNaoTransacional = true`) caso o administrador deseje aplicá-las.
- **Cofre de Chaves Externo de Produção:** Em homologação/desenvolvimento, as credenciais utilizam criptografia local `DataProtection`. Para implantação definitiva na infraestrutura em nuvem da CenterSys, basta registrar a implementação correspondente de `ICredentialProvider` integrada ao cofre corporativo definido pela empresa.
